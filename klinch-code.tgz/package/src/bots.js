// Named bots and personality.
//
// SOUL.md: the agent's personality and manner (tone, habits, what it cares about), added to the system prompt of
//   every session. Looked up in ~/.klinch/SOUL.md, then <project>/SOUL.md or <project>/.klinch/SOUL.md (the
//   project's wins). It changes the manner only: the agent is still Klinch Code and follows all its rules.
// Bot: a named profile with its own role, model, depth and memory. ~/.klinch/bots/<name>.md or
//   <project>/.klinch/bots/<name>.md, front matter `name`, `description`, `model`, `effort`, then the bot's role and
//   personality (its own SOUL). `klinch --bot <name>`, /bot <name>, /bot off; /compare @a,@b and board cards use
//   bots too. A bot remembers facts between sessions in ~/.klinch/bots/<name>.memory.md (the `remember` tool).
import { readFileSync, readdirSync, appendFileSync, mkdirSync, existsSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join, basename } from 'node:path';
import { frontMatter } from './skills.js';

const home = (env) => env.KLINCH_HOME || join(homedir(), '.klinch');
const read = (p) => { try { return readFileSync(p, 'utf8'); } catch { return null; } };
const slug = (s) => String(s || '').trim().toLowerCase().replace(/[^a-z0-9а-яё_-]+/gi, '-').replace(/^-+|-+$/g, '').slice(0, 40);

/** The personality text: the user's SOUL.md and the project's (later wins on conflicts, both are given). */
export function loadSoul(cwd, env = process.env) {
  const parts = [];
  const mine = read(join(home(env), 'SOUL.md'));
  if (mine?.trim()) parts.push(mine.trim().slice(0, 8000));
  const proj = read(join(cwd, 'SOUL.md')) ?? read(join(cwd, '.klinch', 'SOUL.md'));
  if (proj?.trim()) parts.push(proj.trim().slice(0, 8000));
  return parts.join('\n\n');
}

/** Bots: [{ name, description, model, effort, soul, file }], the project's winning over yours on a name clash. */
export function loadBots(cwd, env = process.env) {
  const out = new Map();
  for (const dir of [join(home(env), 'bots'), join(cwd, '.klinch', 'bots')]) {
    let files = [];
    try { files = readdirSync(dir).filter((f) => f.endsWith('.md') && !f.endsWith('.memory.md')).sort(); } catch { continue; }
    for (const f of files) {
      const { meta, body } = frontMatter(read(join(dir, f)) || '');
      const name = slug(meta.name || basename(f, '.md'));
      if (!name) continue;
      out.set(name, {
        name, description: String(meta.description || body.trim().split('\n')[0] || '').slice(0, 200),
        model: meta.model || null, effort: meta.effort || null, soul: body.trim().slice(0, 12000), file: join(dir, f),
      });
    }
  }
  return [...out.values()];
}

export const memoryPath = (name, env = process.env) => join(home(env), 'bots', `${slug(name)}.memory.md`);
export const readMemory = (name, env = process.env) => (read(memoryPath(name, env)) || '').trim();

/** Creates ~/.klinch/bots/<name>.md from a template; returns its path. */
export function createBot(name, { description = '', model = '', soul = '' } = {}, env = process.env) {
  const n = slug(name);
  if (!n) throw new Error('Имя бота: буквы, цифры, - и _');
  const dir = join(home(env), 'bots'), file = join(dir, `${n}.md`);
  if (existsSync(file)) throw new Error(`Бот ${n} уже есть: ${file}`);
  mkdirSync(dir, { recursive: true });
  writeFileSync(file, `---\nname: ${n}\ndescription: ${description || 'мой бот'}\n${model ? `model: ${model}\n` : ''}---\n${soul || 'Ты … (роль бота: чем занимается, как говорит, на что обращает внимание).'}\n`);
  return file;
}

/** System prompt part for the personality and the active bot (with its memory). */
export function personaText({ soul = '', bot = null, env = process.env } = {}) {
  const parts = [];
  if (soul) parts.push(`# Личность (SOUL.md)\nЭто характер и манера общения, которые выбрал пользователь. Держись их, но ты по-прежнему Klinch Code и соблюдаешь все правила выше.\n${soul}`);
  if (bot) {
    const mem = readMemory(bot.name, env);
    parts.push(`# Ты бот «${bot.name}»\n${bot.soul}${mem ? `\n\n## Что ты помнишь с прошлых сессий\n${mem.slice(-12000)}` : ''}\n\nВажное для будущих сессий (решения, предпочтения пользователя, факты о проекте) сохраняй через remember, коротко.`);
  }
  return parts.join('\n\n');
}

/** The `remember` tool: offered only while a bot is active (`getBot()` returns it). */
export function rememberTool(getBot, env = process.env) {
  return {
    name: 'remember',
    description: 'Запомнить факт для будущих сессий этого бота (одна-две строки): решение, предпочтение пользователя, важный факт о проекте.',
    input_schema: { type: 'object', properties: { fact: { type: 'string' } }, required: ['fact'] },
    when: () => !!getBot(),
    preview: ({ fact }) => `remember ${String(fact).slice(0, 80)}`,
    run({ fact }) {
      const bot = getBot();
      if (!bot) throw new Error('Нет активного бота');
      const line = String(fact || '').replace(/\s+/g, ' ').trim().slice(0, 500);
      if (!line) throw new Error('Пустой факт');
      mkdirSync(join(home(env), 'bots'), { recursive: true });
      appendFileSync(memoryPath(bot.name, env), `- ${new Date().toISOString().slice(0, 10)} ${line}\n`);
      return 'Запомнил';
    },
  };
}
