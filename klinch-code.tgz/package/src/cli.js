// Command-line front end: `klinch` (chat), `klinch login`, `klinch models`, `klinch balance`, `klinch -p "task"`.
import { createInterface } from 'node:readline';
import { randomBytes } from 'node:crypto';
import { execFileSync, spawn } from 'node:child_process';
import { basename, dirname, join } from 'node:path';
import { homedir } from 'node:os';
import { readFileSync, writeFileSync, mkdirSync, openSync, unlinkSync } from 'node:fs';
import { stdin, stdout, stderr } from 'node:process';
import { loadConfig, saveConfig, maskKey, configPath } from './config.js';
import { createClient, fmt, ApiError } from './api.js';
import { withLocal } from './localmodels.js';
import { createAgent, formatTodos, EFFORTS, parseDuration } from './agent.js';
import { detectSandbox, sandboxSettings, sandboxConfig, describeSandbox, DEFAULT_IMAGE } from './sandbox.js';
import { statusCommand, builtinLine, customLine, gitBranch } from './statusline.js';
import { startServers, mcpCommand } from './mcp.js';
import { loadRules } from './rules.js';
import { createCodeIndex, describeIndex, EMBED_MODEL, DIMS } from './codeindex.js';
import { loadSkills, loadCommands, expandCommand, loadInstructions, INSTRUCTION_FILES, loadAgents, loadOutputStyles } from './skills.js';
import { pluginCommand, loadPlugins } from './plugins.js';
import { createHub, hubCommand } from './hub.js';
import { manageSkill, noteUse, curate, skillsCommand, agentSkills, CURATOR_PROMPT } from './selfskills.js';
import { buildRepoMap } from './repomap.js';
import { loadHookConfigs, createHooks, isTrusted as hooksTrusted, trust as trustHooks, noHooks } from './hooks.js';
import { BACKGROUND, killBackground, killAllBackground } from './tools.js';
import { startDesign, stopDesign, onPick, pickToContent, closeBrowser } from './browser.js';
import { loadPermissions, projectAllow, trustProjectAllow, suggestRule, addRule } from './permissions.js';
import { withMentions, clipboardImage, imageBlock, saveSession, listSessions } from './attach.js';
import { loadState, saveState, addFolder, pairLink, serve, openBrowser, VERSION } from './local.js';
import { ideBridge } from './ide.js';
import { createDiagnostics } from './lsp.js';
import { createCloud } from './cloud.js';
import { editMemory, readMemory, memoryPath, readGoal, setGoal, projectDir } from './memory.js';
import { parseWhen, describe as describeWhen, loadSchedules, addSchedule, takeDue, removeSchedule, scheduleTool, HEARTBEAT_PROMPT } from './schedule.js';
import { proposedContent } from './tools.js';
import { loadSoul, loadBots, personaText, rememberTool, readMemory as readBotMemory } from './bots.js';
import { serial, isEdit } from './multi.js';
import { multiCommands } from './multicli.js';
import { hookCommand, changesFor, reviewChanges } from './precommit.js';
import { record, transcribe, speak, waitForWake } from './voice.js';
import { mediaTools, canvasUrl, closeCanvas, showCanvas, htmlPage } from './media.js';
import { workspaceTools } from './workspace.js';
import { planAll } from './importer.js';
import { recordEdit, blameCommand, blameTool } from './blame.js';
import { loadAutomations, updateAutomation, automationCommand, automationTool, createEngine, listenHooks, eventPrompt, eventLabel, describeTrigger } from './automations.js';
import { acpMain } from './acp.js';
import * as gh from './github.js';

const c = stdout.isTTY && !process.env.NO_COLOR
  ? { dim: (s) => `\x1b[2m${s}\x1b[0m`, bold: (s) => `\x1b[1m${s}\x1b[0m`, red: (s) => `\x1b[31m${s}\x1b[0m`, green: (s) => `\x1b[32m${s}\x1b[0m`, cyan: (s) => `\x1b[36m${s}\x1b[0m`, yellow: (s) => `\x1b[33m${s}\x1b[0m` }
  : Object.fromEntries(['dim', 'bold', 'red', 'green', 'cyan', 'yellow'].map((k) => [k, (s) => s]));

const HELP = `klinch — агент для кода на балансе Klinch

  klinch                 чат с агентом в текущей папке
  klinch -p "задача"     выполнить одну задачу и выйти
  klinch -c              продолжить последний чат в этой папке
  klinch --plan          начать в режиме плана (сначала план, правки после одобрения)
  klinch -p "…" --output-format json|stream-json   для скриптов и CI (вывод в JSON)
  klinch --allow "shell(npm test:*)"   разрешить без вопросов на этот запуск (можно несколько)
  klinch login [ключ]    сохранить ключ Klinch (kl_live_…)
  klinch logout          удалить ключ
  klinch models          список доступных моделей
  klinch balance         остаток и расход
  klinch mcp list|add|remove   MCP-серверы (инструменты из других сервисов)
  klinch plugin list|add|remove  плагины в формате Claude Code (команды, скиллы, субагенты, хуки, MCP)
  klinch skills list|curate|archive|restore <имя>  скиллы; агент сам пишет свои, куратор убирает неиспользуемые
  klinch hub search <слова> | install <id> | remove <id> | list | sync   хаб скиллов и плагинов (и что включено в кабинете)
  klinch connect [папки] работать в этих папках из чата на klinch.cloud («Работать локально»)
  klinch daemon          выполнять задачи по расписанию и автоматизации фоном, пока окно открыто
  klinch schedule [list|remove <id>]   задачи по расписанию
  klinch automation add "<когда> <задача>" | list | remove|off|on|fire|token <id>   агент сам запускается при коммите,
                         изменении файлов, по вебхуку или по расписанию («при коммите в ветке main проверь тесты»)
  klinch blame <файл> [-L 10,40] [--json] | --stats   AI blame: какие строки написал агент, в какой сессии и по какому запросу
  klinch github install  бот для GitHub: ревью каждого PR (ошибки и безопасность) и ответы на ${gh.MENTION} в PR и issue
  klinch github review [--security] [N]  ревью PR в GitHub Actions (или PR номер N): замечания прямо в коде
  klinch github respond  выполнить просьбу из упоминания ${gh.MENTION} (в GitHub Actions)
  klinch import [claude|codex|openclaw] [-y]   перенести настройки, MCP, скиллы и инструкции из другого агента
  klinch acp             агент для редакторов с протоколом ACP (Zed, JetBrains); klinch acp setup — подключить их
  klinch cloud "задача"  облачный агент: работает на сервере с репозиторием GitHub и сам открывает PR (klinch cloud help)
  klinch -m <модель>     модель на этот запуск (сохраняется: klinch model <модель>)
  klinch -y              не спрашивать подтверждение правок и команд
  klinch --time-limit 80m  бюджет времени задачи: к концу агент сохраняет результат и пишет итог
  klinch --effort high   глубина размышлений модели: low, medium, high, max (сохранить: /effort в чате)
  klinch --sandbox       команды в песочнице: без вопросов, писать только в папку проекта, сеть только к реестрам
  klinch -m local:qwen3  локальная модель (Ollama, LM Studio, llama.cpp): бесплатно, без интернета
  klinch review [--staged] [--strict]  Agent Review изменений вне чата (для CI и перед коммитом)
  klinch hook install [--strict]   ревью перед каждым git commit (hook remove — выключить)
  klinch --bot <имя>     работать как бот (своя роль, модель и память: ~/.klinch/bots/<имя>.md)
  klinch -p "…" --compare [--models a,b] [--apply]  одна задача на нескольких моделях параллельно + ревью
  klinch -p "…" --moa [--models a,b]   Mixture of Agents: несколько моделей отвечают, одна сводит

Переменные: KLINCH_API_KEY, KLINCH_BASE_URL, KLINCH_MODEL, KLINCH_LOCAL_URL, KLINCH_EFFORT, KLINCH_SANDBOX=1, KLINCH_MAX_TOKENS,
KLINCH_REPO_MAP=1. Настройки: ~/.klinch/config.json
В сообщении: @путь/к/файлу прикрепляет файл или картинку, @файл#L10-20 — только эти строки.
«ultrathink» в сообщении: этот запрос модель обдумывает на максимуме.

В чате:
  /plan        режим плана вкл/выкл        /todo      список задач агента
  /effort [low|medium|high|max|auto]  глубина размышлений (/think то же)
  /sandbox [on|off|net on|off|list|allow|docker|ssh] песочница для команд   /statusline  строка состояния вкл/выкл
  /memory      память между сессиями (# текст в начале сообщения — запомнить для проекта)
  /goal [текст|clear]  постоянная цель проекта   /heartbeat [30m|stop]  агент сам двигается к цели
  /loop [когда] <задача>  повторять: «/loop каждые 10 минут проверь тесты», /loop stop [id]
  /automation [когда] <задача>  по событию: «при коммите …», «при изменении src/**/*.ts …», «по вебхуку …»; /automation rm <id>
  /blame <файл>[#L10-20]  AI blame: строки агента (сессия, запрос, модель) и человека; /blame без файла — по проекту
  /debug <баг>  режим отладки: логи, запуск, причина по фактам, логи убираются   /diagnostics  языковые серверы
  /style [имя] стиль ответов (explanatory, learning, свои)   /agents  субагенты   /plugins  плагины
  /rules       правила проекта по путям (.klinch/rules, .cursor/rules)   /index  индекс кода для поиска по смыслу
  /compact     сжать историю              /context   сколько занимает история
  /init        создать KLINCH.md           /resume    вернуться к прошлому чату
  /mcp         MCP-серверы                 /skills    скиллы и свои команды
  /curator     агент наводит порядок в своих скиллах (объединить, поправить, убрать)
  /hub [слова] найти и поставить скилл или плагин: /hub install <id> (плагин подключится при следующем запуске)
  /undo        откатить правки последнего запроса   /rewind [N]  вернуть файлы и чат к шагу N
  /permissions правила «без вопросов» и запреты
  /hooks       хуки                        /tasks     фоновые команды (/tasks kill <id>, /tasks out <id>)
  /repomap     карта проекта               /paste     картинка из буфера обмена
  /worktree    отдельная копия (git worktree): /worktree <имя>, /worktree exit
  /design      режим дизайна: /design localhost:3000, кликните элемент в окне и напишите правку; /design off
  /compare [m1,m2,@бот] <задача>  одна задача на нескольких моделях сразу, ревью сравнивает, вы выбираете
  /moa [m1,m2] <вопрос>  Mixture of Agents: модели отвечают параллельно, текущая сводит в один ответ
  /review [модель]  Agent Review: другой агент проверяет текущие изменения, прежде чем вы их примете
  /board       доска задач для нескольких агентов: add, run, show, apply, drop, rm
  /bot [имя|off|new <имя>]  бот со своей ролью, моделью и памятью   /bots  список ботов
  /listen [слово]  слушать микрофон и отзываться на слово (по умолчанию «агент»)
  /voice       сказать сообщение голосом   /talk  голосовой режим (говорите и слушайте)   /say [on|off]  читать ответы вслух
  /canvas      живая страница рядом с терминалом: графики, схемы, таблицы от агента (/canvas off)
  /buddy       глазки Klinch вкл/выкл      /model <имя|auto>  /models  /balance  /clear  /exit`;

export function parseArgs(argv) {
  const o = { cmd: null, args: [], prompt: null, model: null, yes: false, help: false, version: false };
  if (argv[0] === 'mcp' || argv[0] === 'plugin' || argv[0] === 'plugins') return { ...o, cmd: argv[0] === 'mcp' ? 'mcp' : 'plugin', args: argv.slice(1) };
  if (argv[0] === 'skills' || argv[0] === 'skill') return { ...o, cmd: 'skills', args: argv.slice(1) };
  if (argv[0] === 'hub') return { ...o, cmd: 'hub', args: argv.slice(1) };
  if (argv[0] === 'blame') return { ...o, cmd: 'blame', args: argv.slice(1) };
  if (argv[0] === 'automation' || argv[0] === 'automations') return { ...o, cmd: 'automation', args: argv.slice(1), yes: argv.includes('-y') };
  if (argv[0] === 'cloud') return { ...o, cmd: 'cloud', args: argv.slice(1) };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-p' || a === '--prompt') o.prompt = argv[++i] ?? '';
    else if (a === '-m' || a === '--model') o.model = argv[++i];
    else if (a === '-y' || a === '--yes') o.yes = true;
    else if (a === '-h' || a === '--help') o.help = true;
    else if (a === '-v' || a === '--version') o.version = true;
    else if (a === '-c' || a === '--continue') o.cont = true;
    else if (a === '--plan') o.plan = true;
    else if (a === '--effort') o.effort = argv[++i];
    else if (a === '--time-limit') o.timeLimit = argv[++i];
    else if (a === '--sandbox') o.sandbox = true;
    else if (a === '--no-sandbox') o.sandbox = false;
    else if (a === '--allow') (o.allow ||= []).push(argv[++i]);
    else if (a === '--output-format') o.format = argv[++i];
    else if (a === '--json') o.format = 'json';
    else if (a === '--bot') o.bot = argv[++i];
    else if (a === '--compare') o.compare = true;
    else if (a === '--moa') o.moa = true;
    else if (a === '--models') o.models = argv[++i];
    else if (a === '--apply') o.apply = true;
    else if (!o.cmd && !a.startsWith('-')) o.cmd = a;
    else o.args.push(a);
  }
  return o;
}

// `klinch import [claude|codex|openclaw] [-y]`: shows what will be moved, then moves it after «y».
async function importSettings(opts, env) {
  let plans;
  try { plans = planAll(opts.args[0], { cwd: process.cwd(), env }); } catch (e) { stderr.write(c.red(e.message) + '\n'); process.exitCode = 1; return; }
  const todo = plans.filter((p) => p.steps.length);
  if (!todo.length) return stdout.write(c.dim(`Переносить нечего: ${plans.map((p) => p.name).join(', ')} — ничего нового не найдено.\n`));
  for (const p of todo) { stdout.write(c.bold(`${p.name}\n`)); for (const s of p.steps) stdout.write(`  ${s.text}\n`); }
  if (!opts.yes) {
    if (!stdin.isTTY) return stdout.write(c.dim(`Перенести: klinch import ${opts.args[0] ? opts.args[0] + ' ' : ''}-y\n`));
    const rl = createInterface({ input: stdin, output: stdout });
    const a = await question(rl, 'Перенести? [y/N] '); rl.close();
    if (!/^(y|yes|д|да)$/i.test(a.trim())) return stdout.write('Ничего не изменено.\n');
  }
  let n = 0;
  for (const p of todo) for (const s of p.steps) { try { s.apply(); n++; } catch (e) { stderr.write(c.red(`${s.text}: ${e.message}`) + '\n'); } }
  stdout.write(c.green(`Готово: ${n} из ${todo.reduce((k, p) => k + p.steps.length, 0)}. Своё ничего не перезаписано.\n`));
}

function question(rl, q, signal) { return new Promise((r) => (signal ? rl.question(q, { signal }, r) : rl.question(q, r))); }

// Reads a line without echoing it (for the API key).
function secret(rl, q) {
  return new Promise((resolve) => {
    const prev = rl._writeToOutput;
    rl._writeToOutput = (s) => { if (s.startsWith(q)) stdout.write(q); };
    rl.question(q, (v) => { rl._writeToOutput = prev; stdout.write('\n'); resolve(v); });
  });
}

export async function main(argv = process.argv.slice(2), env = process.env) {
  const opts = parseArgs(argv);
  if (opts.help) return stdout.write(HELP + '\n');
  if (opts.version) return stdout.write(`klinch-code ${VERSION}\n`);
  const cfg = loadConfig(env);
  if (opts.model) cfg.model = opts.model;

  if (opts.cmd === 'login') return login(opts.args[0], cfg, env);
  if (opts.cmd === 'mcp') {
    try { for (const l of mcpCommand(opts.args, env)) stdout.write(l + '\n'); } catch (e) { stderr.write(c.red(e.message) + '\n'); process.exitCode = 1; }
    return;
  }
  if (opts.cmd === 'plugin') {
    try { for (const l of pluginCommand(opts.args, env)) stdout.write(l + '\n'); } catch (e) { stderr.write(c.red(e.message) + '\n'); process.exitCode = 1; }
    return;
  }
  if (opts.cmd === 'hub') {
    try { for (const l of await hubCommand(opts.args, createHub({ baseUrl: cfg.baseUrl, apiKey: cfg.apiKey, env }))) stdout.write(l + '\n'); } catch (e) { stderr.write(c.red(e.message) + '\n'); process.exitCode = 1; }
    return;
  }
  if (opts.cmd === 'skills') {
    try { for (const l of skillsCommand(opts.args, { env })) stdout.write(l + '\n'); } catch (e) { stderr.write(c.red(e.message) + '\n'); process.exitCode = 1; }
    return;
  }
  if (opts.cmd === 'import') return importSettings(opts, env);
  if (opts.cmd === 'blame') {
    try { for (const l of blameCommand(opts.args, { env, paint: c.cyan, dim: c.dim })) stdout.write(l + '\n'); } catch (e) { stderr.write(c.red(e.message) + '\n'); process.exitCode = 1; }
    return;
  }
  if (opts.cmd === 'automation' && opts.args[0] === 'fire') return fireAutomation(opts, env);
  if (opts.cmd === 'automation') {
    const schedule = { parseWhen, describe: describeWhen, add: (x) => addSchedule(loadSchedules(env), x, env) };
    try { for (const l of automationCommand(opts.args.filter((a) => a !== '-y'), { env, schedule })) stdout.write(l + '\n'); } catch (e) { stderr.write(c.red(e.message) + '\n'); process.exitCode = 1; }
    return;
  }
  if (opts.cmd === 'github') return github(opts, cfg, env);
  // Cloud agents (src/cloud.js): the task runs on the server, the agent opens the pull request itself.
  if (opts.cmd === 'cloud') {
    if (!cfg.apiKey) { stderr.write(`Ключ не задан: ${c.bold('klinch login')}\n`); process.exitCode = 1; return; }
    try { await createCloud({ baseUrl: cfg.baseUrl, apiKey: cfg.apiKey, env }).run(opts.args, { model: cfg.model }); } catch (e) { stderr.write(c.red(e.message) + '\n'); process.exitCode = 1; }
    return;
  }
  if (opts.cmd === 'schedule') {
    const [sub, id] = opts.args;
    const list = loadSchedules(env);
    if (sub === 'remove' || sub === 'rm') { stdout.write(removeSchedule(list, id, env) ? `Удалена ${id}\n` : c.red(`Нет задачи ${id}\n`)); return; }
    if (!list.length) return stdout.write(c.dim('Задач по расписанию нет. В чате: /loop каждый день в 9:00 <задача>\n'));
    for (const j of list) stdout.write(`${j.id}  ${describeWhen(j.spec)}  ${c.dim(j.cwd)}\n    ${j.prompt}  ${c.dim(`следующий запуск ${new Date(j.next).toLocaleString('ru-RU')}`)}\n`);
    return;
  }
  if (opts.cmd === 'logout') { saveConfig({ apiKey: undefined }, env); return stdout.write('Ключ удалён.\n'); }
  if (opts.cmd === 'model') {
    if (!opts.args[0]) return stdout.write(`Текущая модель: ${cfg.model}\n`);
    saveConfig({ model: opts.args[0] }, env); return stdout.write(`Модель по умолчанию: ${opts.args[0]}\n`);
  }
  if (opts.cmd === 'hook') {
    try { for (const l of hookCommand(opts.args, process.cwd())) stdout.write(l + '\n'); } catch (e) { stderr.write(c.red(e.message.split('\n')[0]) + '\n'); process.exitCode = 1; }
    return;
  }
  if (opts.cmd && !['chat', 'connect', 'daemon', 'review', 'acp'].includes(opts.cmd) && !['models', 'balance'].includes(opts.cmd)) {
    stderr.write(`Неизвестная команда: ${opts.cmd}\n${HELP}\n`); process.exitCode = 2; return;
  }

  // The editor (Zed, JetBrains) starts `klinch acp` itself; without a key it says so in its panel.
  if (opts.cmd === 'acp') return opts.args[0] === 'setup' ? acpSetup(env) : acpMain(env);
  if (!cfg.apiKey) {
    stdout.write(`Ключ Klinch не задан. Выполните ${c.bold('klinch login')} или задайте KLINCH_API_KEY.\nКлюч можно купить на ${cfg.baseUrl}\n`);
    process.exitCode = 1; return;
  }
  if (opts.cmd === 'connect') return connect(opts, cfg, env);
  if (opts.cmd === 'daemon') return daemon(opts, env);
  const client = withLocal(createClient(cfg), cfg);   // local:<model> runs on this computer (src/localmodels.js)

  try {
    if (opts.cmd === 'models') {
      const list = await client.models();
      for (const m of list) stdout.write(`${m.id.padEnd(22)} ${c.dim(m.local ? 'на этом компьютере, бесплатно' : m.id === 'auto' ? 'автовыбор: модель под каждый запрос' : `${m.provider}  вход ×${m.multipliers?.input ?? '?'}  выход ×${m.multipliers?.output ?? '?'}`)}\n`);
      return;
    }
    if (opts.cmd === 'balance') {
      const [a, u] = await Promise.all([client.account(), client.usage(30)]);
      stdout.write(`Баланс: ${c.bold(fmt(a.balance))} токенов\nЗа 30 дней: ${u.requests} запросов, списано ${fmt(u.spent)} токенов${u.runway_days != null ? `, хватит примерно на ${u.runway_days} дн.` : ''}\n`);
      return;
    }
    if (opts.cmd === 'review') return await reviewOnce(cfg, client, opts);
    if (opts.prompt != null) return await oneShot(opts.prompt, cfg, client, opts, env);
    return await repl(cfg, client, opts, env);
  } catch (e) {
    stderr.write(c.red(e.message) + '\n'); process.exitCode = 1;
  }
}

// `klinch acp setup`: registers the agent in JetBrains IDEs (~/.jetbrains/acp.json) and prints the lines for Zed.
// The command is the full path to node and this script: an editor started from the Dock has no npm folder in PATH.
function acpSetup(env) {
  const entry = { command: process.execPath, args: [process.argv[1], 'acp'], env: {} };
  const file = join(env.HOME || homedir(), '.jetbrains', 'acp.json');
  let j = {};
  try { j = JSON.parse(readFileSync(file, 'utf8')); } catch (e) { if (e.code !== 'ENOENT') { stderr.write(c.red(`Не читается ${file}: ${e.message}`) + '\n'); process.exitCode = 1; return; } }
  j.agent_servers = { ...(j.agent_servers || {}), 'Klinch Code': entry };
  mkdirSync(dirname(file), { recursive: true });
  writeFileSync(file, JSON.stringify(j, null, 2) + '\n');
  stdout.write(`${c.green('JetBrains:')} агент добавлен в ${file}. В IDE: AI Assistant → выбор агента → Klinch Code (IntelliJ, PyCharm, WebStorm 2025.3+).\n\n`);
  stdout.write(`${c.bold('Zed:')} добавьте в settings.json:\n${JSON.stringify({ agent_servers: { 'Klinch Code': { type: 'custom', ...entry } } }, null, 2)}\n`);
  stdout.write(c.dim('\nДругие редакторы с ACP: команда klinch acp (JSON-RPC через stdin/stdout).\n'));
}

// `klinch connect [папки…] [--reset] [--no-open]`: the cabinet's chat works in these folders («Работать локально»).
async function connect(opts, cfg, env) {
  const s = loadState(env);
  if (opts.args.includes('--reset')) { s.secret = randomBytes(32).toString('base64url'); stdout.write(c.yellow('Новая ссылка: браузеры, привязанные раньше, больше не смогут работать с этим компьютером.\n')); }
  const folders = opts.args.filter((a) => !a.startsWith('--'));
  try {
    for (const f of folders.length ? folders : [process.cwd()]) {
      try { stdout.write(`Папка: ${c.bold(addFolder(s, f))}\n`); }
      catch (e) { if (folders.length) throw e; }
    }
  } catch (e) { stderr.write(c.red(e.message) + '\n'); process.exitCode = 1; return; }
  saveState(s, env);
  const link = pairLink(cfg.baseUrl, s);
  stdout.write(`\n${c.bold('Klinch · работать локально')}\nОткройте эту ссылку в браузере, где вы вошли в кабинет (один раз на браузер):\n${c.cyan(link)}\n`);
  stdout.write(c.dim('Ссылка — ключ к этому компьютеру: не отправляйте её никому. Новая ссылка: klinch connect --reset\n'));
  stdout.write(`\nПривязанные папки: ${s.folders.length ? s.folders.map((f) => f.path).join(', ') : c.dim('пока нет, привяжите в чате: + → Работать локально → Привязать папку…')}\n`);
  if (!opts.args.includes('--no-open')) openBrowser(link);
  stdout.write(c.green('На связи.') + c.dim(' Пока окно открыто, чат на klinch.cloud работает с этими папками. Ctrl+C — отключить.\n\n'));
  const ctl = new AbortController();
  process.once('SIGINT', () => { ctl.abort(); stdout.write(c.dim('\nОтключено.\n')); });
  try { await serve({ baseUrl: cfg.baseUrl, apiKey: cfg.apiKey, env, signal: ctl.signal, state: s, log: (l) => stdout.write(c.dim(l) + '\n') }); }
  catch (e) { if (!ctl.signal.aborted) { stderr.write(c.red(e.message) + '\n'); process.exitCode = 1; } }
}

// The chat of a folder holds a lock while it is open: its scheduled tasks run there, and the daemon leaves them.
const lockPath = (cwd, env) => join(projectDir(cwd, env), 'chat.lock');
function chatOpen(cwd, env) {
  try { const pid = +readFileSync(lockPath(cwd, env), 'utf8'); process.kill(pid, 0); return pid !== process.pid; } catch { return false; }
}

// `klinch daemon [-y]`: runs due scheduled tasks and automations (src/automations.js) as `klinch -p` in their
// folders (actions that need a confirmation are skipped unless -y), output into ~/.klinch/logs. Folders with an open
// chat are left to that chat; webhooks are served here for every folder.
async function daemon(opts, env) {
  const logs = join(env.KLINCH_HOME || join(homedir(), '.klinch'), 'logs');
  mkdirSync(logs, { recursive: true, mode: 0o700 });
  stdout.write(`${c.bold('Klinch daemon')}: задачи по расписанию и автоматизации выполняются, пока окно открыто. Ctrl+C — стоп. Логи: ${logs}\n`);
  const running = new Set();
  const stamp = () => new Date().toLocaleString('ru-RU');
  const tick = () => {
    const list = loadSchedules(env);
    const due = takeDue(list.filter((j) => !chatOpen(j.cwd, env) && !running.has(j.id)), {}, env);
    for (const j of due) {
      const log = join(logs, `${j.id}.log`), fd = openSync(log, 'a');
      stdout.write(c.dim(`${stamp()}  ${j.id} в ${j.cwd}: ${j.prompt.slice(0, 80)}\n`));
      running.add(j.id);
      const child = spawn(process.execPath, [process.argv[1], '-p', j.prompt, ...(opts.yes ? ['-y'] : [])], { cwd: j.cwd, env, stdio: ['ignore', fd, fd] });
      child.on('close', (code) => { running.delete(j.id); if (code) stdout.write(c.red(`  ${j.id} завершилась с кодом ${code}, см. ${log}\n`)); });
    }
  };
  const fire = (j, e) => new Promise((resolve) => {
    const log = join(logs, `${j.id}.log`), fd = openSync(log, 'a');
    writeFileSync(fd, `\n=== ${stamp()} ${eventLabel(e)} ===\n`);
    stdout.write(c.cyan(`${stamp()}  ⚡ ${j.id} ${describeTrigger(j)} (${eventLabel(e)}) в ${j.cwd}\n`));
    const child = spawn(process.execPath, [process.argv[1], '-p', eventPrompt(j, e), ...(opts.yes ? ['-y'] : [])],
      { cwd: j.cwd, env: { ...env, KLINCH_AUTOMATION: j.id, KLINCH_TRIGGER: eventLabel(e) }, stdio: ['ignore', fd, fd] });
    const done = (code) => {
      updateAutomation(j.id, (cur) => ({ runs: (cur.runs || 0) + 1, last: Date.now(), lastCode: code || 0 }), env);
      if (code) stdout.write(c.red(`  ${j.id} завершилась с кодом ${code}, см. ${log}\n`));
      resolve();
    };
    child.on('close', done); child.on('error', () => done(1));
  });
  const engine = createEngine({ jobs: () => loadAutomations(env).filter((j) => !chatOpen(j.cwd, env)), fire, log: (l) => stdout.write(c.dim(l) + '\n') });
  let hooks = null, hooksTried = false;
  const ensureHooks = async () => {
    if (hooks || hooksTried || !loadAutomations(env).some((j) => j.on === 'webhook')) return;
    hooksTried = true;
    hooks = await listenHooks({ jobs: () => loadAutomations(env), run: engine.run, env, log: (l) => stdout.write(c.dim(`${stamp()}  ${l}`) + '\n') });
    if (hooks) stdout.write(c.dim(`Вебхуки: http://127.0.0.1:${hooks.address().port}/hook/<id>\n`));
    else { stdout.write(c.yellow('Порт вебхуков занят (открыт чат с автоматизацией?), попробую позже.\n')); setTimeout(() => { hooksTried = false; }, 60_000).unref?.(); }
  };
  tick(); engine.tick(); await ensureHooks();
  const t = setInterval(tick, 20_000);
  const t2 = setInterval(() => { try { engine.tick(); } catch { /* a folder is gone */ } ensureHooks(); }, 4000);
  await new Promise((r) => process.once('SIGINT', r));
  clearInterval(t); clearInterval(t2); engine.close(); hooks?.close();
  stdout.write(c.dim('\nОстановлено.\n'));
}

// `klinch automation fire <id> [текст]`: runs an automation now, here, with its output in the terminal.
async function fireAutomation(opts, env) {
  const [, id, ...text] = opts.args.filter((a) => a !== '-y');
  const j = loadAutomations(env).find((x) => x.id === id);
  if (!j) { stderr.write(c.red(id ? `Нет автоматизации ${id}\n` : 'Укажите id: klinch automation list\n')); process.exitCode = 1; return; }
  const e = { type: 'manual', text: text.join(' ') };
  const child = spawn(process.execPath, [process.argv[1], '-p', eventPrompt(j, e), ...(opts.yes ? ['-y'] : [])],
    { cwd: j.cwd, env: { ...env, KLINCH_AUTOMATION: j.id, KLINCH_TRIGGER: eventLabel(e) }, stdio: 'inherit' });
  const code = await new Promise((r) => { child.on('close', r); child.on('error', () => r(1)); });
  updateAutomation(j.id, (cur) => ({ runs: (cur.runs || 0) + 1, last: Date.now(), lastCode: code || 0 }), env);
  process.exitCode = code || 0;
}

// `klinch github install|workflow|review|respond` (src/github.js): the PR review bot and the agent behind the mention.
async function github(opts, cfg, env) {
  const [sub = '', ...rest] = opts.args;
  const flag = (f) => rest.includes(f);
  const cwd = process.cwd();
  if (sub === 'workflow') return stdout.write(gh.workflowYaml());
  if (sub === 'install') {
    const r = gh.install(cwd, { force: flag('--force') });
    if (!r.written) return stdout.write(`${r.file} уже есть. Перезаписать: ${gh.CMD} github install --force\n`);
    stdout.write(`${c.green('Готово:')} ${r.file}\nОсталось добавить секрет ${c.bold(`${gh.CMD.toUpperCase()}_API_KEY`)} (ваш ключ): Settings → Secrets and variables → Actions → New repository secret.\n`
      + `Чтобы агент сам открывал PR по issue: Settings → Actions → General → «Allow GitHub Actions to create and approve pull requests».\n`
      + `Потом закоммитьте файл. Каждый PR получит ревью, а ${gh.MENTION} в PR или issue запустит агента.\n`);
    return;
  }
  if (sub !== 'review' && sub !== 'security' && sub !== 'respond') {
    return stdout.write(`${gh.CMD} github install [--force]   записать .github/workflows/${gh.CMD}.yml
${gh.CMD} github workflow            показать этот файл
${gh.CMD} github review [--security] [--security-only] [--fail] [--dry-run] [N]   ревью PR (по умолчанию: PR события GitHub Actions)
${gh.CMD} github respond [--dry-run]   выполнить просьбу из ${gh.MENTION} (событие GitHub Actions)
Нужны ${gh.CMD.toUpperCase()}_API_KEY и GITHUB_TOKEN.\n`);
  }
  const event = gh.readEvent(env);
  const dryRun = flag('--dry-run');
  const log = (t) => stdout.write(c.dim(t) + '\n');
  if (!cfg.apiKey) {
    // A PR from a fork gets no secrets: no review, and no red check either.
    if (event.payload.pull_request?.head?.repo?.fork) { stdout.write(`::notice::Ключа ${gh.CMD.toUpperCase()}_API_KEY нет (PR из форка): ревью пропущено.\n`); return; }
    stderr.write(c.red(`Ключ не задан: добавьте секрет ${gh.CMD.toUpperCase()}_API_KEY в настройках репозитория.`) + '\n'); process.exitCode = 1; return;
  }
  const token = env.GITHUB_TOKEN || env.GH_TOKEN;
  if (!token && !dryRun) { stderr.write(c.red('Нет GITHUB_TOKEN: в workflow передайте GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}, локально без него — --dry-run (публичный репозиторий).') + '\n'); process.exitCode = 1; return; }
  const repo = gh.repoOf(env, event.payload, cwd);
  if (!repo) { stderr.write(c.red('Не понял, какой это репозиторий: задайте GITHUB_REPOSITORY=owner/repo.') + '\n'); process.exitCode = 1; return; }
  const client = withLocal(createClient(cfg), cfg);
  const rl = createInterface({ input: stdin, output: stderr });
  const o = { text() {}, endText() {}, toolStart() {}, thinking() {}, todos() {}, plan() {},
    tool: (p) => log('  ' + p.split('\n')[0]), sub: (l, p) => log(`  [${l}] ${p.split('\n')[0]}`), note: (n) => log('  · ' + n) };
  // The answer to a mention edits files and runs commands in the throwaway checkout without questions; the review
  // only reads, and leaves the project's MCP servers and hooks off (the PR's code can come from anyone).
  const s = await setup(cfg, client, { ...opts, yes: sub === 'respond', format: 'json' }, env, rl, o);
  const reviewer = (role) => s.spawn({ label: 'ревью', model: cfg.reviewModel || s.agent.model, cwd, readOnly: true, role, out: o });
  const d = { gh: gh.githubApi({ token, api: env.GITHUB_API_URL || undefined }), repo, event, cwd, env, log, dryRun,
    runUrl: gh.runUrlOf(env), reviewer, agent: s.agent, anyone: flag('--allow-anyone'), write: (t) => stdout.write(t) };
  try {
    if (sub === 'respond') await gh.respond(d);
    else {
      const kinds = sub === 'security' || flag('--security-only') ? ['security'] : flag('--security') ? ['bugs', 'security'] : ['bugs'];
      const number = +rest.find((a) => /^\d+$/.test(a)) || null;
      const res = await gh.review(d, { kinds, number });
      if (flag('--fail') && res.some((r) => r.findings.some((f) => f.severity === 'high'))) process.exitCode = 1;
    }
  } catch (e) { stderr.write(c.red(e.message) + '\n'); process.exitCode = 1; }
  finally { rl.close(); s.mcp.close(); killAllBackground(); }
}

async function login(keyArg, cfg, env) {
  const rl = createInterface({ input: stdin, output: stdout });
  const raw = keyArg || (await secret(rl, 'Ключ Klinch (kl_live_…): '));
  rl.close();
  // A paste can bring terminal escape codes, quotes, invisible spaces or the whole `export KLINCH_API_KEY=…` line:
  // take just the key.
  const key = /kl_(?:live|test)_[A-Za-z0-9_-]{8,}/.exec(String(raw))?.[0] || String(raw).replace(/[\s\u200b-\u200d\ufeff"'`]/g, '');
  if (!key) { stderr.write('Ключ пустой.\n'); process.exitCode = 1; return; }
  if (!key.startsWith('kl_')) { stderr.write(c.red(`Это не похоже на ключ Klinch: он начинается с kl_live_. Получено ${key.length} символов, начало «${key.slice(0, 4)}».`) + '\n'); process.exitCode = 1; return; }
  try {
    const a = await createClient({ ...cfg, apiKey: key }).account();
    saveConfig({ apiKey: key, baseUrl: cfg.baseUrl }, env);
    stdout.write(`${c.green('Готово.')} Ключ ${maskKey(key)} сохранён в ${configPath(env)}\nБаланс: ${c.bold(fmt(a.balance))} токенов. Запускайте ${c.bold('klinch')} в папке проекта.\n`);
  } catch (e) {
    stderr.write(c.red(e.message) + '\n');
    if (e instanceof ApiError && e.status === 401) stderr.write(c.dim(`Проверял ключ ${maskKey(key)} (${key.length} символов) на ${cfg.baseUrl}. Скопируйте его кнопкой «Скопировать ключ» в кабинете или передайте сразу: klinch login kl_live_…\n`));
    process.exitCode = 1;
  }
}

// `klinch review [--staged] [--strict] [--hook]`: Agent Review of the changes in this repository, outside the chat.
// --strict: exit code 1 when the review says «нужно исправить» (the pre-commit hook then stops the commit).
async function reviewOnce(cfg, client, opts) {
  const staged = opts.args.includes('--staged'), strict = opts.args.includes('--strict'), hook = opts.args.includes('--hook');
  let diff;
  try { diff = changesFor(process.cwd(), { staged }); } catch { stderr.write(c.red('Ревью смотрит изменения git: эта папка не в репозитории.\n')); process.exitCode = hook ? 0 : 1; return; }
  if (!diff.trim()) { if (!hook) stdout.write(c.dim(staged ? 'Нет изменений, добавленных в коммит (git add).\n' : 'Изменений нет.\n')); return; }
  stdout.write(c.bold('Agent Review') + c.dim(` · ${cfg.reviewModel || cfg.model} проверяет ${staged ? 'коммит' : 'изменения'}`) + '\n');
  try {
    const r = await reviewChanges({ client, model: cfg.reviewModel || cfg.model, cwd: process.cwd(), diff, out: makeOut() });
    if (r.verdict === 'fix' && strict) { stderr.write(c.red('Коммит остановлен: ревью нашло проблемы. Исправьте или: git commit --no-verify') + '\n'); process.exitCode = 1; }
  } catch (e) {
    // A broken review never blocks a commit.
    stderr.write(c.yellow(`Ревью не удалось: ${e.message}`) + '\n'); process.exitCode = hook ? 0 : 1;
  }
}

// Output sink shared by the REPL and one-shot mode.
function makeOut() {
  let inText = false, thinkAt = 0, timer = null;
  // «Думает… 12 с» while the model reasons (its reasoning is never printed), then «думал 12 с».
  const stopThink = () => {
    if (!thinkAt) return;
    clearInterval(timer); timer = null;
    const sec = Math.round((Date.now() - thinkAt) / 1000); thinkAt = 0;
    if (stdout.isTTY) stdout.write('\r\x1b[2K');
    if (sec >= 2) stdout.write(c.dim(`  · думал ${sec} с`) + '\n');
  };
  const end = () => { stopThink(); if (inText) stdout.write('\n'); inText = false; };
  return {
    thinking: () => {
      if (thinkAt || inText) return;
      thinkAt = Date.now();
      if (!stdout.isTTY) return;
      const draw = () => stdout.write('\r\x1b[2K' + c.dim(`  Думает… ${Math.round((Date.now() - thinkAt) / 1000)} с`));
      draw(); timer = setInterval(draw, 1000); timer.unref?.();
    },
    text: (t) => { stopThink(); inText = true; stdout.write(t); },
    endText: end,
    toolStart: () => {},
    tool: (p) => { end(); stdout.write(c.dim(`  ▸ ${p.split('\n')[0]}`) + '\n'); },
    sub: (label, p) => { end(); stdout.write(c.dim(`    ↳ ${label}: ${p.split('\n')[0].slice(0, 120)}`) + '\n'); },
    todos: (t) => { end(); stdout.write(c.cyan(t.split('\n').map((l) => '  ' + l).join('\n')) + '\n'); },
    plan: (p) => { end(); stdout.write('\n' + c.bold('План') + '\n' + p.trim() + '\n'); },
    note: (n) => { end(); stdout.write(c.dim(`  · ${n}`) + '\n'); },
  };
}

const usageLine = (u, a) => c.dim(`  · ${u ? `${fmt(u.input_tokens + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0))} вх / ${fmt(u.output_tokens)} вых` : ''}${a ? ` · баланс ${fmt(a.balance)} токенов` : ''}`);

/** A confirmation preview: the first line in yellow, a diff below it in red / green. */
export const paintPreview = (p) => p.split('\n').map((l, i) => (i === 0 ? c.yellow(l) : l.startsWith('+ ') ? c.green(l) : l.startsWith('- ') ? c.red(l) : l.startsWith('@@') ? c.cyan(l) : c.dim(l))).join('\n');

async function ask(rl, preview, o = {}, perm = null) {
  stdout.write('\n' + paintPreview(preview) + '\n');
  if (o.plan) {
    const v = (await question(rl, c.bold('Выполнять? [y/N] '))).trim().toLowerCase();
    return ['y', 'д', 'yes', 'да'].includes(v);
  }
  if (ask.always) return true;
  const rule = perm && o.tool ? suggestRule(o.tool, o.input) : null;
  // In VS Code the edit also opens as a diff there; «Принять» / «Отклонить» in the editor answers like y / n here.
  const change = perm?.ide && (o.tool === 'edit_file' || o.tool === 'write_file') ? proposedContent(perm.at?.() || perm.cwd, o.tool, o.input) : null;
  const view = change ? perm.ide.showDiff({ ...change, title: `${change.path} (Klinch: ${change.created ? 'новый файл' : 'правка'})` }) : null;
  const q = c.bold(`Выполнить? [y/N/a=всё в этой сессии${rule ? `/p=всегда ${rule} здесь` : ''}]${view ? c.dim(' (или в редакторе)') : ''} `);
  let v;
  if (view) {
    const ctl = new AbortController();
    v = await Promise.race([question(rl, q, ctl.signal), view.decision.then((d) => { ctl.abort(); stdout.write(c.dim(d === 'accept' ? 'принято в редакторе\n' : 'отклонено в редакторе\n')); return d === 'accept' ? 'y' : 'n'; })]);
    view.close();
  } else v = await question(rl, q);
  v = String(v).trim().toLowerCase();
  if (v === 'a' || v === 'в') { ask.always = true; return true; }
  if (rule && (v === 'p' || v === 'з')) {
    addRule(perm.cwd, rule, perm.env); perm.perms.allow.push(rule);
    stdout.write(c.dim(`  · запомнил: ${rule} в этой папке без вопросов (убрать: /permissions)\n`));
    return true;
  }
  return v === 'y' || v === 'д' || v === 'yes' || v === 'да';
}

async function askUserIn(rl, q, options) {
  stdout.write('\n' + c.bold(q) + '\n' + options.map((o, i) => `  ${i + 1}. ${o}`).join('\n') + (options.length ? '\n' : ''));
  const v = (await question(rl, c.cyan('Ответ: '))).trim();
  return options[+v - 1] || v;
}

// Klinch eyes beside the prompt (/buddy): calm while waiting, they react only while the agent answers.
const FACES = { idle: '(•‿•)', think: '(◔_◔)', work: '(•̀ᴗ•́)', happy: '(^‿^)', sad: '(•︵•)' };
const face = (k) => c.red(FACES[k]);

/** Skills, commands, instructions and MCP servers for the folder, then the agent. */
async function setup(cfg, client, opts, env, rl, out) {
  const cwd = process.cwd();
  const info = (t) => (opts.format && opts.format !== 'text' ? stderr : stdout).write(t);
  // The Curator, once a day: the agent's skills nobody used for a month go to the archive (no tokens, nothing deleted).
  const selfSkills = cfg.selfSkills !== false;
  if (selfSkills) {
    try { const moved = curate({ cwd, env, auto: true }); if (moved.length) info(c.dim(`Куратор убрал в архив неиспользуемые скиллы: ${moved.join(', ')} (вернуть: klinch skills restore <имя>)\n`)); } catch { /* read-only folder */ }
  }
  // What is turned on in the cabinet (skills, plugins) arrives here: one short request at start, quiet on failure.
  if (cfg.apiKey && cfg.hubSync !== false) {
    try {
      const { added, removed } = await createHub({ baseUrl: cfg.baseUrl, apiKey: cfg.apiKey, env, timeout: 4000 }).sync();
      if (added.length || removed.length) info(c.dim(`Из кабинета: ${[added.length && 'поставлено ' + added.join(', '), removed.length && 'убрано ' + removed.join(', ')].filter(Boolean).join('; ')}\n`));
    } catch { /* offline or an older site */ }
  }
  const skills = loadSkills(cwd, env), commands = loadCommands(cwd, env), instructions = loadInstructions(cwd, env);
  const agents = loadAgents(cwd, env), styles = loadOutputStyles(cwd, env), rules = loadRules(cwd, env);
  const diagnostics = cfg.diagnostics === false ? null : createDiagnostics(cwd, { env });
  // Semantic code index (src/codeindex.js): off with "codeIndex": false in the config or KLINCH_INDEX=0.
  const codeIndex = env.KLINCH_INDEX === '0' || cfg.codeIndex === false ? null
    : createCodeIndex({ cwd, env, embed: (texts, signal) => client.embeddings(texts, { model: EMBED_MODEL, dimensions: DIMS, signal }) });
  const jobs = [];   // this chat's repeating tasks (/loop, the schedule tool), plus the saved ones of the folder
  const style = cfg.outputStyle ? styles.find((x) => x.name === cfg.outputStyle) : null;
  const interactive = stdin.isTTY && rl;
  const mcp = await startServers({
    cwd, env,
    log: (l) => info(c.dim(l) + '\n'),
    allow: async (s) => {
      if (opts.yes) return true;
      if (!interactive) { info(c.dim(`MCP ${s.name} из ${s.file} пропущен: разрешите его в обычном запуске klinch.\n`)); return false; }
      const what = s.config.url || [s.config.command, ...(s.config.args || [])].join(' ');
      const v = (await question(rl, c.yellow(`Проект просит запустить MCP-сервер ${c.bold(s.name)}: ${what}\nРазрешить? [y/N] `))).trim().toLowerCase();
      return ['y', 'д', 'yes', 'да'].includes(v);
    },
  });
  // Hooks: the user's own run as is; a project's run only after the user allowed that exact config once.
  const hookConfigs = [];
  for (const h of loadHookConfigs(cwd, env)) {
    if (hooksTrusted(cwd, h, env)) { hookConfigs.push(h); continue; }
    let ok = !!opts.yes;
    if (!ok && interactive) {
      const cmds = Object.values(h.hooks).flat().flatMap((m) => (m?.hooks || []).map((x) => x.command)).filter(Boolean);
      const v = (await question(rl, c.yellow(`Проект задаёт хуки в ${h.file} (команды при работе агента):\n${cmds.map((x) => '  ' + x).join('\n')}\nРазрешить? [y/N] `))).trim().toLowerCase();
      ok = ['y', 'д', 'yes', 'да'].includes(v);
    } else if (!ok) info(c.dim(`Хуки из ${h.file} пропущены: разрешите их в обычном запуске klinch.\n`));
    if (ok) { trustHooks(cwd, h, env); hookConfigs.push(h); }
  }
  const hooks = hookConfigs.length ? createHooks(hookConfigs, { cwd, env, warn: (w) => info(c.dim(`  · ${w}`) + '\n') }) : noHooks;
  const started = hooks.count ? await hooks.run('SessionStart', { source: opts.cont ? 'resume' : 'startup' }) : null;
  // Permission rules; allow rules from the project's own files only after the user accepted them.
  const pa = projectAllow(cwd, env);
  let projectAllowed = pa.trusted;
  if (!pa.trusted && interactive && !opts.yes) {
    const v = (await question(rl, c.yellow(`Проект разрешает агенту без вопросов: ${pa.allow.join(', ')}\nПринять? [y/N] `))).trim().toLowerCase();
    if ((projectAllowed = ['y', 'д', 'yes', 'да'].includes(v))) trustProjectAllow(cwd, env);
  }
  const perms = loadPermissions(cwd, env, { extraAllow: opts.allow || [], projectAllowed });
  const quietRun = !interactive || (opts.format && opts.format !== 'text');
  const sandbox = makeSandbox(typeof opts.sandbox === 'boolean' && cfg.sandbox && typeof cfg.sandbox === 'object' ? { ...cfg.sandbox, enabled: opts.sandbox } : opts.sandbox ?? cfg.sandbox, info);
  const ide = interactive && !quietRun ? ideBridge(env) : null;
  // SOUL.md and named bots (src/bots.js): the bot's model and depth apply unless -m / --effort say otherwise.
  const soul = loadSoul(cwd, env), bots = loadBots(cwd, env);
  const holder = { bot: opts.bot ? bots.find((b) => b.name === String(opts.bot).toLowerCase()) || null : null };
  if (opts.bot && !holder.bot) info(c.yellow(`Нет бота ${opts.bot}: ${bots.length ? `есть ${bots.map((b) => b.name).join(', ')}` : 'создайте /bot new <имя>'}\n`));
  const personaFor = (b) => personaText({ soul, bot: b, env });
  const remember = rememberTool(() => holder.bot, env);
  const media = [...mediaTools({ client, env }), ...workspaceTools({ client })];   // pictures, files, canvas (src/media.js); Google and X (src/workspace.js)
  // AI blame (src/blame.js): who wrote each line. `trace` says which session and automation an edit belongs to.
  const trace = { session: () => `p${Date.now().toString(36)}`, automation: null, trigger: null };
  { const id = `p${Date.now().toString(36)}${randomBytes(2).toString('hex')}`; trace.session = () => id; }
  const attribute = cfg.blame === false ? null : (x) => recordEdit({ abs: x.abs, before: x.before, after: x.after, meta: {
    session: trace.session(), turn: x.turn, prompt: x.prompt, model: x.model, tool: x.tool, sub: x.sub,
    automation: trace.automation || env.KLINCH_AUTOMATION || null, trigger: trace.trigger || env.KLINCH_TRIGGER || null } }, env);
  const scheduleApi = { parseWhen, describe: describeWhen, add: (x) => addSchedule(jobs, x, env) };
  const allInstructions = [instructions, started?.context && `# Из хука SessionStart\n${started.context}`].filter(Boolean).join('\n\n');
  const agent = createAgent({
    client, model: (!opts.model && holder.bot?.model) || cfg.model, cwd, out, hooks, permissions: perms, persona: personaFor(holder.bot),
    // -y: confirmed without asking, but shown, so the log says what was done (a click, a typed text, a command).
    confirm: opts.yes ? async (p) => { const l = String(p).split('\n'); out.tool(l.slice(0, 6).join('\n') + (l.length > 6 ? `\n  … ещё ${l.length - 6} строк` : '')); return true; }
      : quietRun ? async (p) => { out.note?.(`без подтверждения пропущено: ${p.split('\n')[0]} (разрешите через --allow или -y)`); return false; }
      : (p, o) => ask(rl, p, o, { cwd, env, perms, ide, at: () => agent.cwd }),
    askUser: interactive && !quietRun ? (q, o) => askUserIn(rl, q, o) : null,
    extraTools: [...mcp.tools, scheduleTool(jobs, () => cwd, env), automationTool(() => cwd, env, scheduleApi), blameTool(env), remember, ...media], skills, attribute,
    skillStore: selfSkills ? { manage: (input, at) => manageSkill(input, { cwd: at, env }), reload: (at) => loadSkills(at, env), used: (n) => noteUse(n, env) } : null,
    instructions: allInstructions,
    repoMapInPrompt: env.KLINCH_REPO_MAP === '1' || cfg.repoMap === true,
    mode: opts.plan ? 'plan' : 'normal',
    sandbox, effort: opts.effort || holder.bot?.effort || cfg.effort, agents, rules, codeIndex, outputStyle: style?.prompt ? style : null, memory: cfg.memory !== false, env,
    diagnose: diagnostics ? (abs) => diagnostics.check(abs) : null,
    ...(cfg.maxTokens ? { maxTokens: cfg.maxTokens } : {}), ...(cfg.maxSteps ? { maxSteps: cfg.maxSteps } : {}),
    ...(cfg.eyes ? { eyes: cfg.eyes } : {}),
    ...(parseDuration(opts.timeLimit || cfg.timeLimit) ? { timeLimit: parseDuration(opts.timeLimit || cfg.timeLimit) } : {}),
    ...(cfg.compactAt ? { compactAt: cfg.compactAt, trimAt: Math.round(cfg.compactAt * 0.45) } : {}),
    // A long task asks before it goes on past the step limit; -y lets it go on, a script without a terminal stops.
    onStepLimit: opts.yes ? async () => true : quietRun ? null : async (n) => {
      const v = (await question(rl, c.yellow(`Агент сделал ${n} шагов подряд. Продолжать? [y/N] `))).trim().toLowerCase();
      return ['y', 'д', 'yes', 'да'].includes(v);
    },
  });
  if ((opts.effort || cfg.effort) && !EFFORTS.includes(opts.effort || cfg.effort)) info(c.dim(`  · глубина «${opts.effort || cfg.effort}» не знаю, есть: ${EFFORTS.join(', ')}\n`));
  // Language servers stop with the MCP servers.
  const closeMcp = mcp.close;
  mcp.close = () => { closeMcp(); diagnostics?.close(); };
  // More agents for /compare, /moa, /review and /board (src/multicli.js): same tools, rules and instructions, their
  // own model and folder. In their own copy of the repository edits need no question; commands are asked one at a
  // time, labelled with the agent.
  const queue = serial();
  const confirmFor = (label, isolated) => async (p, o = {}) => {
    if ((isolated && isEdit(o.tool)) || opts.yes || ask.always) return true;
    if (quietRun) { out.note?.(`[${label}] без подтверждения пропущено: ${p.split('\n')[0]} (разрешите через --allow или -y)`); return false; }
    return queue(() => ask(rl, `[${label}] ${p}`, o, { cwd, env, perms }));
  };
  const spawn = ({ model, cwd: dir, isolated = false, label = 'агент', persona, effort, readOnly = false, role = null, out: o }) => createAgent({
    client, model, cwd: dir, out: o, hooks, permissions: perms, confirm: confirmFor(label, isolated), askUser: null,
    extraTools: [...mcp.tools, ...media], skills, instructions: allInstructions, sandbox: agent.sandbox, agents, rules, env,
    diagnose: diagnostics ? (abs) => diagnostics.check(abs) : null,
    persona: persona ?? personaFor(null), effort: effort || agent.effort, subagent: readOnly ? 'explore' : null, role,
    maxSteps: readOnly ? 60 : 150, ...(cfg.maxTokens ? { maxTokens: cfg.maxTokens } : {}),
    ...(cfg.compactAt ? { compactAt: cfg.compactAt, trimAt: Math.round(cfg.compactAt * 0.45) } : {}),
  });
  return { agent, skills, commands, mcp, instructions, hooks, perms, agents, styles, jobs, rules, diagnostics, spawn, bots, holder, personaFor, codeIndex, trace };
}

/** The sandbox state for the agent from a config value; a warning when this computer has none. */
function makeSandbox(value, info = (t) => stdout.write(t)) {
  const st = sandboxSettings(value);
  if (!st.enabled) return { ...st, active: false };
  if (st.backend === 'ssh' && !st.host) { info(c.yellow('Песочнице ssh нужен компьютер: /sandbox ssh user@host. Команды будут спрашивать подтверждение.\n')); return { ...st, active: false }; }
  const d = detectSandbox({ backend: st.backend });
  if (!d.kind) { info(c.yellow(`Песочница недоступна: ${d.reason}. Команды будут спрашивать подтверждение.\n`)); return { ...st, active: false }; }
  return { ...st, active: true, kind: d.kind };
}

// `-p` mode. --output-format text (default) prints like the chat; json prints one object at the end;
// stream-json prints one JSON object per line as things happen. Without a terminal or in JSON mode actions that
// need confirmation are skipped unless allowed by -y, --allow or permission rules.
function jsonOut(stream) {
  const events = [];
  const emit = (e) => { events.push(e); if (stream) stdout.write(JSON.stringify(e) + '\n'); };
  let text = '';
  return {
    events,
    out: {
      text: (t) => { text += t; }, endText: () => { if (text) { emit({ type: 'text', text }); text = ''; } }, toolStart() {},
      tool: (p) => emit({ type: 'tool', call: p.split('\n')[0] }), sub: (l, p) => emit({ type: 'subagent', task: l, call: p.split('\n')[0] }),
      todos: (t) => emit({ type: 'todos', todos: t }), plan: (p) => emit({ type: 'plan', plan: p }), note: (n) => emit({ type: 'note', note: n }),
    },
  };
}

async function oneShot(prompt, cfg, client, opts, env) {
  const format = opts.format || 'text';
  if (!['text', 'json', 'stream-json'].includes(format)) { stderr.write(`--output-format: text, json или stream-json\n`); process.exitCode = 2; return; }
  const j = format === 'text' ? null : jsonOut(format === 'stream-json');
  const rl = createInterface({ input: stdin, output: j ? stderr : stdout });
  const o = j ? j.out : makeOut();
  const s = await setup(cfg, client, opts, env, rl, o);
  if (opts.compare || opts.moa) {
    if (j) { rl.close(); s.mcp.close(); stderr.write('--compare и --moa пока только с текстовым выводом\n'); process.exitCode = 2; return; }
    const m = multiCommands({ ...s, client, cfg, env, c, write: (t) => stdout.write(t), line: async () => (opts.apply ? '' : 'n'), busy: (fn) => fn(undefined),
      send: (content) => s.agent.ask(content), mainOut: o, getBot: () => s.holder.bot, setBot() {}, memoryOf: () => '', startCwd: process.cwd(), note() {} });
    try { await (opts.compare ? m.compare : m.moa)(`${opts.models || ''} ${prompt}`.trim()); }
    finally { rl.close(); s.mcp.close(); killAllBackground(); }
    return;
  }
  const started = Date.now();
  let msg = null, error = null;
  try {
    const { content } = withMentions(prompt, process.cwd());
    msg = await s.agent.ask(content);
  } catch (e) { error = e; }
  finally { rl.close(); s.mcp.close(); killAllBackground(); }
  const a = await client.account().catch(() => null);
  if (!j) {
    if (error) throw error;
    return stdout.write(usageLine(s.agent.lastUsage, a) + '\n');
  }
  const result = {
    type: 'result', is_error: !!error, result: error ? error.message : (msg?.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('').trim(),
    model: s.agent.model, num_turns: s.agent.steps, duration_ms: Date.now() - started, tool_calls: s.agent.calls,
    // Actions the agent wanted but nobody confirmed: allow them with -y or --allow, or the task is not fully done.
    permission_denials: s.agent.denied,
    usage: Object.keys(s.agent.totalUsage).length ? s.agent.totalUsage : null, balance: a?.balance ?? null,
  };
  stdout.write(JSON.stringify(result, null, format === 'json' ? 2 : 0) + '\n');
  if (error) process.exitCode = 1;
}

const git = (cwd, args) => execFileSync('git', args, { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();

async function repl(cfg, client, opts, env) {
  const rl = createInterface({ input: stdin, output: stdout, prompt: c.cyan('› ') });
  const input = rl[Symbol.asyncIterator](); // created now so lines typed (or piped) during startup are kept
  const out = makeOut();
  const startCwd = process.cwd();
  const { agent, skills, commands, mcp, instructions, hooks, perms, agents, styles, jobs, rules, diagnostics, spawn, bots, holder, personaFor, codeIndex, trace } = await setup(cfg, client, opts, env, rl, out);
  try { mkdirSync(projectDir(startCwd, env), { recursive: true, mode: 0o700 }); writeFileSync(lockPath(startCwd, env), String(process.pid)); } catch { /* read-only home */ }
  const plugins = loadPlugins(env);
  let sessionId = Date.now().toString(36) + randomBytes(3).toString('hex');
  trace.session = () => sessionId;
  let buddy = cfg.buddy !== false && !!stdout.isTTY;
  const setPrompt = () => rl.setPrompt((buddy ? face('idle') + ' ' : '') + (agent.mode === 'plan' ? c.yellow('план ') : agent.mode === 'debug' ? c.yellow('отладка ') : '') + c.cyan('› '));
  setPrompt();
  if (opts.cont) {
    const last = listSessions(startCwd, env)[0];
    if (last) { agent.messages.push(...last.messages); sessionId = last.id; stdout.write(c.dim(`Продолжаю чат «${last.title}» (${last.messages.length} сообщений).\n`)); }
    else stdout.write(c.dim('Прошлых чатов в этой папке нет, начинаю новый.\n'));
  }
  let account = await client.account();
  stdout.write(`${c.bold('Klinch Code')} ${c.dim(`· ${cfg.model} · ${startCwd}`)}\nБаланс: ${c.bold(fmt(account.balance))} токенов. ${c.dim('/help — команды, Ctrl+C — выход')}\n`);
  const extras = [
    mcp.servers.filter((x) => !x.error).map((x) => `${x.name} (${x.tools})`).join(', ') && `MCP: ${mcp.servers.filter((x) => !x.error).map((x) => `${x.name} (${x.tools})`).join(', ')}`,
    plugins.length && `плагины: ${plugins.map((x) => x.name).join(', ')}`, agents.length && `субагенты: ${agents.length}`,
    skills.length && `скиллы: ${skills.length}`, rules.length && `правила: ${rules.length}`, hooks.count && `хуки: ${hooks.count}`, commands.length && `команды: ${commands.map((x) => '/' + x.name).join(' ')}`,
    instructions && `инструкции: ${INSTRUCTION_FILES.filter((f) => instructions.includes(`(${f})`)).join(', ') || '~/.klinch/KLINCH.md'}`,
    agent.mode === 'plan' && 'режим плана',
    agent.effort && `мысли: ${agent.effort}`,
    agent.sandbox?.active && describeSandbox(agent.sandbox),
    holder.bot && `бот: ${holder.bot.name}`, !holder.bot && bots.length && `ботов: ${bots.length}`,
  ].filter(Boolean);
  if (extras.length) stdout.write(c.dim(extras.join(' · ')) + '\n');
  stdout.write('\n');

  let busy = false, ctl = null, images = [], statusOn = cfg.statusline !== false;
  const statusCmd = statusCommand(env);
  const status = (spent) => {
    if (!statusOn) return usageLine(agent.lastUsage, account);
    const i = { sessionId, cwd: agent.cwd, projectDir: startCwd, version: VERSION, model: agent.model, contextTokens: agent.contextTokens, compactAt: agent.compactAt,
      effort: agent.effort, mode: agent.mode, sandbox: agent.sandbox?.active, style: agent.outputStyle?.name, branch: gitBranch(agent.cwd), spent, balance: account?.balance };
    return customLine(statusCmd, i, env) ?? c.dim('  ' + builtinLine(i));
  };
  rl.on('SIGINT', () => { if (busy && ctl) { ctl.abort(); } else { stdout.write('\n'); rl.close(); } });
  rl.on('close', () => { clearInterval(timer); clearInterval(autoTimer); engine.close(); hookServer?.close(); try { unlinkSync(lockPath(startCwd, env)); } catch { /* gone */ } mcp.close(); killAllBackground(); closeCanvas(); stdout.write(c.dim('\nПока.\n')); });
  // Scheduled tasks of this folder: saved ones (re-read each time, the daemon or another chat may change them) and
  // this chat's /loop ones. A task that comes due while the agent works waits for it to finish.
  const tick = async () => {
    if (busy || rl.closed) return;
    const saved = loadSchedules(env).filter((j) => j.cwd === startCwd);
    const list = [...saved, ...jobs.filter((j) => !j.persist || !saved.some((x) => x.id === j.id))];
    const due = takeDue(list, { cwd: startCwd }, env);
    for (let i = jobs.length - 1; i >= 0; i--) if (!jobs[i].persist && !list.includes(jobs[i])) jobs.splice(i, 1);
    for (const j of due) {
      if (busy || rl.closed) break;
      stdout.write('\n' + c.cyan(`⏰ ${j.kind === 'heartbeat' ? 'пульс' : describeWhen(j.spec)}: ${j.kind === 'heartbeat' ? 'проверяю цель' : j.prompt}`) + '\n');
      await send(j.prompt, j.kind === 'heartbeat' ? 'пульс' : '⏰');
      if (!rl.closed) rl.prompt();
    }
  };
  const timer = setInterval(() => { tick().catch(() => {}); }, 15_000);
  timer.unref?.();
  // Automations of this folder (src/automations.js): commits and file changes are watched here while the chat is
  // open (the daemon leaves the folder to it); webhooks too, when no daemon holds the port.
  const mine = () => loadAutomations(env).filter((j) => j.cwd === startCwd);
  const fireHere = (j, e) => {
    stdout.write('\n' + c.cyan(`⚡ ${describeTrigger(j)} (${eventLabel(e)}): ${j.prompt}`) + '\n');
    return send(eventPrompt(j, e), '⚡', { automation: j.id, trigger: eventLabel(e) }).finally(() => {
      updateAutomation(j.id, (cur) => ({ runs: (cur.runs || 0) + 1, last: Date.now(), lastCode: 0 }), env);
      if (!rl.closed) rl.prompt();
    });
  };
  const engine = createEngine({ jobs: mine, fire: fireHere, log: (l) => stdout.write(c.dim(l) + '\n') });
  let hookServer = null;
  const autoTimer = setInterval(() => { try { engine.tick(); } catch { /* the folder is gone */ } }, 4000);
  autoTimer.unref?.();
  const startHooks = async () => { if (!hookServer && mine().some((j) => j.on === 'webhook')) hookServer = await listenHooks({ jobs: mine, run: engine.run, env }); };
  await startHooks();
  try { engine.tick(); } catch { /* not a git folder */ }

  // One answer at a time: design-mode picks from the browser arrive while the prompt waits for typing.
  let queue = Promise.resolve();
  const send = (content, label, meta) => { const p = queue.then(() => sendNow(content, label, meta)); queue = p.catch(() => {}); return p; };
  let designHooked = false;
  // Notes for the agent about what the user did outside the conversation (applied /compare variant…), sent with the
  // next message.
  const notes = [];
  async function sendNow(content, label, meta = null) {
    trace.automation = meta?.automation || null; trace.trigger = meta?.trigger || null;
    if (notes.length) { const n = notes.splice(0).join('\n'); content = typeof content === 'string' ? `${n}\n\n${content}` : [{ type: 'text', text: n }, ...content]; }
    busy = true; ctl = new AbortController();
    if (buddy) stdout.write(face('think') + c.dim(label ? ` ${label}` : '') + '\n');
    let ok = false;
    try {
      const before = account?.balance;
      await agent.ask(content, { signal: ctl.signal });
      ok = true;
      account = await client.account().catch(() => account);
      stdout.write((buddy ? face('happy') + ' ' : '') + status(before != null && account?.balance != null ? before - account.balance : null) + '\n');
    } catch (e) {
      out.endText();
      if (buddy) stdout.write(face('sad') + ' ');
      if (e.name === 'AbortError' || e.interrupted) stdout.write(c.dim('(прервано)\n'));
      else stdout.write(c.red(e.message) + '\n');
      if (e instanceof ApiError && e.status === 402) stdout.write(`Пополните баланс: ${cfg.baseUrl}/console\n`);
    }
    try { saveSession({ id: sessionId, cwd: startCwd, model: agent.model, messages: agent.messages }, env); } catch { /* disk full etc. */ }
    busy = false; ctl = null; trace.automation = null; trace.trigger = null;
    setPrompt();
    return ok;
  }

  const commandsTable = {
    async help() { stdout.write(HELP + '\n'); },
    async exit() { rl.close(); },
    async quit() { rl.close(); },
    async clear() { agent.reset(); sessionId = Date.now().toString(36) + randomBytes(3).toString('hex'); stdout.write(c.dim('История очищена.\n')); },
    async balance() { account = await client.account(); stdout.write(`Баланс: ${c.bold(fmt(account.balance))} токенов\n`); },
    async models() { for (const m of await client.models()) stdout.write(`${m.id === agent.model ? c.green('● ') : '  '}${m.id}\n`); },
    async model(name) {
      if (!name) return stdout.write(`Модель: ${agent.model}\n`);
      const list = await client.models();
      if (name !== 'auto' && !list.some((m) => m.id === name)) return stdout.write(c.red(`Нет такой модели. Список: /models\n`));
      agent.model = name; saveConfig({ model: name }, env); stdout.write(`Модель: ${c.bold(name)}\n`);
    },
    async plan() {
      agent.mode = agent.mode === 'plan' ? 'normal' : 'plan';
      stdout.write(agent.mode === 'plan' ? c.yellow('Режим плана: агент только изучает код и предлагает план, правки после вашего «да».\n') : c.dim('Режим плана выключен.\n'));
      setPrompt();
    },
    async todo() { stdout.write(agent.todos.length ? formatTodos(agent.todos) + '\n' : c.dim('Списка задач пока нет.\n')); },
    async context() {
      const t = agent.contextTokens, at = agent.compactAt, pct = at ? Math.min(100, Math.round((100 * t) / at)) : 0;
      // Rough split of what the history holds (characters / 4 ≈ tokens).
      const sizes = { 'системный промпт и инструменты': JSON.stringify([agent.system(), agent.tools().map(({ name, description, input_schema }) => ({ name, description, input_schema }))]).length, 'ваши сообщения и ответы': 0, 'выводы инструментов': 0 };
      for (const m of agent.messages) for (const b of typeof m.content === 'string' ? [{ type: 'text', text: m.content }] : m.content) {
        const n = JSON.stringify(b).length;
        sizes[b.type === 'tool_result' || b.type === 'tool_use' ? 'выводы инструментов' : 'ваши сообщения и ответы'] += n;
      }
      stdout.write(`Контекст: ${'█'.repeat(Math.round(pct / 5))}${'░'.repeat(20 - Math.round(pct / 5))} ${pct}%  ${fmt(t)} из ${fmt(at)} токенов до сжатия, ${agent.messages.length} сообщений\n`);
      for (const [label, n] of Object.entries(sizes)) stdout.write(c.dim(`  ${label}: ~${fmt(n / 4)} токенов\n`));
      stdout.write(c.dim('Старые длинные выводы сокращаются сами; сжать сейчас: /compact\n'));
    },
    async effort(arg) {
      const v = (arg || '').trim().toLowerCase();
      if (!v) return stdout.write(`Глубина размышлений: ${c.bold(agent.effort || 'auto')} ${c.dim(`(есть ${EFFORTS.join(', ')}, auto; «ultrathink» в сообщении — максимум на один запрос)`)}\n`);
      if (v !== 'auto' && v !== 'off' && !EFFORTS.includes(v)) return stdout.write(c.red(`Есть: ${EFFORTS.join(', ')}, auto\n`));
      agent.effort = v === 'auto' || v === 'off' ? null : v;
      saveConfig({ effort: agent.effort || undefined }, env);
      stdout.write(`Глубина размышлений: ${c.bold(agent.effort || 'auto')}${agent.effort === 'max' || agent.effort === 'high' ? c.dim(' (ответы дольше и дороже)') : ''}\n`);
    },
    async think(arg) { return commandsTable.effort(arg); },
    async sandbox(arg) {
      const raw = (arg || '').trim(), v = raw.toLowerCase(), cur = agent.sandbox || sandboxSettings(false);
      const [word, ...rest] = raw.split(/\s+/), w = (word || '').toLowerCase();
      const base = { enabled: !!cur.active, network: cur.network ?? 'allowlist', allowWrite: cur.allowWrite || [], allowHosts: cur.allowHosts || [], backend: cur.backend || 'local', image: cur.image, host: cur.host, port: cur.port, dir: cur.dir };
      let next = null;
      if (v === 'on' || v === 'вкл') next = { ...base, enabled: true };
      else if (v === 'off' || v === 'выкл') next = { ...base, enabled: false };
      else if (v === 'net on' || v === 'net off') next = { ...base, network: v === 'net on' };
      else if (v === 'net list' || v === 'net allowlist') next = { ...base, network: 'allowlist' };
      else if (!v) next = { ...base, enabled: !cur.active };
      else if (w === 'allow' || w === 'deny') {
        const hosts = rest.map((h) => h.toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '')).filter(Boolean);
        if (!hosts.length) return stdout.write(c.dim(`Открыты по умолчанию: реестры npm, PyPI, crates, Go, Maven, RubyGems и GitHub. Свои: ${base.allowHosts.join(', ') || 'нет'}\n/sandbox allow <адрес> (можно *.example.com), /sandbox deny <адрес>\n`));
        next = { ...base, allowHosts: w === 'allow' ? [...new Set([...base.allowHosts, ...hosts])] : base.allowHosts.filter((h) => !hosts.includes(h)) };
      } else if (w === 'docker') next = { ...base, enabled: true, backend: 'docker', image: rest[0] || base.image || DEFAULT_IMAGE };
      else if (w === 'ssh') {
        if (!rest[0] && !base.host) return stdout.write(c.red('/sandbox ssh user@host [папка там] [порт]\n'));
        next = { ...base, enabled: true, backend: 'ssh', host: rest[0] || base.host, dir: rest[1] || (rest[0] ? undefined : base.dir), port: rest[2] ? +rest[2] : rest[0] ? undefined : base.port };
      } else if (w === 'local') next = { ...base, enabled: true, backend: 'local' };
      else return stdout.write(c.red('/sandbox on | off | net on | net off | net list | allow <адрес> | docker [образ] | ssh user@host [папка] | local\n'));
      agent.sandbox = makeSandbox(sandboxConfig(next));
      saveConfig({ sandbox: sandboxConfig(next) }, env);
      const sb = agent.sandbox;
      const net = sb.network === true ? 'открыта' : sb.network === false ? 'выключена (/sandbox net list: только реестры пакетов)' : `только реестры пакетов и GitHub${sb.allowHosts?.length ? ` и ${sb.allowHosts.join(', ')}` : ''} (/sandbox allow <адрес>)`;
      stdout.write(!sb.active ? c.dim('Песочница выключена: команды снова спрашивают подтверждение.\n')
        : sb.kind === 'docker' ? c.green(`Песочница Docker (${sb.image}): каждая команда в новом контейнере, подключена только ${agent.cwd}, сеть ${net}.\n`)
        : sb.kind === 'ssh' ? c.green(`Песочница на ${sb.host}: перед командой проект копируется туда, после неё изменения возвращаются (node_modules и .venv остаются там).\n`)
        : sb.kind === 'lowil' ? c.green(`Песочница Windows включена: команды идут без вопросов, писать можно только в ${agent.cwd} и временную папку, сеть ${net}. Чтение файлов не ограничено.\n`)
        : c.green(`Песочница включена: команды идут без вопросов, писать только в ${agent.cwd} и временную папку, сеть ${net}.\n`));
    },
    async style(arg) {
      const name = (arg || '').trim().toLowerCase();
      if (!name) {
        for (const x of styles) stdout.write(`${(agent.outputStyle?.name || 'default') === x.name ? c.green('● ') : '  '}${c.bold(x.name)} ${c.dim(x.description)}\n`);
        return stdout.write(c.dim('Выбрать: /style <имя>. Свой стиль: .klinch/output-styles/<имя>.md (или .claude/output-styles)\n'));
      }
      const x = styles.find((y) => y.name === name);
      if (!x) return stdout.write(c.red(`Нет стиля ${name}. Список: /style\n`));
      agent.outputStyle = x.prompt ? x : null;
      saveConfig({ outputStyle: x.prompt ? x.name : undefined }, env);
      stdout.write(`Стиль ответов: ${c.bold(x.name)}\n`);
    },
    async agents() {
      if (!agents.length) return stdout.write(c.dim('Своих субагентов нет. Субагент: .klinch/agents/<имя>.md или .claude/agents/<имя>.md (name, description, tools в начале файла).\n'));
      for (const x of agents) stdout.write(`  ${c.bold(x.name)} ${c.dim((x.readOnly ? '[только чтение] ' : '') + x.description)}\n`);
    },
    async index() {
      if (!codeIndex) return stdout.write(c.dim('Индекс кода выключен ("codeIndex": false в ~/.klinch/config.json или KLINCH_INDEX=0).\n'));
      stdout.write(c.dim('Индексирую проект…\n'));
      const st = await codeIndex.update();
      stdout.write(`Индекс кода: ${describeIndex(st)}${codeIndex.semantic ? '' : c.dim(' · поиск по смыслу сейчас недоступен, работает по словам')}\n`);
    },
    async rules() {
      if (!rules.length) return stdout.write(c.dim('Правил нет. Правило: .klinch/rules/<имя>.md (или .cursor/rules/*.mdc) с description, globs, alwaysApply в начале файла.\n'));
      for (const x of rules) stdout.write(`  ${c.bold(x.name)} ${c.dim(x.always ? '[всегда]' : x.globs.length ? `[${x.globs.join(', ')}]` : '[по теме]')} ${c.dim(x.description)}\n`);
    },
    async plugins() {
      if (!plugins.length) return stdout.write(c.dim('Плагинов нет. Поставить: klinch plugin add <git или папка>\n'));
      for (const x of plugins) stdout.write(`  ${c.bold(x.name)}${x.version ? ' ' + x.version : ''} ${c.dim(x.description)}\n`);
    },
    async memory(arg) {
      const [sub, ...rest] = (arg || '').trim().split(/\s+/);
      if (sub === 'add' && rest.length) return stdout.write(editMemory({ action: 'add', text: rest.join(' ') }, startCwd, env) + '\n');
      if (sub === 'user' && rest.length) return stdout.write(editMemory({ action: 'add', scope: 'user', text: rest.join(' ') }, startCwd, env) + '\n');
      if (sub === 'remove' && rest.length) { for (const sc of ['project', 'user']) { try { return stdout.write(editMemory({ action: 'remove', scope: sc, old: rest.join(' ') }, startCwd, env) + '\n'); } catch { /* try the other one */ } } return stdout.write(c.red('Такой записи нет\n')); }
      const u = readMemory('user', startCwd, env).trim(), p = readMemory('project', startCwd, env).trim();
      stdout.write(`${c.bold('О вас')} ${c.dim(memoryPath('user', startCwd, env))}\n${u || c.dim('пусто')}\n\n${c.bold('Этот проект')} ${c.dim(memoryPath('project', startCwd, env))}\n${p || c.dim('пусто')}\n`);
      stdout.write(c.dim('Агент дополняет память сам. Вручную: # текст (проект), /memory user <текст>, /memory remove <часть строки>\n'));
    },
    async goal(arg) {
      const v = (arg || '').trim();
      if (!v) { const g = readGoal(startCwd, env); return stdout.write(g ? `Цель: ${c.bold(g)}\n${c.dim('Сменить: /goal <текст>, убрать: /goal clear, двигаться самому: /heartbeat 30m')}\n` : c.dim('Цели нет. /goal <текст>: агент держит её в каждой задаче.\n')); }
      if (v === 'clear' || v === 'убрать') { setGoal(startCwd, '', env); return stdout.write(c.dim('Цель убрана.\n')); }
      setGoal(startCwd, v, env); stdout.write(c.green(`Цель проекта: ${v}\n`));
    },
    async loop(arg) {
      const v = (arg || '').trim();
      const mine = () => [...loadSchedules(env).filter((j) => j.cwd === startCwd), ...jobs.filter((j) => !j.persist)];
      if (!v) {
        const l = mine();
        if (!l.length) return stdout.write(c.dim('Повторов нет. /loop каждые 10 минут <задача>, /loop каждый день в 9:00 <задача>, /loop 0 9 * * 1-5 <задача>\n'));
        for (const j of l) stdout.write(`  ${j.id}  ${describeWhen(j.spec)}${j.persist ? '' : c.dim(' (пока открыт чат)')}  ${j.prompt}\n`);
        return stdout.write(c.dim('Остановить: /loop stop <id> (или /loop stop — все)\n'));
      }
      const [w, id] = v.split(/\s+/);
      if (w === 'stop' || w === 'стоп') {
        const ids = id ? [id] : mine().map((j) => j.id);
        for (const x of ids) { removeSchedule(jobs, x, env); const disk = loadSchedules(env); if (disk.some((j) => j.id === x)) removeSchedule(disk, x, env); }
        return stdout.write(c.dim(`Остановлено: ${ids.join(', ') || 'нечего'}\n`));
      }
      const p = parseWhen(v);
      if (!p || !p.prompt) return stdout.write(c.red('Не понял. Пример: /loop каждые 10 минут проверь тесты  ·  /loop 5m …  ·  /loop каждый день в 9:00 …\n'));
      // Every N minutes/hours while the chat is open; a daily/cron or a one-off task is saved (runs via klinch daemon too).
      const persist = !p.spec.every || p.spec.every >= 24 * 3600_000;
      const j = addSchedule(jobs, { cwd: startCwd, spec: p.spec, prompt: p.prompt, persist }, env);
      stdout.write(c.green(`Задача ${j.id}: ${describeWhen(j.spec)} — ${j.prompt}`) + c.dim(`\nПервый запуск ${new Date(j.next).toLocaleString('ru-RU')}.${persist ? ' Сохранена: выполнится и без чата, если запущен klinch daemon.' : ' Пока открыт чат.'}\n`));
    },
    async automation(arg) {
      const v = (arg || '').trim();
      try {
        if (!v || /^(list|ls|список)$/i.test(v)) { for (const l of automationCommand(['list'], { cwd: startCwd, env })) stdout.write(l + '\n'); return; }
        const [w, ...rest] = v.split(/\s+/);
        if (/^(fire|run|запусти)$/i.test(w)) {
          const j = mine().find((x) => x.id === rest[0]);
          if (!j) return stdout.write(c.red(`Нет автоматизации ${rest[0] || ''} в этой папке\n`));
          return void (await fireHere(j, { type: 'manual', text: rest.slice(1).join(' ') }));
        }
        const sub = { stop: 'remove', rm: 'remove', remove: 'remove', delete: 'remove', off: 'off', on: 'on', token: 'token' }[w.toLowerCase()];
        const lines = sub ? automationCommand([sub, ...rest], { cwd: startCwd, env })
          : automationCommand(['add', v], { cwd: startCwd, env, schedule: { parseWhen, describe: describeWhen, add: (x) => addSchedule(jobs, { ...x, persist: true }, env) } });
        stdout.write((sub ? lines.join('\n') : c.green(lines[0]) + (lines.length > 1 ? '\n' + c.dim(lines.slice(1).join('\n')) : '')) + '\n');
        if (!sub) { await startHooks(); engine.tick(); }
      } catch (e) { stdout.write(c.red(e.message) + '\n'); }
    },
    async automations(arg) { return commandsTable.automation(arg); },
    async blame(arg) {
      const args = (arg || '').trim() ? (arg || '').trim().split(/\s+/) : ['--stats'];
      try { for (const l of blameCommand(args, { cwd: agent.cwd, env, paint: c.cyan, dim: c.dim })) stdout.write(l + '\n'); } catch (e) { stdout.write(c.red(e.message) + '\n'); }
    },
    async heartbeat(arg) {
      const v = (arg || '').trim();
      const cur = jobs.find((j) => j.kind === 'heartbeat');
      if (v === 'stop' || v === 'off' || v === 'стоп') { if (cur) removeSchedule(jobs, cur.id, env); return stdout.write(c.dim('Пульс выключен.\n')); }
      if (!readGoal(startCwd, env)) return stdout.write(c.yellow('Сначала задайте цель: /goal <что нужно получить>\n'));
      const p = parseWhen((v || '30m') + ' x');
      if (!p?.spec.every) return stdout.write(c.red('Интервал: /heartbeat 30m, /heartbeat каждый час\n'));
      if (cur) removeSchedule(jobs, cur.id, env);
      const j = addSchedule(jobs, { cwd: startCwd, spec: p.spec, prompt: HEARTBEAT_PROMPT, persist: false, kind: 'heartbeat' }, env);
      stdout.write(c.green(`Пульс ${describeWhen(j.spec)}: агент проверяет цель и делает следующий шаг. Стоп: /heartbeat stop\n`));
    },
    async debug(arg) {
      const v = (arg || '').trim();
      if (!v || v === 'off' || v === 'выкл') {
        agent.mode = !v && agent.mode !== 'debug' ? 'debug' : 'normal'; setPrompt();
        return stdout.write(agent.mode === 'debug' ? c.yellow('Режим отладки: опишите баг. Агент добавит временные логи, запустит, найдёт причину по выводу и уберёт логи.\n') : c.dim('Режим отладки выключен.\n'));
      }
      const prev = agent.mode; agent.mode = 'debug'; setPrompt();
      try { await send(v, 'отладка'); } finally { agent.mode = prev === 'debug' ? 'normal' : prev; setPrompt(); }
    },
    async diagnostics() {
      if (!diagnostics) return stdout.write(c.dim('Диагностика выключена ("diagnostics": false в ~/.klinch/config.json).\n'));
      const on = diagnostics.servers();
      stdout.write(`После каждой правки файл проверяет ${on.length ? `языковой сервер: ${on.join(', ')}` : 'проверка синтаксиса (языковой сервер ещё не запускался или не установлен)'}.\n`);
      stdout.write(c.dim('Поддерживаются: typescript-language-server, pyright / pylsp, gopls, rust-analyzer, clangd, solargraph, intelephense (из node_modules/.bin или PATH).\n'));
    },
    async statusline() { statusOn = !statusOn; saveConfig({ statusline: statusOn ? undefined : false }, env); stdout.write(statusOn ? status(null) + '\n' : c.dim('Строка состояния выключена.\n')); },
    async compact() {
      busy = true; ctl = new AbortController();
      try { stdout.write(c.dim('Сжимаю историю…\n')); if (await agent.compact(ctl.signal)) stdout.write(c.green('Готово: история заменена конспектом.\n')); else stdout.write(c.dim('Сжимать пока нечего.\n')); }
      finally { busy = false; ctl = null; }
    },
    async init() {
      await send('Изучи этот проект (repo_map, ключевые файлы, package.json / Makefile / README) и создай в корне файл KLINCH.md для будущих сессий: что это за проект, как установить, собрать, запустить и проверить (точные команды), структура папок, соглашения по коду и важные подводные камни. Коротко, без воды. Если KLINCH.md уже есть, дополни его.', 'изучаю проект');
    },
    async resume(arg) {
      const list = listSessions(startCwd, env).filter((x) => x.id !== sessionId);
      if (!list.length) return stdout.write(c.dim('Прошлых чатов в этой папке нет.\n'));
      if (!arg) {
        list.slice(0, 10).forEach((x, i) => stdout.write(`  ${i + 1}. ${x.title || '(без текста)'} ${c.dim(new Date(x.updated).toLocaleString('ru-RU'))}\n`));
        return stdout.write(c.dim('Открыть: /resume <номер>\n'));
      }
      const pick = list[+arg - 1];
      if (!pick) return stdout.write(c.red('Нет такого номера.\n'));
      agent.reset(); agent.messages.push(...pick.messages); sessionId = pick.id;
      stdout.write(c.green(`Продолжаю «${pick.title}».\n`));
    },
    async mcp() {
      if (!mcp.servers.length) return stdout.write(c.dim('MCP-серверов нет. Добавить: klinch mcp add <имя> -- <команда>  (или .mcp.json в проекте)\n'));
      for (const x of mcp.servers) stdout.write(`  ${x.error ? c.red('✗') : c.green('●')} ${x.name.padEnd(16)} ${x.error ? c.red(x.error) : `${x.tools} инструментов`} ${c.dim(x.source === 'user' ? '(ваш)' : '(из проекта)')}\n`);
    },
    async skills() {
      if (!skills.length && !commands.length) return stdout.write(c.dim('Скиллов и своих команд нет. Скилл: .klinch/skills/<имя>/SKILL.md, команда: .klinch/commands/<имя>.md\n'));
      const mine = new Set(agentSkills(agent.cwd, env).map((x) => x.name));
      for (const x of skills) stdout.write(`  ${c.bold(x.name)}${mine.has(x.name) ? c.cyan(' [агент]') : ''} ${c.dim(x.description)}\n`);
      for (const x of commands) stdout.write(`  ${c.bold('/' + x.name)} ${c.dim(x.description)}\n`);
    },
    async hub(arg) {
      for (const l of await hubCommand((arg || '').split(/\s+/).filter(Boolean), createHub({ baseUrl: cfg.baseUrl, apiKey: cfg.apiKey, env }))) stdout.write(l + '\n');
      skills.splice(0, skills.length, ...loadSkills(agent.cwd, env));
    },
    async curator() {
      const moved = curate({ cwd: agent.cwd, env });
      if (moved.length) stdout.write(c.dim(`В архив (давно не использовались): ${moved.join(', ')}\n`));
      skills.splice(0, skills.length, ...loadSkills(agent.cwd, env));
      if (!agentSkills(agent.cwd, env).length) return stdout.write(c.dim('Своих скиллов у агента пока нет: он сохраняет их после непростых задач.\n'));
      await send(CURATOR_PROMPT, 'куратор скиллов');
    },
    async repomap(focus) { const r = buildRepoMap(agent.cwd, { focus }); stdout.write(r.text + '\n' + c.dim(`(${r.files} файлов кода)\n`)); },
    async paste() {
      const buf = clipboardImage();
      if (!buf) return stdout.write(c.red('В буфере обмена нет картинки (Linux: нужен wl-paste или xclip).\n'));
      if (buf.length > 5 * 1024 * 1024) return stdout.write(c.red('Картинка больше 5 МБ.\n'));
      images.push(imageBlock(buf)); stdout.write(c.green(`Картинка прикреплена (${Math.round(buf.length / 1024)} КБ), уйдёт со следующим сообщением.\n`));
    },
    async undo() {
      const cps = agent.checkpoints();
      if (!cps.length) return stdout.write(c.dim('Откатывать нечего.\n'));
      const files = agent.rewind(cps.length);
      stdout.write(c.green(`Откатил последний запрос «${cps.at(-1).prompt.slice(0, 60)}»`) + (files.length ? `: ${files.map((f) => f.replace(agent.cwd + '/', '')).join(', ')}` : ', файлов он не менял') + '\n' + c.dim('Изменения от команд shell не откатываются.\n'));
    },
    async rewind(arg) {
      const cps = agent.checkpoints();
      if (!cps.length) return stdout.write(c.dim('Откатывать нечего.\n'));
      if (!arg) {
        cps.forEach((x) => stdout.write(`  ${x.n}. ${x.prompt.replace(/\s+/g, ' ').slice(0, 70)} ${c.dim(x.files.length ? `(${x.files.length} файл.)` : '')}\n`));
        return stdout.write(c.dim('Вернуться к состоянию до запроса N (файлы и чат): /rewind N\n'));
      }
      const files = agent.rewind(+arg);
      stdout.write(c.green(`Вернул всё как было до запроса ${arg}.`) + (files.length ? ` Файлы: ${files.map((f) => f.replace(agent.cwd + '/', '')).join(', ')}` : '') + '\n');
    },
    async permissions(arg) {
      const [cmd, ...rest] = arg.split(/\s+/);
      if (cmd === 'allow' && rest.length) { const r = rest.join(' '); addRule(startCwd, r, env); perms.allow.push(r); return stdout.write(`Разрешено здесь: ${r}\n`); }
      if (cmd === 'remove' && rest.length) {
        const r = rest.join(' '), file = join(env.KLINCH_HOME || join(homedir(), '.klinch'), 'permissions.json');
        let p = {}; try { p = JSON.parse(readFileSync(file, 'utf8')); } catch { /* none */ }
        if (p.projects?.[startCwd]) { p.projects[startCwd] = p.projects[startCwd].filter((x) => x !== r); writeFileSync(file, JSON.stringify(p, null, 2) + '\n', { mode: 0o600 }); }
        const i = perms.allow.indexOf(r); if (i >= 0) perms.allow.splice(i, 1);
        return stdout.write(`Убрано: ${r}\n`);
      }
      stdout.write(`Без вопросов: ${perms.allow.length ? perms.allow.join(', ') : c.dim('ничего')}\nЗапрещено: ${perms.deny.length ? perms.deny.join(', ') : c.dim('ничего')}\n`);
      stdout.write(c.dim('Добавить: /permissions allow shell(npm test:*)   убрать: /permissions remove <правило>\n'));
    },
    async hooks() {
      if (!hooks.count) return stdout.write(c.dim('Хуков нет. Настройка: ~/.klinch/settings.json или .klinch/settings.json, формат как у Claude Code ("hooks": { "PreToolUse": [...] }).\n'));
      for (const h of hooks.configs) for (const [ev, list] of Object.entries(h.hooks)) for (const m of list || []) for (const x of m?.hooks || []) stdout.write(`  ${c.bold(ev)}${m.matcher ? ` [${m.matcher}]` : ''} ${x.command} ${c.dim('(' + h.file + ')')}\n`);
    },
    async tasks(arg) {
      const [cmd, id] = arg.split(/\s+/);
      if (cmd === 'kill' && id) { const j = BACKGROUND.get(id); if (!j) return stdout.write(c.red(`Нет ${id}\n`)); killBackground(j); return stdout.write(`Остановлено: ${id}\n`); }
      if (!BACKGROUND.size) return stdout.write(c.dim('Фоновых команд нет. Агент запускает их сам (сервер, watch), остановить: /tasks kill <id>\n'));
      for (const j of BACKGROUND.values()) stdout.write(`  ${j.code === null ? c.green('●') : c.dim('○')} ${j.id}  $ ${j.command} ${c.dim(j.code === null ? 'работает' : 'завершилась')}\n`);
      if (cmd === 'out' && id && BACKGROUND.get(id)) stdout.write(BACKGROUND.get(id).out.slice(-4000) + '\n');
    },
    async design(arg) {
      if (['off', 'stop', 'выкл'].includes(arg)) { await stopDesign(); return stdout.write('Режим дизайна выключен.\n'); }
      if (arg === 'close') { await closeBrowser(); return stdout.write('Браузер закрыт.\n'); }
      const url = await startDesign({ url: arg || undefined, env });
      if (!designHooked) {
        designHooked = true;
        onPick((p) => {
          if (p.exit) { stdout.write(c.dim(`\nРежим дизайна ${p.closed ? 'закрыт вместе с браузером' : 'выключен'}.\n`)); return rl.prompt(); }
          stdout.write(`\n${c.cyan('из браузера')} ${c.dim(p.selector)}\n  ${p.instruction}\n`);
          pickToContent(p).then((content) => send(content, 'правка из браузера')).catch((e) => stdout.write(c.red(e.message) + '\n'))
            .finally(() => { stdout.write('\n'); if (!rl.closed) rl.prompt(); });
        });
      }
      if (url === 'about:blank') return stdout.write(c.yellow('Окно открыто, но страница пустая. Укажите адрес: /design localhost:3000\n'));
      stdout.write(c.green(`Режим дизайна: ${url}\n`) + c.dim('В окне браузера кликните элемент и напишите, что изменить: агент поправит код. Выйти: кнопка «Выйти» или /design off\n'));
    },
    async say(arg) {
      sayOn = arg === 'on' ? true : arg === 'off' ? false : !sayOn;
      saveConfig({ say: sayOn || undefined }, env);
      stdout.write(sayOn ? `Читаю ответы вслух${c.dim(' (озвучка тратит баланс; выключить: /say off)')}\n` : c.dim('Ответы больше не озвучиваю.\n'));
    },
    async voice() { await voiceTurn(); },
    async listen(arg) {
      const word = (arg || '').trim() || cfg.wakeWord || 'агент';
      if (arg?.trim()) { saveConfig({ wakeWord: word }, env); cfg.wakeWord = word; }
      stdout.write(`Слушаю. Скажите «${c.bold(word)}» и просьбу, например «${word}, запусти тесты». ${c.dim('Ctrl+C — перестать слушать. Тишина не тратит ни баланс, ни лимит голоса.')}\n`);
      while (!rl.closed) {
        let req;
        try {
          req = await busyRun((signal) => waitForWake({ word, signal, threshold: cfg.voiceThreshold || 600, hear: (w) => transcribe(client, w),
            onState: (st) => stdout.write(st === 'heard' ? c.red('● ') + c.bold('Слушаю…') + '\n' : c.dim('  не расслышал, жду слово дальше\n')) }));
        } catch (e) { if (!e.interrupted && e.name !== 'AbortError') stdout.write(c.red(e.message) + '\n'); break; }
        stdout.write(c.cyan('› ') + req + '\n');
        await send(withMentions(req, agent.cwd, images.splice(0)).content);
        await sayLast();
      }
      stdout.write(c.dim('Больше не слушаю.\n'));
    },
    async talk() {
      stdout.write(c.dim('Голосовой режим: говорите, Enter — отправить; пустая запись или Ctrl+C — выход.\n'));
      while (!rl.closed && await voiceTurn(true)) { /* next turn */ }
      stdout.write(c.dim('Голосовой режим выключен.\n'));
    },
    async canvas(arg) {
      if (arg === 'off') { closeCanvas(); return stdout.write(c.dim('Canvas закрыт.\n')); }
      const url = canvasUrl() || await showCanvas(htmlPage('Canvas', '<p style="color:#999">Здесь агент покажет графики, схемы и таблицы. Попросите, например: «нарисуй схему модулей на canvas».</p>'), { open: false });
      openBrowser(url); stdout.write(`Canvas: ${c.cyan(url)}${c.dim(' (агент обновляет его инструментом canvas; закрыть: /canvas off)')}\n`);
    },
    async buddy() { buddy = !buddy; saveConfig({ buddy }, env); stdout.write(buddy ? `${face('happy')} Привет!\n` : c.dim('Глазки спрятаны.\n')); setPrompt(); },
    async worktree(arg) {
      if (!arg) { stdout.write(git(agent.cwd, ['worktree', 'list']) + '\n' + c.dim(`Сейчас: ${agent.cwd}\n`)); return; }
      if (arg === 'exit') { agent.cwd = startCwd; return stdout.write(`Вернулся в ${startCwd}\n`); }
      const name = arg.replace(/[^A-Za-z0-9._-]+/g, '-').slice(0, 40);
      const top = git(startCwd, ['rev-parse', '--show-toplevel']);
      const path = join(dirname(top), `${basename(top)}-${name}`), branch = `klinch/${name}`;
      try { git(top, ['worktree', 'add', '-b', branch, path]); } catch { git(top, ['worktree', 'add', path, branch]); }
      agent.cwd = path;
      stdout.write(c.green(`Работаю в отдельной копии ${path} (ветка ${branch}). Вернуться: /worktree exit\n`));
    },
  };

  /** Runs fn(signal) as a busy step: Ctrl+C aborts it. */
  const busyRun = async (fn) => {
    const outer = busy;
    if (!outer) { busy = true; ctl = new AbortController(); }
    try { return await fn(ctl.signal); } finally { if (!outer) { busy = false; ctl = null; } }
  };
  const multi = multiCommands({
    agent, spawn, client, cfg, env, c, bots, personaFor, startCwd, mainOut: out,
    write: (t) => stdout.write(t), line: (q) => question(rl, q), busy: busyRun, send, note: (t) => notes.push(t),
    getBot: () => holder.bot, memoryOf: (b) => readBotMemory(b.name, env),
    setBot: (b, modelOk = true) => {
      holder.bot = b;
      agent.persona = personaFor(b);
      agent.model = b?.model && modelOk ? b.model : opts.model || cfg.model;
      agent.effort = b?.effort || opts.effort || cfg.effort;
    },
  });
  // A project's own /review command stays its own; Agent Review is then /agent-review.
  for (const [k, f] of Object.entries(multi)) if (!(k === 'review' && commands.some((x) => x.name === 'review'))) commandsTable[k] = f;
  commandsTable['agent-review'] = multi.review;

  // Voice (src/voice.js): record until Enter, text from the gateway, the answer read aloud when asked.
  let sayOn = cfg.say === true;
  const lastAnswer = () => { const m = agent.messages.at(-1); return m?.role === 'assistant' && Array.isArray(m.content) ? m.content.filter((b) => b.type === 'text').map((b) => b.text).join('') : ''; };
  const sayLast = async () => { try { await busyRun((signal) => speak(client, lastAnswer(), { signal })); } catch (e) { stdout.write(c.dim(`  · не озвучил: ${e.message}`) + '\n'); } };
  async function voiceTurn(talking = false) {
    let wav;
    try {
      stdout.write(c.red('● ') + c.bold('Говорите…') + c.dim(' Enter — готово') + '\n');
      // When the recording ends by itself (no microphone, time limit), the Enter question is cancelled, or it
      // would swallow the user's next line.
      const enter = new AbortController();
      try { wav = await record(new Promise((r) => { question(rl, '', enter.signal).then(r); rl.once('close', r); })); }
      finally { enter.abort(); }
    } catch (e) { stdout.write(c.red(e.message) + '\n'); return false; }
    if (!wav) { stdout.write(c.dim('Ничего не записалось.\n')); return false; }
    let text;
    try { stdout.write(c.dim('  распознаю…\n')); text = await transcribe(client, wav); }
    catch (e) { stdout.write(c.red(e.message) + '\n'); return false; }
    if (!text) { stdout.write(c.dim('Не расслышал, повторите.\n')); return talking; }
    stdout.write(c.cyan('› ') + text + '\n');
    await send(withMentions(text, agent.cwd, images.splice(0)).content);
    if (sayOn || talking) await sayLast();
    return true;
  }

  rl.prompt();
  for await (const line of { [Symbol.asyncIterator]: () => input }) {
    const text = line.trim();
    if (!text) { rl.prompt(); continue; }
    if (text.startsWith('/') && !text.startsWith('//')) {
      const [cmd, ...rest] = text.slice(1).split(/\s+/);
      const args = rest.join(' ');
      const custom = commands.find((x) => x.name === cmd.toLowerCase()), skill = skills.find((x) => x.name === cmd.toLowerCase());
      if (commandsTable[cmd]) { try { await commandsTable[cmd](args); } catch (e) { stdout.write(c.red(e.message.split('\n')[0]) + '\n'); } }
      else if (custom) await send(withMentions(expandCommand(custom, args), agent.cwd, images.splice(0)).content, '/' + custom.name);
      else if (skill) { noteUse(skill.name, env); await send(withMentions(`Используй скилл «${skill.name}»:\n\n${skill.body}\n\n${args ? `Задача: ${args}` : ''}`, agent.cwd, images.splice(0)).content, '/' + skill.name); }
      else stdout.write(c.red(`Неизвестная команда /${cmd}. /help\n`));
      if (!rl.closed) rl.prompt();
      continue;
    }
    // «# текст»: запомнить для проекта (Markdown-заголовки «## …» уходят как обычное сообщение).
    if (/^#\s+\S/.test(text) && !text.startsWith('##')) {
      try { stdout.write(c.green(editMemory({ action: 'add', text: text.replace(/^#\s+/, '') }, startCwd, env)) + c.dim(' (/memory — посмотреть)') + '\n'); }
      catch (e) { stdout.write(c.red(e.message) + '\n'); }
      rl.prompt(); continue;
    }
    let content;
    try {
      const r = withMentions(text, agent.cwd, images);
      content = r.content;
      if (r.attached.length) stdout.write(c.dim(`  · прикреплено: ${r.attached.join(', ')}\n`));
    } catch (e) { stdout.write(c.red(e.message) + '\n'); rl.prompt(); continue; }
    images = [];
    await send(content);
    if (sayOn) await sayLast();
    stdout.write('\n');
    if (!rl.closed) rl.prompt();
  }
}
