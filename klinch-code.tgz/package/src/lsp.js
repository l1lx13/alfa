// Diagnostics after the agent's edits: the project's language server (LSP) is asked about the changed file, and its
// errors and warnings go back to the agent with the edit's result, so it fixes them right away.
//
// Language servers, if installed (node_modules/.bin of the project first, then PATH):
//   TypeScript / JavaScript  typescript-language-server --stdio (TypeScript 5-6), tsgo / tsc --lsp (TypeScript 7)
//   Python                   pyright-langserver --stdio, or pylsp
//   Go gopls · Rust rust-analyzer · C / C++ clangd · Ruby solargraph stdio · PHP intelephense --stdio
// Without one, a quick syntax check where there is one: node --check, Python's parser, JSON.
// Off: "diagnostics": false in ~/.klinch/config.json.
import { spawn, spawnSync } from 'node:child_process';
import { readFileSync, existsSync } from 'node:fs';
import { join, extname, relative, delimiter } from 'node:path';
import { pathToFileURL } from 'node:url';

export const SERVERS = [
  { exts: ['.ts', '.tsx', '.mts', '.cts', '.js', '.jsx', '.mjs', '.cjs'], cmds: [['typescript-language-server', '--stdio'], ['tsgo', '--lsp', '--stdio'], ['tsc', '--lsp', '--stdio']], lang: (e) => (/^\.[mc]?tsx?$/.test(e) ? (e === '.tsx' ? 'typescriptreact' : 'typescript') : e === '.jsx' ? 'javascriptreact' : 'javascript') },
  { exts: ['.py'], cmds: [['pyright-langserver', '--stdio'], ['basedpyright-langserver', '--stdio'], ['pylsp']], lang: () => 'python' },
  { exts: ['.go'], cmds: [['gopls']], lang: () => 'go' },
  { exts: ['.rs'], cmds: [['rust-analyzer']], lang: () => 'rust' },
  { exts: ['.c', '.h', '.cc', '.cpp', '.hpp', '.cxx'], cmds: [['clangd']], lang: (e) => (e === '.c' || e === '.h' ? 'c' : 'cpp') },
  { exts: ['.rb'], cmds: [['solargraph', 'stdio']], lang: () => 'ruby' },
  { exts: ['.php'], cmds: [['intelephense', '--stdio']], lang: () => 'php' },
];

/** The executable for `name`: the project's node_modules/.bin, then PATH. */
export function findBin(name, cwd, env = process.env) {
  const exts = process.platform === 'win32' ? ['.cmd', '.exe', ''] : [''];
  for (const dir of [join(cwd, 'node_modules', '.bin'), ...(env.PATH || '').split(delimiter)]) {
    for (const x of exts) { const p = join(dir, name + x); if (dir && existsSync(p)) return p; }
  }
  return null;
}

/** A minimal LSP client over stdio: requests, notifications and publishDiagnostics. */
export function lspClient(argv, { cwd, env = process.env }) {
  const child = spawn(argv[0], argv.slice(1), { cwd, env, stdio: ['pipe', 'pipe', 'ignore'] });
  let buf = Buffer.alloc(0), seq = 0, dead = false;
  const waiting = new Map(), diags = new Map(), listeners = new Set();
  const send = (msg) => { if (dead) return; const b = Buffer.from(JSON.stringify({ jsonrpc: '2.0', ...msg })); child.stdin.write(`Content-Length: ${b.length}\r\n\r\n`); child.stdin.write(b); };
  child.stdout.on('data', (d) => {
    buf = Buffer.concat([buf, d]);
    for (;;) {
      const h = buf.indexOf('\r\n\r\n');
      if (h < 0) return;
      const len = +/Content-Length:\s*(\d+)/i.exec(buf.subarray(0, h).toString())?.[1];
      if (!(len >= 0) || buf.length < h + 4 + len) return;
      let m; try { m = JSON.parse(buf.subarray(h + 4, h + 4 + len).toString()); } catch { m = null; }
      buf = buf.subarray(h + 4 + len);
      if (!m) continue;
      if (m.id != null && !m.method && waiting.has(m.id)) { const w = waiting.get(m.id); waiting.delete(m.id); m.error ? w.reject(new Error(m.error.message)) : w.resolve(m.result); }
      else if (m.method === 'textDocument/publishDiagnostics') { diags.set(m.params.uri, m.params.diagnostics || []); for (const l of listeners) l(m.params.uri); }
      else if (m.id != null && m.method) send({ id: m.id, result: m.method === 'workspace/configuration' ? (m.params?.items || []).map(() => null) : null });   // server → client requests
    }
  });
  const stop = () => { dead = true; for (const w of waiting.values()) w.reject(new Error('language server exited')); waiting.clear(); };
  child.on('error', stop); child.on('close', stop);
  child.stdin.on('error', () => {});
  const request = (method, params, ms = 20000) => new Promise((resolve, reject) => {
    if (dead) return reject(new Error('language server exited'));
    const id = ++seq; waiting.set(id, { resolve, reject }); send({ id, method, params });
    setTimeout(() => { if (waiting.delete(id)) reject(new Error(`${method}: no answer`)); }, ms).unref?.();
  });
  return {
    request, notify: (method, params) => send({ method, params }), diags, get dead() { return dead; },
    /** Resolves when diagnostics for `uri` have arrived and stayed the same for `quiet` ms (or after `max` ms). */
    waitDiags(uri, { quiet = 700, max = 6000 } = {}) {
      return new Promise((resolve) => {
        let t = null;
        const done = () => { listeners.delete(on); clearTimeout(t); clearTimeout(cap); resolve(diags.get(uri) || []); };
        const on = (u) => { if (u !== uri) return; clearTimeout(t); t = setTimeout(done, quiet); };
        const cap = setTimeout(done, max);
        listeners.add(on);
      });
    },
    close() { try { send({ id: ++seq, method: 'shutdown' }); send({ method: 'exit' }); } catch { /* gone */ } setTimeout(() => child.kill(), 500).unref?.(); },
  };
}

const SEV = { 1: 'ошибка', 2: 'предупреждение' };
/** Diagnostics as lines «path:line:col ошибка: message (source)», errors first, at most `max`. */
export function formatDiags(list, rel, max = 20) {
  const xs = list.filter((d) => (d.severity || 1) <= 2).sort((a, b) => (a.severity || 1) - (b.severity || 1));
  const lines = xs.slice(0, max).map((d) => `${rel}:${d.range.start.line + 1}:${d.range.start.character + 1} ${SEV[d.severity || 1]}: ${String(d.message).split('\n')[0]}${d.source ? ` (${d.source}${d.code != null ? ' ' + d.code : ''})` : ''}`);
  if (xs.length > max) lines.push(`… ещё ${xs.length - max}`);
  return lines;
}

/** Quick checks without a language server: syntax only. Returns lines like formatDiags. */
export function syntaxCheck(abs, rel, env = process.env) {
  const ext = extname(abs).toLowerCase();
  if (ext === '.json') {
    const t = readFileSync(abs, 'utf8');
    if (!t.trim()) return [];
    try { JSON.parse(t); return []; } catch (e) { return [`${rel}: ошибка: ${e.message}`]; }
  }
  let r = null;
  if (['.js', '.mjs', '.cjs'].includes(ext)) r = spawnSync(process.execPath, ['--check', abs], { encoding: 'utf8', timeout: 10000, env });
  else if (ext === '.py') r = spawnSync('python3', ['-c', 'import ast,sys; ast.parse(open(sys.argv[1], encoding="utf-8").read(), sys.argv[1])', abs], { encoding: 'utf8', timeout: 10000, env });
  if (!r || r.error || r.status === 0) return [];
  const msg = (r.stderr || '').trim().split('\n').filter((l) => /Error|error/.test(l)).pop() || (r.stderr || '').trim().split('\n').pop();
  const line = /:(\d+)\b/.exec(r.stderr || '')?.[1] || /line (\d+)/.exec(r.stderr || '')?.[1];
  return [`${rel}${line ? ':' + line : ''} ошибка: ${msg}`];
}

/**
 * One language server per kind, started on first use in `cwd`. check(abs) → lines of problems ([] when clean).
 * `servers` and `find` are for tests.
 */
export function createDiagnostics(cwd, { env = process.env, servers = SERVERS, find = findBin } = {}) {
  const running = new Map();   // SERVERS entry → { client, ready, versions, pull, name } (client null: none started)
  // The first server of the kind that is installed and starts (TypeScript 7 has no tsserver for
  // typescript-language-server, its own `tsc --lsp` serves instead).
  const start = (s) => {
    if (running.has(s)) return running.get(s);
    const root = pathToFileURL(cwd).href;
    const r = { client: null, versions: new Map(), pull: false };
    r.ready = (async () => {
      for (const c of s.cmds) {
        const bin = find(c[0], cwd, env);
        if (!bin) continue;
        const client = lspClient([bin, ...c.slice(1)], { cwd, env });
        const res = await client.request('initialize', {
          processId: process.pid, rootUri: root, rootPath: cwd, workspaceFolders: [{ uri: root, name: 'root' }],
          capabilities: { textDocument: { publishDiagnostics: { relatedInformation: false }, diagnostic: { dynamicRegistration: false }, synchronization: { didSave: true } }, workspace: { configuration: true, workspaceFolders: true } },
        }, 30000).catch(() => null);
        if (!res || client.dead) { client.close(); continue; }
        client.notify('initialized', {});
        Object.assign(r, { client, pull: !!res.capabilities?.diagnosticProvider, name: c[0] });
        return true;
      }
      return false;
    })();
    running.set(s, r);
    return r;
  };
  return {
    async check(abs) {
      const rel = relative(cwd, abs) || abs, ext = extname(abs).toLowerCase();
      const s = servers.find((x) => x.exts.includes(ext));
      const r = s ? start(s) : null;
      if (r && await r.ready && r.client && !r.client.dead) {
        const uri = pathToFileURL(abs).href, text = readFileSync(abs, 'utf8');
        const v = (r.versions.get(uri) || 0) + 1;
        r.client.diags.delete(uri);
        // Servers that publish diagnostics are waited for; newer ones (pull model) are asked.
        const wait = r.pull ? null : r.client.waitDiags(uri, { max: v === 1 ? 12000 : 6000 });
        if (v === 1) r.client.notify('textDocument/didOpen', { textDocument: { uri, languageId: s.lang(ext), version: v, text } });
        else r.client.notify('textDocument/didChange', { textDocument: { uri, version: v }, contentChanges: [{ text }] });
        r.client.notify('textDocument/didSave', { textDocument: { uri }, text });
        r.versions.set(uri, v);
        if (wait) return formatDiags(await wait, rel);
        const res = await r.client.request('textDocument/diagnostic', { textDocument: { uri } }, 20000).catch(() => null);
        return formatDiags(res?.items || [], rel);
      }
      try { return syntaxCheck(abs, rel, env); } catch { return []; }
    },
    servers: () => [...running.values()].filter((r) => r.client).map((r) => r.name),
    close() { for (const r of running.values()) r.client?.close(); },
  };
}

