// Several agents at once: one task on several models (/compare), Mixture of Agents (/moa), the Kanban board
// (/board, src/board.js) and Agent Review (/review).
//
// In a git repository every run that may change files gets its own copy (a detached `git worktree` in the temp
// folder, made from the working tree as it is now, uncommitted changes of tracked files included). The agents edit
// their copies without asking; what each one changed becomes a patch, the copy is removed, and the user applies the
// patch they choose. Outside git the runs only read and answer.
import { execFileSync } from 'node:child_process';
import { existsSync, mkdirSync, rmSync, symlinkSync, writeFileSync } from 'node:fs';
import { tmpdir, homedir } from 'node:os';
import { join, relative } from 'node:path';

const run = (cwd, args) => execFileSync('git', args, { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], maxBuffer: 64 << 20 });
const git = (cwd, args) => run(cwd, args).trim();

export const textOf = (msg) => (msg?.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('').trim();
export const isEdit = (tool) => ['write_file', 'edit_file', 'notebook_edit'].includes(tool);

/** { top, rel, base } for a git repository with at least one commit, else null. */
export function repoInfo(cwd) {
  try {
    const top = git(cwd, ['rev-parse', '--show-toplevel']);
    git(top, ['rev-parse', '--verify', 'HEAD']);
    return { top, rel: relative(top, cwd) };
  } catch { return null; }
}

/** A commit of the working tree as it is now (staged and unstaged changes of tracked files); nothing is changed. */
export function baseCommit(top) {
  let s = '';
  try { s = git(top, ['stash', 'create']); } catch { /* nothing to stash */ }
  return s || git(top, ['rev-parse', 'HEAD']);
}

const ignored = (top, path) => { try { run(top, ['check-ignore', '-q', path]); return true; } catch { return false; } };

/** A detached copy of the repository at `base` in `dir`; node_modules is shared with the original (link). */
export function addWorktree(top, base, dir) {
  mkdirSync(join(dir, '..'), { recursive: true });
  git(top, ['worktree', 'add', '--detach', dir, base]);
  const nm = join(top, 'node_modules');
  if (existsSync(nm) && !existsSync(join(dir, 'node_modules')) && ignored(top, 'node_modules')) {
    try { symlinkSync(nm, join(dir, 'node_modules'), 'junction'); } catch { /* no links here: the agent installs */ }
  }
}

/** Everything the run changed in its copy, as a binary-safe patch against `base`. */
export function worktreePatch(dir, base) {
  git(dir, ['add', '-A', '--', '.', ':(exclude)node_modules']);
  return run(dir, ['diff', '--cached', '--binary', base, '--', '.', ':(exclude)node_modules']);
}

export function removeWorktree(top, dir) {
  try { git(top, ['worktree', 'remove', '--force', dir]); }
  catch { rmSync(dir, { recursive: true, force: true }); try { git(top, ['worktree', 'prune']); } catch { /* gone */ } }
}

/** { files, plus, minus, names } of a unified diff. */
export function diffStat(patch) {
  const s = { files: 0, plus: 0, minus: 0, names: [] };
  for (const l of String(patch || '').split('\n')) {
    if (l.startsWith('diff --git ')) { s.files++; const m = / b\/(.+)$/.exec(l); if (m) s.names.push(m[1]); }
    else if (l.startsWith('+') && !l.startsWith('+++')) s.plus++;
    else if (l.startsWith('-') && !l.startsWith('---')) s.minus++;
  }
  return s;
}

export const runsDir = (env = process.env) => join(env.KLINCH_HOME || join(homedir(), '.klinch'), 'runs');

/** Saves a patch for later (/board apply, `git apply`); returns its path. */
export function savePatch(patch, name, env = process.env) {
  const dir = runsDir(env);
  mkdirSync(dir, { recursive: true });
  const file = join(dir, `${name}.patch`);
  writeFileSync(file, patch);
  return file;
}

/** Applies a patch to the repository's working tree; a plain apply first, then a three-way merge. */
export function applyPatch(top, patch, env = process.env) {
  if (!String(patch || '').trim()) throw new Error('В этом варианте нет изменений');
  const file = savePatch(patch, `apply-${Date.now().toString(36)}`, env);
  try { run(top, ['apply', '--whitespace=nowarn', file]); }
  catch {
    try { run(top, ['apply', '--3way', '--whitespace=nowarn', file]); }
    catch (e) { throw new Error(`Изменения не легли на текущие файлы (${String(e.stderr || e.message).split('\n')[0]}). Патч: ${file}`); }
  }
  return file;
}

/** Changes in the repository right now: `git diff HEAD` plus new untracked files (each up to 20 KB). */
export function currentDiff(cwd) {
  const top = git(cwd, ['rev-parse', '--show-toplevel']);
  let d = '';
  try { d = run(top, ['diff', 'HEAD']); } catch { d = run(top, ['diff']); }
  const extra = git(top, ['ls-files', '--others', '--exclude-standard']).split('\n').filter(Boolean).slice(0, 30);
  for (const f of extra) {
    let body = '';
    try { body = execFileSync('git', ['diff', '--no-index', '--', '/dev/null', f], { cwd: top, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }); }
    catch (e) { body = String(e.stdout || ''); }   // --no-index exits 1 when the files differ
    d += body.slice(0, 20000);
  }
  return { top, diff: d };
}

/**
 * Models for a multi-model run: the ones asked for, else the saved list, else the current model plus models of
 * other families (claude-…, gpt-…, deepseek-…), up to `n`.
 */
export function pickModels(all, { asked = [], saved = [], current, n = 3 } = {}) {
  const ids = all.map((m) => m.id || m);
  const want = asked.length ? asked : saved;
  if (want.length) {
    const bad = want.filter((m) => !ids.includes(m));
    if (bad.length) throw new Error(`Нет таких моделей: ${bad.join(', ')}. Список: /models`);
    return [...new Set(want)];
  }
  const fam = (id) => String(id).split(/[-_/]/)[0];
  const out = ids.includes(current) ? [current] : [];
  ids.splice(0, ids.length, ...ids.filter((id) => !String(id).startsWith('local:')));   // local ones only when asked
  for (const id of ids) if (out.length < n && !out.some((x) => fam(x) === fam(id))) out.push(id);
  for (const id of ids) if (out.length < n && !out.includes(id)) out.push(id);
  return out.slice(0, n);
}

/** `"m1,m2 задача"` → { models: [m1, m2], task }; models are taken only when the first word names known models. */
export function splitModels(text, ids) {
  const t = String(text || '').trim();
  const [first, ...rest] = t.split(/\s+/);
  const list = (first || '').split(',').map((s) => s.trim()).filter(Boolean);
  const known = (m) => ids.includes(m) || m.startsWith('@');
  if (list.length > 1 || (list.length === 1 && known(list[0]) && rest.length)) return { models: list, task: rest.join(' ').trim() };
  return { models: [], task: t };
}

/** Runs plain functions one at a time (questions to the user from parallel agents never overlap). */
export function serial() {
  let tail = Promise.resolve();
  return (fn) => { const p = tail.then(fn, fn); tail = p.catch(() => {}); return p; };
}

/**
 * Runs jobs in parallel, each in its own copy of the repository when possible.
 * job: { label, model, task, persona?, effort? }. spawn({ model, cwd, isolated, label, persona, effort }) → agent.
 * Returns { results: [{ n, label, model, ok, error, answer, patch, stat, steps, usage, ms }], isolated }.
 */
export async function runJobs({ jobs, spawn, cwd, signal, isolate = true, onDone }) {
  const repo = isolate ? repoInfo(cwd) : null;
  let base = null;
  if (repo) { try { base = baseCommit(repo.top); } catch { base = null; } }
  const root = join(tmpdir(), 'agent-runs', Date.now().toString(36) + Math.random().toString(36).slice(2, 6));
  const results = await Promise.all(jobs.map(async (job, i) => {
    const r = { n: i + 1, label: job.label, model: job.model, ok: false, error: null, answer: '', patch: '', steps: 0, usage: {}, ms: 0 };
    const t0 = Date.now();
    let dir = null;
    try {
      if (base) { dir = join(root, String(i + 1)); addWorktree(repo.top, base, dir); }
      const agent = spawn({ ...job, cwd: dir ? join(dir, repo.rel) : cwd, isolated: !!dir });
      try {
        const msg = await agent.ask(job.task, { signal });
        r.answer = textOf(msg); r.ok = true;
      } finally { r.steps = agent.steps; r.usage = { ...agent.totalUsage }; }
    } catch (e) { r.error = e.interrupted || e.name === 'AbortError' ? 'прервано' : e.message; }
    finally {
      if (dir) {
        try { r.patch = worktreePatch(dir, base); } catch { /* the copy is broken: nothing to show */ }
        removeWorktree(repo.top, dir);
      }
      r.ms = Date.now() - t0;
      r.stat = diffStat(r.patch);
      onDone?.(r);
    }
    return r;
  }));
  try { rmSync(root, { recursive: true, force: true }); } catch { /* temp */ }
  return { results, isolated: !!base, top: repo?.top || null };
}

export const tokensOf = (u = {}) => (u.input_tokens || 0) + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0) + (u.output_tokens || 0);

const clip = (s, n) => (s.length > n ? `${s.slice(0, n)}\n… (обрезано, всего ${s.length} символов)` : s);

export const REVIEWER = {
  name: 'ревьюер',
  prompt: `Ты строгий ревьюер кода (Agent Review). Тебе дают изменения (diff). Найди реальные проблемы: ошибки в логике, граничные случаи, сломанные вызовы и импорты, забытые места, уязвимости, потерю данных, расхождение с задачей. Нужные для проверки файлы читай сам (read_file, search). Не придирайся к стилю и не пересказывай diff.
Формат: список замечаний «[важно|мелочь] путь:строка — что не так и как исправить»; если замечаний нет, так и скажи. Последней строкой: «ИТОГ: можно принимать» или «ИТОГ: нужно исправить».`,
};

/** The reviewer's request for the current changes. */
export function reviewPrompt(diff, task = '') {
  return `${task ? `Задача, ради которой делались изменения: ${task}\n\n` : ''}Проверь эти изменения перед тем, как пользователь их примет:\n\n\`\`\`diff\n${clip(diff, 120000)}\n\`\`\``;
}

/** The reviewer's request for variants of one task; the answer ends with «ЛУЧШИЙ: N». */
export function compareReviewPrompt(task, results) {
  const per = Math.max(8000, Math.floor(120000 / Math.max(1, results.length)));
  const parts = results.map((r) => `## Вариант ${r.n}${r.ok ? '' : ` (не закончил: ${r.error})`}\nИтог агента:\n${clip(r.answer || '(нет)', 3000)}\n\n${r.patch ? `\`\`\`diff\n${clip(r.patch, per)}\n\`\`\`` : 'Файлы не менял.'}`);
  return `Несколько агентов независимо решали одну задачу. Сравни варианты.\n\nЗадача: ${task}\n\n${parts.join('\n\n')}\n\nДля каждого варианта коротко: решена ли задача, найденные ошибки (путь:строка). Потом какой вариант лучше и почему. Последней строкой ровно «ЛУЧШИЙ: N» (номер варианта) или «ЛУЧШИЙ: нет», если ни один не годится.`;
}

export const bestOf = (text) => { const m = /ЛУЧШИЙ:\s*(\d+)/i.exec(String(text || '')); return m ? +m[1] : null; };

/** The aggregator's request in Mixture of Agents: the proposers' answers to merge into one. */
export function moaPrompt(question, results) {
  const ok = results.filter((r) => r.ok && r.answer);
  return `${question}\n\n---\nНа этот запрос независимо ответили ${ok.length} экспертов (Mixture of Agents). Их ответы:\n\n${ok.map((r, i) => `## Эксперт ${i + 1}\n${clip(r.answer, 12000)}`).join('\n\n')}\n\n---\nТы агрегатор. Сведи ответы в один лучший: возьми верное, исправь ошибки, где эксперты расходятся, проверь по коду и реши сам. Не упоминай экспертов и этот процесс, отвечай пользователю напрямую. Если запрос требует правок в коде, выполни их.`;
}
