// The Kanban board (/board): tasks for several agents in one project.
// Columns: todo (ждёт) → doing (в работе) → review (на проверке: изменения готовы, патч сохранён) → done.
// `/board run` starts every waiting card at once, each with its own bot or model in its own copy of the repository
// (src/multi.js); finished cards wait in review until the user applies or drops their changes.
// The board is kept outside the project: ~/.klinch/boards/<hash of the folder>.json.
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { homedir } from 'node:os';
import { join } from 'node:path';

export const COLUMNS = [['todo', 'Ждут'], ['doing', 'В работе'], ['review', 'На проверке'], ['done', 'Готово']];

const file = (cwd, env) => join(env.KLINCH_HOME || join(homedir(), '.klinch'), 'boards', createHash('sha1').update(cwd).digest('hex').slice(0, 16) + '.json');

export function loadBoard(cwd, env = process.env) {
  try {
    const b = JSON.parse(readFileSync(file(cwd, env), 'utf8'));
    if (Array.isArray(b.cards)) return { cwd, next: b.next || b.cards.length + 1, cards: b.cards };
  } catch { /* new board */ }
  return { cwd, next: 1, cards: [] };
}

export function saveBoard(board, env = process.env) {
  const f = file(board.cwd, env);
  mkdirSync(join(f, '..'), { recursive: true });
  writeFileSync(f, JSON.stringify({ cwd: board.cwd, next: board.next, cards: board.cards }, null, 2) + '\n');
}

/** `текст @бот -m модель` → a new card in todo. */
export function addCard(board, text) {
  let t = String(text || '').trim(), bot = null, model = null;
  t = t.replace(/(^|\s)@([\w-]+)(?=\s|$)/, (_, s, b) => { bot = b.toLowerCase(); return s; });
  t = t.replace(/(^|\s)-m\s+(\S+)/, (_, s, m) => { model = m; return s; });
  t = t.trim();
  if (!t) throw new Error('Пустая задача. /board add <задача> [@бот] [-m модель]');
  const card = { id: board.next++, title: t, bot, model, status: 'todo', created: Date.now() };
  board.cards.push(card);
  return card;
}

export const findCard = (board, id) => {
  const c = board.cards.find((x) => x.id === +String(id).replace(/^#/, ''));
  if (!c) throw new Error(`Нет карточки #${id}`);
  return c;
};

/** The board as text lines (a column per block). */
export function formatBoard(board) {
  const lines = [];
  for (const [k, title] of COLUMNS) {
    const cs = board.cards.filter((c) => c.status === k);
    if (!cs.length && k === 'done') continue;
    lines.push(`${title} (${cs.length})`);
    for (const c of (k === 'done' ? cs.slice(-5) : cs)) {
      const who = [c.bot && '@' + c.bot, c.model].filter(Boolean).join(' ');
      const extra = c.status === 'review' && c.stat ? ` +${c.stat.plus} −${c.stat.minus} в ${c.stat.files} файл.` : c.error ? ` · ${c.error.slice(0, 60)}` : '';
      lines.push(`  #${c.id} ${c.title.replace(/\s+/g, ' ').slice(0, 70)}${who ? `  ${who}` : ''}${extra}${c.verdict ? `  ${c.verdict}` : ''}`);
    }
  }
  return lines;
}
