// Sandbox for the agent's shell commands (/sandbox, --sandbox, "sandbox" in ~/.klinch/config.json).
//
// Inside it a command may write only to the project folder, the temporary folder and the package caches, cannot
// read the usual secret folders (~/.ssh, cloud credentials, the Klinch key) and reaches the network only by the
// allow list (src/netproxy.js: npm, PyPI, GitHub… out of the box). Because nothing outside the project can change,
// sandboxed commands run without the «Выполнить?» question; a command that needs more asks for it with
// `unsandboxed: true` and is confirmed as usual. Deny rules and hooks apply either way.
//
//   Linux: bubblewrap (`bwrap`, packaged as bubblewrap). macOS: the built-in sandbox-exec.
//   Windows: a low-integrity copy of cmd.exe (the project folder is marked writable for it), see prepareWindows.
//   "backend": "docker": each command in a fresh container with only the project folder mounted.
//   "backend": "ssh": each command on another computer, in a copy of the project that is synced before and after.
import { execFileSync, execFile } from 'node:child_process';
import { copyFileSync, existsSync, mkdirSync, readdirSync, realpathSync, statSync } from 'node:fs';
import { homedir, tmpdir } from 'node:os';
import { basename, join } from 'node:path';
import { createHash } from 'node:crypto';
import { DEFAULT_ALLOW, startProxy, proxyEnv, FORWARDER } from './netproxy.js';

const HIDDEN = ['.ssh', '.gnupg', '.aws', '.azure', '.kube', '.docker', '.config/gh', '.config/gcloud', '.netrc', '.npmrc', '.pypirc', '.git-credentials', '.klinch', '.claude.json'];
const CACHES = ['.npm', '.cache', '.yarn', '.pnpm-store', '.bun', '.cargo/registry', '.gradle', '.m2', 'go/pkg', 'Library/Caches'];
export const BACKENDS = ['local', 'docker', 'ssh'];
export const DEFAULT_IMAGE = 'node:22';
// The port the forwarder listens on inside the Linux sandbox's own network.
const INNER_PORT = 3128;

const real = (p) => { try { return realpathSync(p); } catch { return p; } };
const isDir = (p) => { try { return statSync(p).isDirectory(); } catch { return false; } };

/** Which sandbox this computer has: { kind: 'bwrap' | 'seatbelt' | 'lowil' | 'docker' | 'ssh' | null, reason }. */
const found = new Map();
export function detectSandbox({ platform = process.platform, run = execFileSync, backend = 'local', env = process.env } = {}) {
  const key = platform + ':' + backend, cache = platform === process.platform && run === execFileSync;
  if (cache && found.has(key)) return found.get(key);
  let r;
  if (backend === 'docker') {
    try { run('docker', ['version', '--format', '{{.Server.Version}}'], { stdio: 'ignore', timeout: 10000 }); r = { kind: 'docker' }; }
    catch (e) { r = { kind: null, reason: e.code === 'ENOENT' ? 'нужен Docker (docker.com/get-started)' : 'Docker не запущен' }; }
  } else if (backend === 'ssh') {
    try { run('ssh', ['-V'], { stdio: 'ignore', timeout: 5000 }); r = { kind: 'ssh' }; }
    catch { r = { kind: null, reason: 'нужен ssh' }; }
  } else if (platform === 'linux') {
    try { run('bwrap', ['--ro-bind', '/', '/', '--dev', '/dev', '--unshare-net', 'true'], { stdio: 'ignore', timeout: 5000 }); r = { kind: 'bwrap' }; }
    catch (e) { r = { kind: null, reason: e.code === 'ENOENT' ? 'нужен bubblewrap: sudo apt install bubblewrap (или dnf / pacman), либо /sandbox docker' : 'bubblewrap не запускается (в системе выключены user namespaces), можно /sandbox docker' }; }
  } else if (platform === 'darwin') {
    r = existsSync('/usr/bin/sandbox-exec') ? { kind: 'seatbelt' } : { kind: null, reason: 'нет /usr/bin/sandbox-exec' };
  } else if (platform === 'win32') {
    const sys = join(env.SystemRoot || 'C:\\Windows', 'System32');
    r = existsSync(join(sys, 'icacls.exe')) && existsSync(env.ComSpec || join(sys, 'cmd.exe')) ? { kind: 'lowil' } : { kind: null, reason: 'нет icacls.exe' };
  } else r = { kind: null, reason: `на ${platform} песочницы нет, можно /sandbox docker` };
  if (cache) found.set(key, r);
  return r;
}

const NET = (v) => (v === true || v === 'on' ? true : v === false || v === 'off' ? false : 'allowlist');
const strs = (a) => (Array.isArray(a) ? a.filter((x) => typeof x === 'string' && x.trim()).map((x) => x.trim()) : []);

/**
 * Settings from the config value: true / false / { enabled, network: true | false | "allowlist", allowWrite,
 * allowHosts, backend: local | docker | ssh, image, host, port, dir }. Without "network" it is the allow list.
 */
export function sandboxSettings(v) {
  const o = v && typeof v === 'object' ? v : { enabled: v === true };
  const backend = BACKENDS.includes(o.backend) ? o.backend : 'local';
  return {
    enabled: !!o.enabled, network: NET(o.network), allowWrite: strs(o.allowWrite), allowHosts: strs(o.allowHosts), backend,
    ...(backend === 'docker' ? { image: typeof o.image === 'string' && o.image ? o.image : DEFAULT_IMAGE } : {}),
    ...(backend === 'ssh' ? { host: typeof o.host === 'string' ? o.host : '', ...(o.port ? { port: +o.port } : {}), ...(typeof o.dir === 'string' && o.dir ? { dir: o.dir } : {}) } : {}),
  };
}

/** The config value to save for settings `s` (what sandboxSettings reads back). */
export function sandboxConfig(s) {
  const o = { enabled: !!s.enabled, network: s.network ?? 'allowlist' };
  if (s.allowWrite?.length) o.allowWrite = s.allowWrite;
  if (s.allowHosts?.length) o.allowHosts = s.allowHosts;
  if (s.backend && s.backend !== 'local') o.backend = s.backend;
  if (s.backend === 'docker' && s.image && s.image !== DEFAULT_IMAGE) o.image = s.image;
  if (s.backend === 'ssh') { o.host = s.host || ''; if (s.port) o.port = s.port; if (s.dir) o.dir = s.dir; }
  return o;
}

/** Whether the python tool can run inside this sandbox (it talks to the agent over descriptors 3 and 4). */
export const keepsDescriptors = (sb) => sb?.kind === 'bwrap' || sb?.kind === 'seatbelt';

/** One line about the sandbox for the start banner and /sandbox. */
export function describeSandbox(sb) {
  const where = { bwrap: '', seatbelt: '', lowil: ' Windows', docker: ` Docker ${sb.image || DEFAULT_IMAGE}`, ssh: ` на ${sb.host}` }[sb.kind] ?? '';
  const net = sb.kind === 'ssh' ? '' : sb.network === true ? ', сеть открыта' : sb.network === false ? ', без сети' : ', сеть: реестры пакетов';
  return `песочница${where}${net}`;
}

const sbStr = (s) => '"' + String(s).replace(/[\\"]/g, '\\$&') + '"';

// ---- Network by the allow list: one proxy per way of reaching it, started on the first command ----
const proxies = new Map();
const allowList = (sb) => (sb.network === false ? [] : [...DEFAULT_ALLOW, ...(sb.allowHosts || [])]);
/** Whether commands in `sb` go through the proxy (Windows always: there the proxy is the only network limit). */
const wantsProxy = (sb) => sb.kind !== 'ssh' && (sb.network === 'allowlist' || (sb.kind === 'lowil' && sb.network === false));

function dockerGateway(run = execFileSync) {
  if (process.platform !== 'linux') return '127.0.0.1';
  try { return String(run('docker', ['network', 'inspect', 'bridge', '--format', '{{(index .IPAM.Config 0).Gateway}}'], { encoding: 'utf8', timeout: 8000 })).trim() || '127.0.0.1'; }
  catch { return '127.0.0.1'; }
}

/**
 * Gets `sb` ready for commands in `cwd`: starts the allow-list proxy and, on Windows, the low-integrity shell.
 * Safe to call before every command; the work is done once. Never throws: without it commands just get no network.
 */
export async function prepareSandbox(sb, cwd, { env = process.env } = {}) {
  if (!sb?.active) return sb;
  try {
    if (wantsProxy(sb)) {
      const key = sb.kind === 'bwrap' ? 'unix' : sb.kind === 'docker' ? 'docker' : 'tcp';
      let st = proxies.get(key);
      if (!st) {
        st = startProxy({ socket: key === 'unix', host: key === 'docker' ? dockerGateway() : '127.0.0.1', allow: () => st.list });
        proxies.set(key, st);
      }
      st.list = allowList(sb);
      await st.ready;
      Object.defineProperty(sb, 'proxy', { value: st, configurable: true, enumerable: false });
    }
    if (sb.kind === 'lowil') await prepareWindows(sb, cwd, env);
  } catch (e) {
    Object.defineProperty(sb, 'prepareError', { value: e.message, configurable: true, enumerable: false });
  }
  return sb;
}

/** Hosts the proxy of `sb` closed since `t`. */
export const sandboxDenied = (sb, t) => [...new Set((sb?.proxy?.denied || []).filter((d) => d.at >= t && d.host).map((d) => d.host))];

// ---- Windows: a low-integrity cmd.exe ----
// Windows starts a program at the lower of the parent's integrity level and the level marked on the .exe file. A copy
// of cmd.exe marked Low therefore runs at Low, and so does everything it starts: such processes cannot write to
// ordinary (Medium) files and folders. The project folder, the extra allowWrite folders and the sandbox's own temp
// and cache folders are marked Low with icacls, so writing there works. Reading is not limited and the network goes
// only through the proxy variables, so on Windows the sandbox guards files, not secrets.
const labeled = new Set();
export const winBase = (env = process.env) => join(env.USERPROFILE || homedir(), 'AppData', 'LocalLow', 'agent-sandbox');

async function prepareWindows(sb, cwd, env, run = execFileSync) {
  const base = winBase(env), cmd = join(base, 'cmd.exe');
  for (const d of ['tmp', 'npm-cache', 'pip-cache', 'yarn-cache']) mkdirSync(join(base, d), { recursive: true });
  const sys = join(env.SystemRoot || 'C:\\Windows', 'System32');
  if (!existsSync(cmd)) {
    copyFileSync(env.ComSpec || join(sys, 'cmd.exe'), cmd);
    // cmd.exe takes its messages from <lang>\cmd.exe.mui next to it.
    for (const d of readdirSync(sys)) {
      if (!/^[a-z]{2,3}-[A-Za-z]{2,4}$/.test(d) || !existsSync(join(sys, d, 'cmd.exe.mui'))) continue;
      try { mkdirSync(join(base, d), { recursive: true }); copyFileSync(join(sys, d, 'cmd.exe.mui'), join(base, d, 'cmd.exe.mui')); } catch { /* messages only */ }
    }
  }
  const icacls = (p, level) => run(join(sys, 'icacls.exe'), [p, '/setintegritylevel', level], { stdio: 'ignore', timeout: 120000, windowsHide: true });
  if (!labeled.has(cmd)) { icacls(cmd, 'Low'); icacls(base, '(OI)(CI)Low'); labeled.add(cmd); }
  for (const p of [cwd, ...(sb.allowWrite || []).map((x) => x.replace(/^~(?=[\\/]|$)/, homedir()))]) {
    if (!labeled.has(p) && isDir(p)) { icacls(p, '(OI)(CI)Low'); labeled.add(p); }
  }
}

// ---- SSH: the command runs on another computer in a synced copy of the project ----
/** The project's folder on the remote computer (relative to its home), unless "dir" says otherwise. */
export const remoteDir = (sb, cwd) => sb.dir || `agent-sandbox/${basename(cwd).replace(/[^\w.-]/g, '_')}-${createHash('sha1').update(cwd).digest('hex').slice(0, 8)}`;
export const SYNC_EXCLUDE = ['node_modules', '.venv', 'venv', '__pycache__', '.DS_Store'];

// Runs in a separate node process: push the project, run the command over ssh, pull the results back (also when it
// fails). rsync when both computers have it (deleted files follow), tar otherwise.
function sshRunner(o) {
  const { spawn, spawnSync } = require('child_process');
  const ssh = ['-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', ...(o.port ? ['-p', String(o.port)] : []), o.host];
  const q = (s) => `'${String(s).replace(/'/g, `'\\''`)}'`;
  const rdir = /^[~/]/.test(o.dir) ? o.dir.replace(/^~\/?/, '') || '.' : o.dir;
  const has = (bin) => !spawnSync(bin, ['--version'], { stdio: 'ignore' }).error;
  const pipe = (a, b) => new Promise((done) => {
    const x = spawn(a[0], a.slice(1), { stdio: ['ignore', 'pipe', 'inherit'] }), y = spawn(b[0], b.slice(1), { stdio: ['pipe', 'ignore', 'inherit'] });
    x.stdout.pipe(y.stdin); x.on('error', () => done(1)); y.on('error', () => done(1)); y.on('close', (c) => done(c ?? 1));
  });
  const excl = o.exclude.flatMap((e) => ['--exclude', e]);
  (async () => {
    const mk = spawnSync('ssh', [...ssh, `mkdir -p ${q(rdir)}`], { stdio: ['ignore', 'ignore', 'inherit'] });
    if (mk.error || mk.status) { console.error(`Песочница: не удалось подключиться к ${o.host} по ssh (нужен вход по ключу без пароля; один раз зайдите туда вручную, чтобы ssh запомнил компьютер)`); process.exit(255); }
    const rsync = has('rsync') && !spawnSync('ssh', [...ssh, 'command -v rsync'], { stdio: 'ignore' }).status;
    const e = ['-e', ['ssh', ...ssh.slice(0, -1)].join(' ')];
    const push = rsync ? spawnSync('rsync', ['-az', '--delete', ...excl, ...e, o.cwd + '/', `${o.host}:${rdir}/`], { stdio: ['ignore', 'ignore', 'inherit'] }).status
      : await pipe(['tar', '-cf', '-', ...excl, '-C', o.cwd, '.'], ['ssh', ...ssh, `tar -xf - -C ${q(rdir)}`]);
    if (push) { console.error('Песочница: не удалось отправить проект на ' + o.host); process.exit(255); }
    const ch = spawn('ssh', [...ssh, `cd ${q(rdir)} && sh -c ${q(o.command)}`], { stdio: ['ignore', 'inherit', 'inherit'] });
    for (const s of ['SIGTERM', 'SIGINT', 'SIGHUP']) process.on(s, () => ch.kill(s));
    const code = await new Promise((r) => { ch.on('error', () => r(255)); ch.on('close', (c) => r(c ?? 1)); });
    const pull = rsync ? spawnSync('rsync', ['-az', '--delete', ...excl, ...e, `${o.host}:${rdir}/`, o.cwd + '/'], { stdio: ['ignore', 'ignore', 'inherit'] }).status
      : await pipe(['ssh', ...ssh, `tar -cf - ${excl.map(q).join(' ')} -C ${q(rdir)} .`], ['tar', '-xf', '-', '-C', o.cwd]);
    if (pull) console.error('Песочница: не удалось забрать изменения с ' + o.host);
    process.exit(code);
  })();
}

/**
 * The program and arguments that run `command` in `cwd` inside the sandbox `sb` ({ kind, network, allowWrite, … }):
 * [bin, args, env]. `env` holds the variables to add (the proxy and so on). The array may carry `.kill()`, which
 * stops what plain killing the program leaves behind (a Docker container). `home`, `tmp` and `platform` are for tests.
 */
export function wrapCommand(sb, command, cwd, { home = homedir(), tmp = tmpdir(), platform = process.platform, env = process.env } = {}) {
  const writable = [...new Set([real(cwd), ...CACHES.map((c) => join(home, c)), ...(sb.allowWrite || []).map((p) => p.replace(/^~(?=\/|$)/, home))].filter(isDir).map(real))];
  const hidden = HIDDEN.map((h) => join(home, h)).filter((p) => existsSync(p) && !real(cwd).startsWith(real(p)));
  const px = sb.proxy, viaProxy = px && wantsProxy(sb);
  if (sb.kind === 'bwrap') {
    const args = ['--ro-bind', '/', '/', '--dev', '/dev', '--proc', '/proc', '--tmpfs', '/tmp'];
    if (real(tmp) !== '/tmp' && isDir(tmp)) args.push('--bind', real(tmp), real(tmp));
    for (const p of writable) args.push('--bind', p, p);
    for (const p of hidden) args.push(...(isDir(p) ? ['--tmpfs', p] : ['--ro-bind', '/dev/null', p]));
    if (sb.network !== true) args.push('--unshare-net');
    args.push('--unshare-pid', '--die-with-parent', '--new-session', '--chdir', cwd);
    if (viaProxy && px.socket) {
      // No network inside except the forwarder to the proxy's socket.
      const sockDir = px.socket.slice(0, px.socket.lastIndexOf('/'));
      args.splice(args.indexOf('--unshare-net'), 0, '--bind', sockDir, sockDir);
      args.push(process.execPath, '-e', FORWARDER, px.socket, String(INNER_PORT), JSON.stringify(proxyEnv(`http://127.0.0.1:${INNER_PORT}`)), '/bin/sh', '-c', command);
      return ['bwrap', args, {}];
    }
    args.push('/bin/sh', '-c', command);
    return ['bwrap', args, {}];
  }
  if (sb.kind === 'seatbelt') {
    const temps = ['/private/tmp', '/private/var/folders', real(tmp)];
    const profile = [
      '(version 1)', '(allow default)',
      '(deny file-write*)',
      `(allow file-write* ${[...writable, ...temps].map((p) => `(subpath ${sbStr(p)})`).join(' ')} (regex #"^/dev/(null|zero|tty|ttys[0-9]+|fd/[0-9]+|stdout|stderr|dtracehelper)$"))`,
      hidden.length ? `(deny file-read* file-write* ${hidden.map((p) => `(subpath ${sbStr(real(p))})`).join(' ')})` : '',
      sb.network === true ? '' : '(deny network-outbound (remote ip))',
      viaProxy && px.port ? `(allow network-outbound (remote ip "localhost:${px.port}"))` : '',
    ].filter(Boolean).join('\n');
    return ['/usr/bin/sandbox-exec', ['-p', profile, '/bin/sh', '-c', command], viaProxy && px.port ? proxyEnv(`http://127.0.0.1:${px.port}`) : {}];
  }
  if (sb.kind === 'lowil') {
    const base = winBase(env);
    const extra = { TEMP: join(base, 'tmp'), TMP: join(base, 'tmp'), npm_config_cache: join(base, 'npm-cache'), PIP_CACHE_DIR: join(base, 'pip-cache'), YARN_CACHE_FOLDER: join(base, 'yarn-cache') };
    return [join(base, 'cmd.exe'), ['/d', '/s', '/c', `"${command}"`], { ...extra, ...(viaProxy && px.port ? proxyEnv(`http://127.0.0.1:${px.port}`) : {}) }];
  }
  if (sb.kind === 'docker') {
    const win = platform === 'win32', inside = win ? '/work' : cwd;
    const name = `agent-sb-${process.pid}-${Math.random().toString(36).slice(2, 8)}`;
    const args = ['run', '--rm', '--init', '--name', name, '-v', `${cwd}:${inside}`, '-w', inside, '-e', 'HOME=/tmp'];
    if (platform === 'linux' && process.getuid) args.push('--user', `${process.getuid()}:${process.getgid()}`);
    if (!win) for (const p of (sb.allowWrite || []).map((x) => x.replace(/^~(?=\/|$)/, home)).filter(isDir)) args.push('-v', `${p}:${p}`);
    if (sb.network === true) args.push('--network', 'bridge');
    else if (viaProxy && px.port) {
      args.push('--network', 'bridge', '--add-host', 'host.docker.internal:host-gateway');
      for (const [k, v] of Object.entries(proxyEnv(`http://host.docker.internal:${px.port}`))) args.push('-e', `${k}=${v}`);
    } else args.push('--network', 'none');
    args.push(sb.image || DEFAULT_IMAGE, 'sh', '-c', command);
    const r = ['docker', args, {}];
    r.kill = () => execFile('docker', ['rm', '-f', name], { windowsHide: true }, () => {});
    return r;
  }
  if (sb.kind === 'ssh') {
    if (!sb.host) throw new Error('Песочнице ssh нужен компьютер: /sandbox ssh user@host');
    const o = { host: sb.host, port: sb.port || 0, dir: remoteDir(sb, cwd), cwd, command, exclude: SYNC_EXCLUDE };
    return [process.execPath, ['-e', `(${sshRunner.toString()})(JSON.parse(process.argv[1]))`, JSON.stringify(o)], {}];
  }
  throw new Error('Песочница недоступна');
}

/** Output that looks like the sandbox stopped the command: a hint for the model to ask for it unsandboxed. */
export const SANDBOX_HINT = /Read-only file system|Couldn't connect to server|Connection refused|Operation not permitted|Network is unreachable|Could not resolve host|getaddrinfo E(AI_AGAIN|NOTFOUND)|Temporary failure in name resolution|ENETUNREACH|EROFS|EPERM|Access is denied|Отказано в доступе|403 Forbidden/;

