// Status line under each answer: model, how full the context is, reasoning depth, mode, sandbox, git branch, what
// the request cost and the balance. `/statusline` turns it off and on.
//
// Your own line, as in Claude Code: "statusLine": { "type": "command", "command": "~/bin/status.sh" } in
// ~/.klinch/settings.json (or ~/.claude/settings.json). The command gets the session as JSON on stdin and its first
// lines of output replace the built-in line. Only your own settings count: a repository cannot run commands this way.
import { spawnSync, execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';

const readJson = (p) => { try { return JSON.parse(readFileSync(p, 'utf8')); } catch { return null; } };
const k = (n) => (n >= 1000 ? `${Math.round(n / 1000)}K` : String(Math.round(n || 0)));

/** The user's statusLine command, or null. */
export function statusCommand(env = process.env) {
  const home = env.KLINCH_HOME || join(homedir(), '.klinch');
  for (const f of [join(home, 'settings.json'), join(env.HOME || homedir(), '.claude', 'settings.json')]) {
    const s = readJson(f)?.statusLine;
    if (s && typeof s.command === 'string' && s.command.trim()) return { command: s.command.replace(/^~(?=\/)/, env.HOME || homedir()), padding: +s.padding || 0 };
  }
  return null;
}

export function gitBranch(cwd) {
  try { return execFileSync('git', ['rev-parse', '--abbrev-ref', 'HEAD'], { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'], timeout: 2000 }).trim(); } catch { return ''; }
}

/** The JSON a statusLine command reads (the fields Claude Code's scripts use, plus this agent's own under `agent`). */
export function statusJson(i) {
  return {
    hook_event_name: 'Status', session_id: i.sessionId, cwd: i.cwd, version: i.version,
    model: { id: i.model, display_name: i.model },
    workspace: { current_dir: i.cwd, project_dir: i.projectDir || i.cwd },
    output_style: { name: i.style || 'default' },
    context_window: { used_tokens: i.contextTokens || 0, compact_at: i.compactAt, used_percentage: i.compactAt ? Math.round(100 * (i.contextTokens || 0) / i.compactAt) : null },
    cost: { request_tokens: i.spent ?? null },
    agent: { balance: i.balance ?? null, effort: i.effort || 'auto', mode: i.mode, sandbox: !!i.sandbox, branch: i.branch || null },
  };
}

/** The built-in line (plain text; the caller dims it). */
export function builtinLine(i) {
  const pct = i.compactAt ? Math.min(100, Math.round(100 * (i.contextTokens || 0) / i.compactAt)) : null;
  const bar = pct == null ? '' : '▰'.repeat(Math.round(pct / 20)) + '▱'.repeat(5 - Math.round(pct / 20)) + ' ';
  return [
    i.model,
    `контекст ${bar}${k(i.contextTokens)}${i.compactAt ? `/${k(i.compactAt)}` : ''}`,
    i.effort && `мысли ${i.effort}`,
    i.mode === 'plan' && 'план', i.mode === 'debug' && 'отладка',
    i.sandbox && 'песочница',
    i.style && i.style !== 'default' && `стиль ${i.style}`,
    i.branch && `⎇ ${i.branch}`,
    i.spent != null && i.spent > 0 && `−${Math.round(i.spent).toLocaleString('ru-RU')}`,
    i.balance != null && `баланс ${Math.round(i.balance).toLocaleString('ru-RU')}`,
  ].filter(Boolean).join(' · ');
}

/** The user's command's output for this state, or null when there is none or it failed. */
export function customLine(cmd, info, env = process.env) {
  if (!cmd) return null;
  const r = spawnSync(process.platform === 'win32' ? 'cmd.exe' : '/bin/sh', process.platform === 'win32' ? ['/d', '/s', '/c', cmd.command] : ['-c', cmd.command], {
    cwd: info.cwd, env: { ...env, KLINCH_PROJECT_DIR: info.projectDir || info.cwd, CLAUDE_PROJECT_DIR: info.projectDir || info.cwd },
    input: JSON.stringify(statusJson(info)), encoding: 'utf8', timeout: 3000, maxBuffer: 64 * 1024,
  });
  if (r.status !== 0 || !r.stdout?.trim()) return null;
  return r.stdout.replace(/\s+$/, '').split('\n').slice(0, 3).join('\n');
}
