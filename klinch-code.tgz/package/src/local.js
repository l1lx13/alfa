// `klinch connect`: lets the Klinch AI chat in the browser work in folders on this computer («Работать локально»).
//
// No port is opened here: the CLI asks klinch.cloud for work (long poll, /v1/local/poll) with the saved key and posts
// each answer back. A call runs only if it is signed (HMAC-SHA256) with this computer's pairing secret, which the CLI
// prints once inside a link (#pair=… in the URL fragment, never sent to the server). So neither the server nor
// someone who learned the key can run anything here; only a browser the user opened that link in can.
// Files and commands are confined to folders the user bound (here or from the browser that holds the secret).
import { createHmac, randomBytes, timingSafeEqual } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync, statSync, readdirSync, unlinkSync, chmodSync } from 'node:fs';
import { homedir, hostname, platform } from 'node:os';
import { join, resolve, basename, dirname } from 'node:path';
import { spawn } from 'node:child_process';
import { toolByName, safePath } from './tools.js';
import { BROWSER_TOOL, browserUrl } from './browser.js';
import { COMPUTER_TOOL } from './computer.js';

export const VERSION = '0.6.8';
const MAX_READ = 2_000_000;
const SKEW_MS = 5 * 60_000;

const dir = (env) => env.KLINCH_HOME || join(homedir(), '.klinch');
export const statePath = (env = process.env) => join(dir(env), 'local.json');

/** This computer's id, pairing secret and bound folders (~/.klinch/local.json, mode 600). */
export function loadState(env = process.env) {
  let s = {};
  try { s = JSON.parse(readFileSync(statePath(env), 'utf8')); } catch { /* first run */ }
  if (!/^dev_[A-Za-z0-9_-]{16,40}$/.test(s.deviceId || '')) s.deviceId = 'dev_' + randomBytes(16).toString('base64url');
  if (typeof s.secret !== 'string' || s.secret.length < 32) s.secret = randomBytes(32).toString('base64url');
  if (!Array.isArray(s.folders)) s.folders = [];
  return s;
}

export function saveState(s, env = process.env) {
  mkdirSync(dir(env), { recursive: true, mode: 0o700 });
  writeFileSync(statePath(env), JSON.stringify(s, null, 2) + '\n', { mode: 0o600 });
  try { chmodSync(statePath(env), 0o600); } catch { /* Windows */ }
}

export function addFolder(s, p) {
  const abs = resolve(String(p || ''));
  let st;
  try { st = statSync(abs); } catch { throw new Error(`Папка не найдена: ${abs}`); }
  if (!st.isDirectory()) throw new Error(`Это не папка: ${abs}`);
  if (abs === resolve(homedir()) || abs === dirname(abs)) throw new Error(`Нельзя привязать домашнюю папку или корень диска целиком: ${abs}`);
  if (!s.folders.some((f) => f.path === abs)) s.folders.push({ path: abs, name: basename(abs) || abs });
  return abs;
}

export const pairLink = (baseUrl, s) => `${baseUrl}/console/code#pair=${s.deviceId}.${s.secret}`;

const sign = (secret, payload) => createHmac('sha256', secret).update(payload).digest('hex');

/** Checks a call from the cabinet: signature, this device, fresh timestamp, nonce not seen before. */
export function verifyCall(s, call, seen = new Map(), now = Date.now()) {
  if (typeof call?.payload !== 'string' || typeof call?.sig !== 'string') throw new Error('unsigned');
  const want = Buffer.from(sign(s.secret, call.payload)), got = Buffer.from(call.sig);
  if (want.length !== got.length || !timingSafeEqual(want, got)) throw new Error('bad_signature');
  const p = JSON.parse(call.payload);
  if (p.d !== s.deviceId) throw new Error('wrong_device');
  if (!(Math.abs(now - Number(p.ts)) < SKEW_MS)) throw new Error('expired');
  if (typeof p.n !== 'string' || seen.has(p.n)) throw new Error('replay');
  for (const [n, t] of seen) if (now - t > 2 * SKEW_MS) seen.delete(n);
  seen.set(p.n, now);
  return p;
}

function folderOf(s, path) {
  const f = s.folders.find((x) => x.path === path);
  if (!f) throw new Error(`Папка не привязана к Klinch: ${path}`);
  return f.path;
}

function runShell(command, cwd, timeoutMs) {
  return new Promise((done) => {
    const sh = process.platform === 'win32' ? ['cmd.exe', ['/d', '/s', '/c', command]] : ['/bin/sh', ['-c', command]];
    const child = spawn(sh[0], sh[1], { cwd, env: process.env, stdio: ['ignore', 'pipe', 'pipe'] });
    let out = '';
    const take = (c) => { if (out.length < 120_000) out += c; };
    child.stdout.on('data', take); child.stderr.on('data', take);
    const t = setTimeout(() => { child.kill('SIGKILL'); out += `\n(прервано по таймауту ${Math.round(timeoutMs / 1000)} с)`; }, timeoutMs);
    child.on('error', (e) => { clearTimeout(t); done({ output: `Не удалось запустить: ${e.message}`, code: -1 }); });
    child.on('close', (code) => { clearTimeout(t); done({ output: out.trim(), code: code ?? -1 }); });
  });
}

/** Runs one verified operation. `onChange` is told when the bound folders change. */
export async function runOp(s, op, a = {}, { onChange } = {}) {
  switch (op) {
    case 'info':
      return { name: hostname(), platform: platform(), home: homedir(), folders: s.folders, version: VERSION };
    case 'list_dir': {
      // The folder picker: folders (and, with files=true, files) at any absolute path, names only.
      const abs = resolve(String(a.path || homedir()));
      const entries = readdirSync(abs, { withFileTypes: true })
        .filter((e) => !e.name.startsWith('.') && (a.files || e.isDirectory()))
        .map((e) => ({ name: e.name, dir: e.isDirectory() }))
        .sort((x, y) => Number(y.dir) - Number(x.dir) || x.name.localeCompare(y.name))
        .slice(0, 500);
      return { path: abs, parent: dirname(abs) === abs ? null : dirname(abs), entries };
    }
    case 'bind': {
      const abs = addFolder(s, a.path);
      onChange?.();
      return { path: abs, folders: s.folders };
    }
    case 'unbind':
      s.folders = s.folders.filter((f) => f.path !== a.path);
      onChange?.();
      return { folders: s.folders };
    case 'read': {
      const cwd = folderOf(s, a.folder);
      const abs = safePath(cwd, a.path);
      const st = statSync(abs);
      if (st.isDirectory()) throw new Error(`${a.path} — это папка`);
      const buf = readFileSync(abs).subarray(0, MAX_READ);
      const binary = buf.subarray(0, 8000).includes(0);
      return { size: st.size, binary, truncated: st.size > MAX_READ, content: binary ? '' : buf.toString('utf8') };
    }
    case 'write': {
      const cwd = folderOf(s, a.folder);
      const abs = safePath(cwd, a.path, { write: true });
      mkdirSync(dirname(abs), { recursive: true });
      writeFileSync(abs, String(a.content ?? ''));
      return { ok: true };
    }
    case 'delete': {
      const cwd = folderOf(s, a.folder);
      unlinkSync(safePath(cwd, a.path, { write: true }));
      return { ok: true };
    }
    case 'list':
      return { output: toolByName('list_files').run({ path: a.path || '.', depth: a.recursive ? 6 : 1 }, { cwd: folderOf(s, a.folder) }) };
    case 'search':
      return { output: toolByName('search').run({ pattern: a.pattern, path: a.path || '.', glob: a.glob }, { cwd: folderOf(s, a.folder) }) };
    case 'shell': {
      const cwd = folderOf(s, a.folder);
      return runShell(String(a.command || ''), cwd, Math.min(Math.max(+a.timeout_ms || 120_000, 1000), 150_000));
    }
    case 'browser': {
      // The site's agent drives a browser on this computer. Clicks, typing and js on a site off this computer need the
      // user's yes on the call's card (approved), the same rule the terminal agent follows.
      const cwd = a.folder ? folderOf(s, a.folder) : undefined;
      if (BROWSER_TOOL.danger(a) && !a.approved) throw new Error(`Действие на сайте ${new URL(browserUrl()).host}: нужно подтверждение пользователя`);
      const input = a.action === 'design' ? { ...a, wait_sec: Math.min(+a.wait_sec || 150, 150) } : a;
      const r = await BROWSER_TOOL.run(input, { cwd });
      const blocks = Array.isArray(r) ? r : [{ type: 'text', text: String(r ?? '') }];
      return {
        output: blocks.filter((b) => b.type === 'text').map((b) => b.text).join('\n'),
        images: blocks.filter((b) => b.type === 'image').map((b) => `data:${b.source.media_type};base64,${b.source.data}`),
        url: browserUrl(),
      };
    }
    case 'computer': {
      // Screen, mouse and keyboard of this computer for the site's agent: every action except looking needs the
      // user's yes on the call's card.
      if (COMPUTER_TOOL.danger(a) && !a.approved) throw new Error('Действие с мышью или клавиатурой: нужно подтверждение пользователя');
      const r = await COMPUTER_TOOL.run(a, {});
      const blocks = Array.isArray(r) ? r : [{ type: 'text', text: String(r ?? '') }];
      return {
        output: blocks.filter((b) => b.type === 'text').map((b) => b.text).join('\n'),
        images: blocks.filter((b) => b.type === 'image').map((b) => `data:${b.source.media_type};base64,${b.source.data}`),
      };
    }
    default:
      throw new Error(`Неизвестная операция: ${op}`);
  }
}

/**
 * The connect loop: registers this computer, then polls for calls until `signal` aborts.
 * `log(line)` prints progress; returns when stopped, throws on a key the server refuses.
 */
export async function serve({ baseUrl, apiKey, env = process.env, signal, log = () => {}, fetchImpl = fetch, state }) {
  const s = state || loadState(env);
  const headers = { authorization: 'Bearer ' + apiKey, 'content-type': 'application/json' };
  const register = async () => {
    const r = await fetchImpl(`${baseUrl}/v1/local/device`, { method: 'POST', headers, signal,
      body: JSON.stringify({ id: s.deviceId, name: hostname(), platform: platform(), home: homedir(), folders: s.folders, version: VERSION }) });
    if (r.status === 401) throw new Error('Ключ не принят. Проверьте его: klinch login');
    if (r.status === 409) { s.deviceId = 'dev_' + randomBytes(16).toString('base64url'); saveState(s, env); return register(); }
    if (!r.ok) throw new Error(`Не удалось подключиться: ошибка ${r.status}`);
  };
  const onChange = () => { saveState(s, env); register().catch((e) => log(`! ${e.message}`)); };
  saveState(s, env);
  await register();
  const seen = new Map();
  const answer = (id, response) => fetchImpl(`${baseUrl}/v1/local/answer`, { method: 'POST', headers, body: JSON.stringify({ device: s.deviceId, id, response }) })
    .catch((e) => log(`! ответ не отправлен: ${e.message}`));
  const handle = async (call) => {
    let p;
    try { p = verifyCall(s, call, seen); } catch (e) {
      log(`! отклонён запрос без верной подписи (${e.message})`);
      return answer(call.id, { ok: false, error: 'Компьютер не принял запрос: этот браузер не привязан к нему. Откройте ссылку из klinch connect ещё раз.', code: 'unpaired' });
    }
    if (p.op !== 'info' && p.op !== 'list_dir') log(`▸ ${p.op}${p.args?.action ? ` ${p.args.action}${p.args.url ? ' ' + p.args.url : ''}` : p.args?.command ? ` $ ${String(p.args.command).slice(0, 80)}` : p.args?.path ? ` ${p.args.path}` : ''}`);
    try { await answer(call.id, { ok: true, result: await runOp(s, p.op, p.args || {}, { onChange }) }); }
    catch (e) { await answer(call.id, { ok: false, error: e.message }); }
  };
  let backoff = 1000;
  while (!signal?.aborted) {
    try {
      const r = await fetchImpl(`${baseUrl}/v1/local/poll?device=${encodeURIComponent(s.deviceId)}`, { headers, signal });
      if (r.status === 401) throw Object.assign(new Error('Ключ не принят. Проверьте его: klinch login'), { fatal: true });
      if (r.status === 404) { log('Компьютер был отвязан в кабинете, подключаю заново…'); await register(); continue; }
      if (!r.ok) throw new Error(`ошибка ${r.status}`);
      const { calls = [] } = await r.json();
      for (const c of calls) void handle(c);
      backoff = 1000;
    } catch (e) {
      if (signal?.aborted) break;
      if (e.fatal) throw e;
      log(`! нет связи с ${baseUrl} (${e.message}), повтор через ${Math.round(backoff / 1000)} с`);
      await new Promise((r) => setTimeout(r, backoff));
      backoff = Math.min(backoff * 2, 30_000);
    }
  }
}

/** Opens the pairing link in the default browser (best effort). */
export function openBrowser(url) {
  const cmd = process.platform === 'darwin' ? ['open', [url]] : process.platform === 'win32' ? ['cmd', ['/c', 'start', '""', url.replace(/&/g, '^&')]] : ['xdg-open', [url]];
  try { spawn(cmd[0], cmd[1], { stdio: 'ignore', detached: true }).on('error', () => {}).unref(); } catch { /* no browser */ }
}
