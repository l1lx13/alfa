// `klinch import [claude|codex|openclaw]`: moves your settings from other agents into ~/.klinch, so nothing has to be
// set up twice. First it shows what it would do, then does it after «y» (or right away with -y).
//
//   Claude Code  ~/.claude/settings.json (permissions, hooks, statusLine), MCP servers from ~/.claude.json (yours and
//                this folder's), ~/.claude/CLAUDE.md, ~/.claude/commands, ~/.claude/skills
//   Codex        [mcp_servers.*] from ~/.codex/config.toml, ~/.codex/AGENTS.md, ~/.codex/prompts (→ commands),
//                ~/.codex/skills
//   OpenClaw     ~/.openclaw/workspace: AGENTS.md, SOUL.md, USER.md, IDENTITY.md, TOOLS.md (→ instructions),
//                MEMORY.md (→ memory), skills; MCP servers from ~/.openclaw/openclaw.json
//
// Nothing of yours is overwritten: a server, command or skill that already exists here is skipped, rules and hooks
// are added to yours, instruction files are appended to ~/.klinch/KLINCH.md once.
import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync, statSync, copyFileSync, chmodSync } from 'node:fs';
import { homedir } from 'node:os';
import { join, basename } from 'node:path';
import { editMemory } from './memory.js';

const home = (env) => env.KLINCH_HOME || join(homedir(), '.klinch');
const userHome = (env) => env.HOME || env.USERPROFILE || homedir();
const read = (p) => { try { return readFileSync(p, 'utf8'); } catch { return null; } };
const readJson = (p) => { const t = read(p); if (t == null) return null; try { return JSON.parse(t); } catch { return null; } };
const isDir = (p) => { try { return statSync(p).isDirectory(); } catch { return false; } };
const list = (p) => { try { return readdirSync(p); } catch { return []; } };
function writeJson(p, v) {
  mkdirSync(join(p, '..'), { recursive: true, mode: 0o700 });
  writeFileSync(p, JSON.stringify(v, null, 2) + '\n', { mode: 0o600 });
  try { chmodSync(p, 0o600); } catch { /* Windows */ }
}
function copyTree(from, to) {
  mkdirSync(to, { recursive: true });
  for (const n of list(from)) {
    const a = join(from, n), b = join(to, n);
    if (isDir(a)) copyTree(a, b); else if (!existsSync(b)) copyFileSync(a, b);
  }
}

/* ---------------- small parsers ---------------- */

/** Enough TOML for Codex's config: tables, dotted keys, strings, numbers, booleans, arrays, inline tables. */
export function parseToml(text) {
  const root = {};
  let cur = root;
  const at = (obj, keys) => { for (const k of keys) obj = obj[k] && typeof obj[k] === 'object' && !Array.isArray(obj[k]) ? obj[k] : (obj[k] = {}); return obj; };
  const splitKey = (s) => [...s.matchAll(/"((?:[^"\\]|\\.)*)"|'([^']*)'|([A-Za-z0-9_-]+)/g)].map((m) => m[1] ?? m[2] ?? m[3]);
  const src = String(text);
  let i = 0;
  const ws = () => { for (;;) { while (/[ \t\r\n]/.test(src[i] || '')) i++; if (src[i] === '#') { while (i < src.length && src[i] !== '\n') i++; } else return; } };
  const value = () => {
    ws();
    const ch = src[i];
    if (src.startsWith('"""', i) || src.startsWith("'''", i)) {
      const q = src.slice(i, i + 3), j = src.indexOf(q, i + 3); const s = src.slice(i + 3, j).replace(/^\r?\n/, ''); i = j + 3;
      return q === '"""' ? unesc(s) : s;
    }
    if (ch === '"') { let j = i + 1; while (j < src.length && src[j] !== '"') j += src[j] === '\\' ? 2 : 1; const s = unesc(src.slice(i + 1, j)); i = j + 1; return s; }
    if (ch === "'") { const j = src.indexOf("'", i + 1); const s = src.slice(i + 1, j); i = j + 1; return s; }
    if (ch === '[') {
      i++; const arr = [];
      for (;;) { ws(); if (src[i] === ']') { i++; return arr; } arr.push(value()); ws(); if (src[i] === ',') i++; }
    }
    if (ch === '{') {
      i++; const obj = {};
      for (;;) {
        ws(); if (src[i] === '}') { i++; return obj; }
        const m = /^((?:"[^"]*"|'[^']*'|[A-Za-z0-9_.-]+|\s)+?)\s*=/.exec(src.slice(i));
        if (!m) throw new Error('TOML: не разобрать «' + src.slice(i, i + 30) + '»');
        i += m[0].length; const ks = splitKey(m[1]); at(obj, ks.slice(0, -1))[ks.at(-1)] = value(); ws(); if (src[i] === ',') i++;
      }
    }
    const m = /^[^,\]\}\r\n#]+/.exec(src.slice(i)); i += m ? m[0].length : 1;
    const raw = (m?.[0] || '').trim();
    if (raw === 'true' || raw === 'false') return raw === 'true';
    if (/^[+-]?\d[\d_]*(\.\d+)?([eE][+-]?\d+)?$/.test(raw)) return +raw.replace(/_/g, '');
    return raw;
  };
  const unesc = (s) => s.replace(/\\(u[0-9a-fA-F]{4}|U[0-9a-fA-F]{8}|.)/g, (_, e) => (e.length > 1 ? String.fromCodePoint(parseInt(e.slice(1), 16)) : { n: '\n', t: '\t', r: '\r', '"': '"', '\\': '\\' }[e] ?? e));
  for (;;) {
    ws();
    if (i >= src.length) return root;
    if (src.startsWith('[[', i)) { const j = src.indexOf(']]', i); const ks = splitKey(src.slice(i + 2, j)); const parent = at(root, ks.slice(0, -1)); (parent[ks.at(-1)] ||= []).push(cur = {}); i = j + 2; continue; }
    if (src[i] === '[') { const j = src.indexOf(']', i); cur = at(root, splitKey(src.slice(i + 1, j))); i = j + 1; continue; }
    const m = /^((?:"[^"]*"|'[^']*'|[A-Za-z0-9_.-]+|[ \t])+?)[ \t]*=/.exec(src.slice(i));
    if (!m) { while (i < src.length && src[i] !== '\n') i++; continue; }   // a line we do not understand
    i += m[0].length;
    const ks = splitKey(m[1]);
    at(cur, ks.slice(0, -1))[ks.at(-1)] = value();
  }
}

/** JSON5 as OpenClaw writes it: comments, trailing commas, unquoted keys, single quotes. */
export function parseJson5(text) {
  let s = String(text), out = '';
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (ch === '"' || ch === "'") {
      let j = i + 1, body = '';
      while (j < s.length && s[j] !== ch) { if (s[j] === '\\') { body += s[j] + s[j + 1]; j += 2; } else { body += s[j] === '"' ? '\\"' : s[j]; j++; } }
      out += '"' + (ch === "'" ? body.replace(/\\'/g, "'") : body) + '"'; i = j; continue;
    }
    if (ch === '/' && s[i + 1] === '/') { while (i < s.length && s[i] !== '\n') i++; out += '\n'; continue; }
    if (ch === '/' && s[i + 1] === '*') { i = s.indexOf('*/', i + 2) + 1 || s.length; continue; }
    out += ch;
  }
  out = out.replace(/([{,]\s*)([A-Za-z_$][\w$-]*)\s*:/g, '$1"$2":').replace(/,(\s*[}\]])/g, '$1');
  return JSON.parse(out);
}

/* ---------------- what each agent has ---------------- */

/** A Codex [mcp_servers.x] entry → { command, args, env } or { url, headers }. */
function codexServer(s) {
  if (!s || typeof s !== 'object') return null;
  if (s.url) {
    const headers = { ...(s.http_headers || s.headers || {}) };
    if (s.bearer_token_env_var) headers.Authorization = `Bearer \${${s.bearer_token_env_var}}`;
    for (const [k, v] of Object.entries(s.env_http_headers || {})) headers[k] = `\${${v}}`;
    return { url: s.url, ...(Object.keys(headers).length ? { headers } : {}) };
  }
  if (!s.command) return null;
  return { command: s.command, ...(s.args?.length ? { args: s.args } : {}), ...(s.env && Object.keys(s.env).length ? { env: s.env } : {}) };
}

/** OpenClaw keeps MCP servers in a few places depending on version; take whatever looks like a server map. */
function openclawServers(cfg) {
  const maps = [cfg?.mcpServers, cfg?.mcp?.servers, cfg?.mcp?.mcpServers, cfg?.tools?.mcp?.servers, cfg?.plugins?.entries?.mcp?.config?.servers];
  const out = {};
  for (const m of maps) {
    if (!m || typeof m !== 'object') continue;
    for (const [name, s] of Array.isArray(m) ? m.map((x) => [x?.name, x]) : Object.entries(m)) {
      if (!name || !s || typeof s !== 'object' || s.enabled === false) continue;
      const c = s.url ? { url: s.url, ...(s.headers ? { headers: s.headers } : {}) } : s.command ? { command: s.command, ...(s.args?.length ? { args: s.args } : {}), ...(s.env ? { env: s.env } : {}) } : null;
      if (c) out[name] = c;
    }
  }
  return out;
}

/** What `source` has on this computer: { mcp, projectMcp, permissions, hooks, statusLine, instructions, memory, commands, skills }. */
export function scan(source, { cwd, env = process.env }) {
  const H = userHome(env);
  const found = { mcp: {}, projectMcp: {}, permissions: null, hooks: null, statusLine: null, instructions: [], memory: [], commands: [], skills: [] };
  const mdFiles = (d) => list(d).filter((n) => n.endsWith('.md') && !isDir(join(d, n))).map((n) => join(d, n));
  const skillDirs = (d) => list(d).filter((n) => isDir(join(d, n)) && existsSync(join(d, n, 'SKILL.md'))).map((n) => join(d, n));
  const instr = (file, label) => { const t = read(file); if (t?.trim()) found.instructions.push({ file, label, text: t.trim() }); };

  if (source === 'claude') {
    const s = readJson(join(H, '.claude', 'settings.json')) || {};
    if (s.permissions && (s.permissions.allow?.length || s.permissions.deny?.length)) found.permissions = s.permissions;
    if (s.hooks && Object.keys(s.hooks).length) found.hooks = s.hooks;
    if (s.statusLine?.command) found.statusLine = s.statusLine;
    const cj = readJson(join(H, '.claude.json')) || {};
    Object.assign(found.mcp, cj.mcpServers || {});
    Object.assign(found.projectMcp, cj.projects?.[cwd]?.mcpServers || {});
    instr(join(H, '.claude', 'CLAUDE.md'), 'Claude Code (~/.claude/CLAUDE.md)');
    found.commands = mdFiles(join(H, '.claude', 'commands'));
    found.skills = skillDirs(join(H, '.claude', 'skills'));
  } else if (source === 'codex') {
    const codexHome = env.CODEX_HOME || join(H, '.codex');
    const t = read(join(codexHome, 'config.toml'));
    if (t) {
      let cfg; try { cfg = parseToml(t); } catch { cfg = {}; }
      for (const [name, s] of Object.entries(cfg.mcp_servers || {})) { if (s?.enabled === false) continue; const c = codexServer(s); if (c) found.mcp[name] = c; }
    }
    instr(join(codexHome, 'AGENTS.md'), 'Codex (~/.codex/AGENTS.md)');
    found.commands = mdFiles(join(codexHome, 'prompts'));
    found.skills = skillDirs(join(codexHome, 'skills'));
  } else if (source === 'openclaw') {
    const oc = env.OPENCLAW_STATE_DIR || join(H, '.openclaw');
    let cfg = null; const t = read(env.OPENCLAW_CONFIG_PATH || join(oc, 'openclaw.json'));
    if (t) { try { cfg = parseJson5(t); } catch { cfg = null; } }
    Object.assign(found.mcp, openclawServers(cfg));
    const ws = cfg?.agents?.defaults?.workspace?.replace(/^~(?=\/|$)/, H) || join(oc, 'workspace');
    for (const n of ['AGENTS.md', 'SOUL.md', 'USER.md', 'IDENTITY.md', 'TOOLS.md']) instr(join(ws, n), `OpenClaw (${n})`);
    const mem = read(join(ws, 'MEMORY.md'));
    if (mem) found.memory = mem.split('\n').map((l) => l.replace(/^\s*(?:[-*+]|\d+\.)\s+/, '').trim()).filter((l) => l && !/^#/.test(l) && l.length <= 500);
    found.skills = [...skillDirs(join(ws, 'skills')), ...skillDirs(join(oc, 'skills'))];
  } else throw new Error(`Не знаю «${source}». Можно: claude, codex, openclaw`);
  return found;
}

/* ---------------- the plan and applying it ---------------- */

const MARK = (label) => `<!-- импорт: ${label} -->`;

/** Steps for what was found: [{ text, apply() }] (only those that change something). */
export function plan(source, { cwd, env = process.env }) {
  const f = scan(source, { cwd, env }), K = home(env), steps = [];
  const mcpFile = join(K, 'mcp.json'), settingsFile = join(K, 'settings.json'), instrFile = join(K, 'KLINCH.md');

  const mine = readJson(mcpFile)?.mcpServers || {};
  const newMcp = Object.entries(f.mcp).filter(([n, c]) => !mine[n] && c && (c.command || c.url));
  if (newMcp.length) steps.push({ text: `MCP-серверы: ${newMcp.map(([n]) => n).join(', ')} → ~/.klinch/mcp.json`, apply() {
    const cur = readJson(mcpFile) || {}; cur.mcpServers ||= {};
    for (const [n, c] of newMcp) cur.mcpServers[n] ??= c;
    writeJson(mcpFile, cur);
  } });
  const projFile = join(cwd, '.klinch', 'mcp.json'), projMine = readJson(projFile)?.mcpServers || {};
  const newProj = Object.entries(f.projectMcp).filter(([n, c]) => !projMine[n] && !mine[n] && c && (c.command || c.url));
  if (newProj.length) steps.push({ text: `MCP-серверы этой папки: ${newProj.map(([n]) => n).join(', ')} → .klinch/mcp.json (спросит разрешение при первом запуске)`, apply() {
    const cur = readJson(projFile) || {}; cur.mcpServers ||= {};
    for (const [n, c] of newProj) cur.mcpServers[n] ??= c;
    writeJson(projFile, cur);
  } });

  const s = readJson(settingsFile) || {};
  if (f.permissions) {
    const add = {};
    for (const k of ['allow', 'deny']) { const have = new Set(s.permissions?.[k] || []); const xs = (f.permissions[k] || []).filter((r) => typeof r === 'string' && !have.has(r)); if (xs.length) add[k] = xs; }
    const n = Object.values(add).flat().length;
    if (n) steps.push({ text: `Разрешения: ${Object.entries(add).map(([k, xs]) => `${k} ${xs.length}`).join(', ')} → ~/.klinch/settings.json`, apply() {
      const cur = readJson(settingsFile) || {}; cur.permissions ||= {};
      for (const [k, xs] of Object.entries(add)) cur.permissions[k] = [...new Set([...(cur.permissions[k] || []), ...xs])];
      writeJson(settingsFile, cur);
    } });
  }
  if (f.hooks) {
    const have = new Set(Object.entries(s.hooks || {}).flatMap(([ev, xs]) => (xs || []).map((x) => ev + JSON.stringify(x))));
    const add = Object.entries(f.hooks).map(([ev, xs]) => [ev, (Array.isArray(xs) ? xs : []).filter((x) => !have.has(ev + JSON.stringify(x)))]).filter(([, xs]) => xs.length);
    if (add.length) steps.push({ text: `Хуки: ${add.map(([ev, xs]) => `${ev} ${xs.length}`).join(', ')} → ~/.klinch/settings.json (запускают команды на компьютере)`, apply() {
      const cur = readJson(settingsFile) || {}; cur.hooks ||= {};
      for (const [ev, xs] of add) cur.hooks[ev] = [...(cur.hooks[ev] || []), ...xs];
      writeJson(settingsFile, cur);
    } });
  }
  if (f.statusLine && !s.statusLine) steps.push({ text: `Своя строка состояния: ${f.statusLine.command}`, apply() {
    const cur = readJson(settingsFile) || {}; cur.statusLine ??= f.statusLine; writeJson(settingsFile, cur);
  } });

  const instrNow = read(instrFile) || '';
  const newInstr = f.instructions.filter((x) => !instrNow.includes(MARK(x.label)) && !instrNow.includes(x.text));
  if (newInstr.length) steps.push({ text: `Инструкции: ${newInstr.map((x) => x.label).join(', ')} → ~/.klinch/KLINCH.md`, apply() {
    const cur = read(instrFile) || '';
    const add = newInstr.map((x) => `${MARK(x.label)}\n${x.text}\n`).join('\n');
    mkdirSync(K, { recursive: true, mode: 0o700 });
    writeFileSync(instrFile, (cur.trim() ? cur.replace(/\s*$/, '\n\n') : '') + add);
  } });

  if (f.memory.length) steps.push({ text: `Память: ${f.memory.length} записей → ~/.klinch/memory.md`, apply() {
    for (const text of f.memory) editMemory({ action: 'add', scope: 'user', text }, cwd, env);
  } });

  const cmdDir = join(K, 'commands');
  const newCmds = f.commands.filter((p) => !existsSync(join(cmdDir, basename(p))));
  if (newCmds.length) steps.push({ text: `Команды: ${newCmds.map((p) => '/' + basename(p, '.md')).join(' ')} → ~/.klinch/commands`, apply() {
    mkdirSync(cmdDir, { recursive: true });
    for (const p of newCmds) if (!existsSync(join(cmdDir, basename(p)))) copyFileSync(p, join(cmdDir, basename(p)));
  } });
  const skillDir = join(K, 'skills'), seen = new Set();
  const newSkills = f.skills.filter((p) => { const n = basename(p); if (seen.has(n) || existsSync(join(skillDir, n))) return false; seen.add(n); return true; });
  if (newSkills.length) steps.push({ text: `Скиллы: ${newSkills.map((p) => basename(p)).join(', ')} → ~/.klinch/skills`, apply() {
    for (const p of newSkills) copyTree(p, join(skillDir, basename(p)));
  } });
  return steps;
}

export const SOURCES = { claude: 'Claude Code', codex: 'Codex', openclaw: 'OpenClaw' };

/** Plans for each source (all when `which` is empty): [{ source, name, steps }]. */
export function planAll(which, opts) {
  const names = which ? [which === 'claude-code' ? 'claude' : which] : Object.keys(SOURCES);
  return names.map((source) => ({ source, name: SOURCES[source] || source, steps: plan(source, opts) }));
}
