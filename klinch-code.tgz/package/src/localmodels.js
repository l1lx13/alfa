// Local models: `local:<name>` runs on the user's own computer through any OpenAI-compatible server (Ollama,
// LM Studio, llama.cpp, vLLM…), free and offline; everything else goes to the Klinch gateway as before.
// Server: "localUrl" in ~/.klinch/config.json or KLINCH_LOCAL_URL (default Ollama, http://localhost:11434/v1),
// optional "localKey" / KLINCH_LOCAL_KEY. The agent speaks Anthropic Messages; requests and the stream are
// translated here (text, images, tools; reasoning is never shown).
import { ApiError } from './api.js';

export const LOCAL = 'local:';
export const DEFAULT_LOCAL_URL = 'http://localhost:11434/v1';
export const isLocal = (model) => String(model || '').startsWith(LOCAL);

const textOfBlocks = (c) => (typeof c === 'string' ? c : (c || []).map((b) => (b.type === 'text' ? b.text : b.type === 'image' ? '[картинка]' : '')).join('\n'));

/** Anthropic Messages request → OpenAI chat completions request. */
export function toOpenAI(body) {
  const out = [];
  if (body.system) out.push({ role: 'system', content: typeof body.system === 'string' ? body.system : textOfBlocks(body.system) });
  for (const m of body.messages || []) {
    const blocks = typeof m.content === 'string' ? [{ type: 'text', text: m.content }] : m.content || [];
    if (m.role === 'assistant') {
      const text = blocks.filter((b) => b.type === 'text').map((b) => b.text).join('');
      const calls = blocks.filter((b) => b.type === 'tool_use').map((b) => ({ id: b.id, type: 'function', function: { name: b.name, arguments: JSON.stringify(b.input || {}) } }));
      out.push({ role: 'assistant', content: text || (calls.length ? null : ''), ...(calls.length ? { tool_calls: calls } : {}) });
      continue;
    }
    for (const b of blocks.filter((x) => x.type === 'tool_result')) {
      out.push({ role: 'tool', tool_call_id: b.tool_use_id, content: (b.is_error ? 'Ошибка: ' : '') + textOfBlocks(b.content) });
    }
    const parts = blocks.filter((b) => b.type === 'text' || b.type === 'image').map((b) => (b.type === 'text'
      ? { type: 'text', text: b.text }
      : { type: 'image_url', image_url: { url: b.source?.type === 'base64' ? `data:${b.source.media_type};base64,${b.source.data}` : b.source?.url } }));
    if (parts.length) out.push({ role: 'user', content: parts.every((p) => p.type === 'text') ? parts.map((p) => p.text).join('\n') : parts });
  }
  return {
    model: body.model.slice(LOCAL.length), messages: out, max_tokens: body.max_tokens, stream: true, stream_options: { include_usage: true },
    ...(body.tools?.length ? { tools: body.tools.map((t) => ({ type: 'function', function: { name: t.name, description: t.description, parameters: t.input_schema } })) } : {}),
  };
}

const STOP = { tool_calls: 'tool_use', function_call: 'tool_use', length: 'max_tokens', stop: 'end_turn' };

/** Reads an OpenAI chat-completions stream into an Anthropic-style message ({ content, stop_reason, usage }). */
export async function readOpenAIStream(r, { onText = () => {}, onToolStart = () => {}, onThinking = () => {} } = {}) {
  const msg = { content: [], stop_reason: null, usage: { input_tokens: 0, output_tokens: 0 } };
  let text = null, finish = null;
  const calls = new Map();   // index → { id, name, args }
  const dec = new TextDecoder();
  let buf = '';
  const onChunk = (j) => {
    if (j.usage) { msg.usage.input_tokens = j.usage.prompt_tokens || 0; msg.usage.output_tokens = j.usage.completion_tokens || 0; }
    if (j.error) throw new ApiError(500, { error: j.error.message || String(j.error) });
    for (const ch of j.choices || []) {
      const d = ch.delta || {};
      if (d.reasoning_content || d.reasoning) onThinking();
      if (d.content) { if (!text) { text = { type: 'text', text: '' }; msg.content.push(text); } text.text += d.content; onText(d.content); }
      for (const tc of d.tool_calls || []) {
        const k = tc.index ?? calls.size;
        let c = calls.get(k);
        if (!c) { c = { id: tc.id || `call_${k}_${Date.now().toString(36)}`, name: '', args: '' }; calls.set(k, c); }
        if (tc.id) c.id = tc.id;
        if (tc.function?.name) { if (!c.name) onToolStart({ name: tc.function.name }); c.name += tc.function.name; }
        if (tc.function?.arguments) c.args += tc.function.arguments;
      }
      if (ch.finish_reason) finish = ch.finish_reason;
    }
  };
  for await (const chunk of r.body) {
    buf += dec.decode(chunk, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
      if (!line.startsWith('data:')) continue;
      const data = line.slice(5).trim();
      if (data === '[DONE]') continue;
      let j; try { j = JSON.parse(data); } catch { continue; }
      onChunk(j);
    }
  }
  for (const c of calls.values()) {
    const b = { type: 'tool_use', id: c.id, name: c.name, input: {} };
    try { b.input = c.args ? JSON.parse(c.args) : {}; } catch { b.badInput = c.args; }
    msg.content.push(b);
  }
  msg.stop_reason = calls.size ? 'tool_use' : finish ? STOP[finish] || 'end_turn' : 'interrupted';
  return msg;
}

/**
 * Wraps the gateway client: `local:*` models are answered by the local server, and models() lists them too
 * (when the server is running). Nothing else changes.
 */
export function withLocal(client, { localUrl, localKey } = {}, fetchImpl = fetch) {
  const base = String(localUrl || DEFAULT_LOCAL_URL).replace(/\/+$/, '');
  const headers = { 'content-type': 'application/json', ...(localKey ? { authorization: 'Bearer ' + localKey } : {}) };
  const down = (e) => new Error(`Локальная модель недоступна (${base}): ${e.cause?.code || e.message}. Запустите сервер (Ollama: ollama serve) или укажите адрес: "localUrl" в ~/.klinch/config.json`);
  async function localModels() {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 1500); t.unref?.();
    try {
      const r = await fetchImpl(base + '/models', { headers, signal: ctl.signal });
      if (!r.ok) return [];
      return ((await r.json()).data || []).map((m) => ({ id: LOCAL + m.id, provider: 'local', local: true, multipliers: { input: 0, output: 0 } }));
    } catch { return []; } finally { clearTimeout(t); }
  }
  return {
    ...client,
    localModels,
    async models() {
      const [remote, local] = await Promise.all([client.models(), localModels()]);
      return [...remote, ...local];
    },
    async stream(body, o = {}) {
      if (!isLocal(body.model)) return client.stream(body, o);
      let r;
      try { r = await fetchImpl(base + '/chat/completions', { method: 'POST', headers, body: JSON.stringify(toOpenAI(body)), signal: o.signal }); }
      catch (e) { if (e.name === 'AbortError') return { content: [], stop_reason: 'interrupted', usage: {} }; throw down(e); }
      if (!r.ok) {
        let b; try { b = await r.json(); } catch { b = undefined; }
        const err = new ApiError(r.status, { error: b?.error?.message || b?.error || `локальный сервер ответил ${r.status}` });
        if (r.status === 404) err.message = `Локальной модели ${body.model.slice(LOCAL.length)} нет. Скачайте её (ollama pull ${body.model.slice(LOCAL.length)}) или посмотрите /models`;
        throw err;
      }
      try { return await readOpenAIStream(r, o); }
      catch (e) { if (e.name === 'AbortError' || o.signal?.aborted) return { content: [], stop_reason: 'interrupted', usage: {} }; throw e; }
    },
  };
}
