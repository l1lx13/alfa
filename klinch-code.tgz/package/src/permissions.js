// Permission rules: which actions run without the «Выполнить?» question, and which never run.
//
// Rules look like Claude Code's: `shell(npm test)` (exactly this command), `shell(git status:*)` (this command with
// any arguments), `shell(npm run *)` (glob), `edit_file`, `write_file(src/**)` (paths), `mcp__github__*` (tool glob).
// A shell line with && ; | is allowed only when every part is allowed.
//
// Where they come from:
//   ~/.klinch/settings.json            { "permissions": { "allow": [...], "deny": [...] } }  — yours, always on
//   ~/.klinch/permissions.json         rules you added with «p» at the prompt, per project folder
//   <project>/.klinch/settings.json, <project>/.claude/settings.json
//                                      deny rules always apply; allow rules only after you accepted them once,
//                                      since a cloned repository could otherwise allow itself anything
//   klinch --allow "shell(npm test)"   for this run
import { readFileSync, writeFileSync, mkdirSync, chmodSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { homedir } from 'node:os';
import { join, resolve, relative, isAbsolute } from 'node:path';
import { globToRegExp } from './tools.js';

const dir = (env) => env.KLINCH_HOME || join(homedir(), '.klinch');
const readJson = (p) => { try { return JSON.parse(readFileSync(p, 'utf8')); } catch { return null; } };
function writeJson(p, v, env) {
  mkdirSync(dir(env), { recursive: true, mode: 0o700 });
  writeFileSync(p, JSON.stringify(v, null, 2) + '\n', { mode: 0o600 });
  try { chmodSync(p, 0o600); } catch { /* Windows */ }
}
const list = (v) => (Array.isArray(v) ? v.filter((x) => typeof x === 'string' && x.trim()).map((x) => x.trim()) : []);

export function parseRule(rule) {
  const m = /^([^()]+?)(?:\((.*)\))?$/.exec(String(rule).trim());
  return m ? { tool: m[1].trim(), arg: m[2] } : { tool: String(rule), arg: undefined };
}

const wild = (pattern, s) => new RegExp('^' + pattern.split('*').map((x) => x.replace(/[.+?^${}()|[\]\\]/g, '\\$&')).join('.*') + '$', 's').test(s);

/** Splits a shell line into its simple commands (&&, ||, ;, |, new lines). Quotes are respected roughly. */
export function shellParts(cmd) {
  const parts = [];
  let cur = '', q = null;
  for (let i = 0; i < cmd.length; i++) {
    const ch = cmd[i];
    if (q) { cur += ch; if (ch === q) q = null; continue; }
    if (ch === '"' || ch === "'") { q = ch; cur += ch; continue; }
    if (ch === ';' || ch === '\n' || ch === '|' || (ch === '&' && cmd[i + 1] === '&')) {
      parts.push(cur); cur = '';
      if ((ch === '|' && (cmd[i + 1] === '|' || cmd[i + 1] === '&')) || ch === '&') i++;
      continue;
    }
    // A lone & runs the command before it in the background and starts the next one: `npm test & rm -rf ~` is two
    // commands, not an `npm test` with arguments. Redirects (2>&1, &>file, >&2) keep their &.
    if (ch === '&' && cmd[i - 1] !== '>' && cmd[i - 1] !== '<' && cmd[i + 1] !== '>') { parts.push(cur); cur = ''; continue; }
    cur += ch;
  }
  parts.push(cur);
  return parts.map((p) => p.trim()).filter(Boolean);
}

/** Substitutions ($(…), backticks) and redirects to files can do anything, so a pattern never covers them. */
const risky = (part) => /\$\(|`/.test(part) || />\s*[^&\s]/.test(part.replace(/\d?>&\d/g, '').replace(/>\s*\/dev\/null/g, ''));

function helper(part, cwd) {
  if (risky(part)) return false;
  const cd = /^cd\s+("([^"]+)"|'([^']+)'|(\S+))\s*$/.exec(part);
  if (cd) { // cd into the project (relative or absolute) is fine, anywhere else is not
    if (!cwd) return !/^(\/|~|\.\.)/.test(cd[2] || cd[3] || cd[4]);
    const rel = relative(cwd, resolve(cwd, (cd[2] || cd[3] || cd[4]).replace(/^~(?=\/|$)/, homedir())));
    return rel === '' || (!rel.startsWith('..') && !isAbsolute(rel));
  }
  return /^(pwd|echo|true|tail|head|grep|wc|sort|uniq|cat)(\s|$)/.test(part) && !/(^|\s)(\/|~|\.\.)/.test(part.replace(/^\S+\s*/, '').replace(/-\S+/g, ''));
}

function argMatches(tool, arg, input) {
  if (arg === undefined || arg === '*') return true;
  if (tool === 'shell') return null; // handled per part
  const path = input?.path ?? input?.url;
  if (path == null) return wild(arg, JSON.stringify(input || {}));
  return /^https?:/.test(path) ? wild(arg, path) : globToRegExp(arg).test(String(path).replace(/^\.\//, ''));
}

function partMatches(arg, part, forDeny = false) {
  if (arg === undefined || arg === '*') return true;
  if (risky(part) && !forDeny) return false;
  if (arg.endsWith(':*')) { const p = arg.slice(0, -2).trim(); return part === p || part.startsWith(p + ' '); }
  return arg.includes('*') ? wild(arg, part) : part === arg.trim();
}

/** Does this rule cover the call? For shell, `parts` are checked one by one by the caller. */
function covers(rule, name, input, part, forDeny = false) {
  const r = parseRule(rule);
  if (!wild(r.tool, name)) return false;
  if (name === 'shell') return partMatches(r.arg, part, forDeny);
  return argMatches(name, r.arg, input) !== false;
}

/** 'deny' | 'allow' | null (ask as usual). */
export function decide({ allow = [], deny = [] }, name, input = {}, cwd = null) {
  if (name === 'shell') {
    const parts = shellParts(String(input.command || ''));
    if (!parts.length) return null;
    if (parts.some((p) => deny.some((r) => covers(r, name, input, p, true)))) return 'deny';
    // `cd dir && npm test 2>&1 | tail -20`: helpers that only move around or trim output ride along with a part the
    // user allowed, so a rule like shell(npm test:*) keeps working however the model wraps the command.
    const ok = parts.map((p) => allow.some((r) => covers(r, name, input, p)));
    return ok.some(Boolean) && parts.every((p, i) => ok[i] || helper(p, cwd)) ? 'allow' : null;
  }
  if (deny.some((r) => covers(r, name, input))) return 'deny';
  return allow.some((r) => covers(r, name, input)) ? 'allow' : null;
}

/** The rule offered at the prompt for «always allow things like this here». */
export function suggestRule(name, input = {}) {
  if (name !== 'shell') return name;
  const parts = shellParts(String(input.command || ''));
  if (parts.length !== 1 || risky(parts[0])) return null;
  const w = parts[0].split(/\s+/);
  const two = ['npm', 'pnpm', 'yarn', 'bun', 'npx', 'git', 'cargo', 'go', 'python', 'python3', 'pip', 'make', 'docker', 'deno', 'node', 'dotnet', 'mvn', 'gradle', 'composer', 'php', 'ruby', 'bundle', 'rails', 'swift', 'xcodebuild', 'flutter', 'dart', 'uv', 'poetry'];
  const head = two.includes(w[0]) && w[1] && !w[1].startsWith('-') ? w.slice(0, 2).join(' ') : w[0];
  if (/^(rm|sudo|curl|wget|sh|bash|zsh|eval|chmod|chown|dd|mkfs)$/.test(w[0])) return null; // ask every time
  return `shell(${head}:*)`;
}

const permsFile = (env) => join(dir(env), 'permissions.json');
const trustFile = (env) => join(dir(env), 'permissions-trust.json');
const projectFiles = (cwd) => [join(cwd, '.claude', 'settings.json'), join(cwd, '.klinch', 'settings.json')];

/** Allow rules a project's own files ask for, and whether the user accepted exactly these. */
export function projectAllow(cwd, env = process.env) {
  const allow = projectFiles(cwd).flatMap((f) => list(readJson(f)?.permissions?.allow));
  const key = cwd + '\0' + createHash('sha256').update(JSON.stringify(allow)).digest('hex');
  return { allow, trusted: !allow.length || !!readJson(trustFile(env))?.[key], key };
}
export function trustProjectAllow(cwd, env = process.env) {
  const { key } = projectAllow(cwd, env);
  const t = readJson(trustFile(env)) || {};
  t[key] = Date.now();
  writeJson(trustFile(env), t, env);
}

/** All rules for this folder. `extraAllow` = --allow flags; project allow rules only when trusted. */
export function loadPermissions(cwd, env = process.env, { extraAllow = [], projectAllowed = null } = {}) {
  const user = readJson(join(dir(env), 'settings.json'))?.permissions || {};
  const mine = readJson(permsFile(env))?.projects?.[cwd] || [];
  const proj = projectAllow(cwd, env);
  const allow = [...list(user.allow), ...list(mine), ...list(extraAllow), ...((projectAllowed ?? proj.trusted) ? proj.allow : [])];
  const deny = [...list(user.deny), ...projectFiles(cwd).flatMap((f) => list(readJson(f)?.permissions?.deny))];
  return { allow, deny };
}

/** Saves an allow rule for this folder (the «p» answer). */
export function addRule(cwd, rule, env = process.env) {
  const p = readJson(permsFile(env)) || {};
  p.projects ||= {};
  p.projects[cwd] = [...new Set([...(p.projects[cwd] || []), rule])];
  writeJson(permsFile(env), p, env);
}
