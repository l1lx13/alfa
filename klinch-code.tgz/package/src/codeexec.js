// The `python` tool: the agent runs a Python script that can call the agent's own tools as functions
// (tools.read_file(path="a.py"), tools.search(pattern="TODO"), tools.shell(command="npm test"), MCP tools too).
// One script replaces dozens of model steps: loop over files, filter results, combine outputs, and only the
// final print() goes back to the model.
//
// Each tool call from the script goes through the same checks as a call from the model: permission rules, hooks,
// the «Выполнить?» question for actions that change something. The script itself is a program on the computer, so
// it asks before it runs, unless the sandbox is on (then it runs inside it, like shell).
// Protocol: the script writes one JSON request per line to fd 3 and reads the answer from fd 4.
import { spawn } from 'node:child_process';
import { wrapCommand, prepareSandbox, keepsDescriptors } from './sandbox.js';

const MAX_OUT = 30000;
const PRELUDE = String.raw`
import json, os, sys
_req = os.fdopen(3, "w", buffering=1)
_res = os.fdopen(4, "r")
class ToolError(Exception):
    pass
class ToolText(str):
    """A tool's text result. Iterating it gives lines (glob and search list one item per line), not characters."""
    def __iter__(self):
        return iter(self.splitlines())
class _Tools:
    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        def call(**kw):
            _req.write(json.dumps({"tool": name, "input": kw}) + "\n")
            _req.flush()
            line = _res.readline()
            if not line:
                raise ToolError("agent closed the tool channel")
            r = json.loads(line)
            if r.get("error"):
                raise ToolError(r["error"])
            return ToolText(r["result"])
        return call
tools = _Tools()
_code = sys.stdin.read()
exec(compile(_code, "<script>", "exec"), {"__name__": "__main__", "tools": tools, "ToolError": ToolError})
`;

const NOT_FROM_SCRIPT = new Set(['python', 'task', 'exit_plan_mode', 'ask_user']);
const quote = (s) => `'${String(s).replace(/'/g, `'\\''`)}'`;

/** Runs `code`; `callTool(name, input)` → { content, is_error }. Returns the report for the model. */
export function runPython(code, { cwd, callTool, timeoutMs = 120000, sandbox = null, python = process.platform === 'win32' ? 'python' : 'python3', env = process.env }) {
  return new Promise((done) => {
    const [bin, args, extra] = sandbox ? wrapCommand(sandbox, `${python} -u -c ${quote(PRELUDE)}`, cwd) : [python, ['-u', '-c', PRELUDE]];
    const child = spawn(bin, args, { cwd, env: { ...env, ...(extra || {}), PYTHONIOENCODING: 'utf-8' }, stdio: ['pipe', 'pipe', 'pipe', 'pipe', 'pipe'] });
    let out = '', calls = 0, buf = '', finished = false;
    const take = (c) => { if (out.length < MAX_OUT * 2) out += c; };
    child.stdout.on('data', take); child.stderr.on('data', take);
    const reply = (j) => { try { child.stdio[4].write(JSON.stringify(j) + '\n'); } catch { /* the script is gone */ } };
    child.stdio[4].on('error', () => {});
    let chain = Promise.resolve();
    child.stdio[3].on('data', (d) => {
      buf += d;
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i); buf = buf.slice(i + 1);
        chain = chain.then(async () => {
          let req; try { req = JSON.parse(line); } catch { return reply({ error: 'bad request' }); }
          if (NOT_FROM_SCRIPT.has(req.tool)) return reply({ error: `${req.tool} нельзя вызывать из скрипта` });
          calls++;
          const r = await callTool(String(req.tool), req.input && typeof req.input === 'object' ? req.input : {});
          const text = typeof r.content === 'string' ? r.content : (r.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('\n');
          reply(r.is_error ? { error: text } : { result: text });
        });
      }
    });
    const t = setTimeout(() => { child.kill('SIGKILL'); take(`\n(прервано по таймауту ${timeoutMs / 1000} с)`); }, timeoutMs);
    child.on('error', (e) => { if (finished) return; finished = true; clearTimeout(t); done({ text: `Не удалось запустить ${python}: ${e.message}. Нужен Python 3.`, error: true }); });
    child.on('close', (code) => {
      if (finished) return; finished = true; clearTimeout(t);
      const o = out.trim();
      done({ text: `${o.length > MAX_OUT ? o.slice(0, MAX_OUT) + `\n… (обрезано, всего ${o.length} символов)` : o || '(скрипт ничего не напечатал)'}${code ? `\n(код выхода ${code})` : ''}${calls ? `\n(вызовов инструментов: ${calls})` : ''}`, error: !!code });
    });
    child.stdin.on('error', () => {});
    child.stdin.end(String(code));
  });
}

/** The tool definition; agent.js gives it callTool through ctx. */
export const pythonTool = {
  name: 'python',
  description: 'Выполнить скрипт Python 3, который может вызывать твои инструменты как функции: tools.read_file(path="a.py"), tools.search(pattern="TODO", glob="*.js"), tools.glob(pattern="**/*.md"), tools.shell(command="npm test"), tools.edit_file(...), MCP-инструменты по их имени. Функция возвращает текст результата (цикл for по нему идёт по строкам: tools.glob и tools.search дают по пути на строку), ошибка — исключение ToolError. В ответ приходит только то, что скрипт напечатал. Годится, когда нужно много однотипных вызовов (обойти файлы, отфильтровать, посчитать) за один шаг. Действия, которые что-то меняют, пользователь подтверждает как обычно.',
  danger: true,
  input_schema: { type: 'object', properties: {
    code: { type: 'string', description: 'Код Python 3; результат печатай через print' },
    timeout_sec: { type: 'integer', description: 'Таймаут, по умолчанию 120, до 600' } }, required: ['code'] },
  preview: ({ code }) => `python\n${String(code || '').split('\n').slice(0, 40).map((l) => '  ' + l).join('\n')}`,
  async run({ code, timeout_sec }, ctx) {
    if (!ctx.callTool) throw new Error('Инструменты из скрипта недоступны');
    // Docker, ssh and Windows cannot pass the script's descriptors 3 and 4, so there it runs as usual (and is confirmed).
    const sandbox = ctx.sandbox?.active && keepsDescriptors(ctx.sandbox) ? await prepareSandbox(ctx.sandbox, ctx.cwd) : null;
    const r = await runPython(String(code || ''), { cwd: ctx.cwd, callTool: ctx.callTool, sandbox, timeoutMs: Math.min(Math.max(+timeout_sec || 120, 1), 600) * 1000, env: ctx.env || process.env });
    if (r.error) throw new Error(r.text);
    return r.text;
  },
};
