// Repeating and scheduled tasks, set in plain words: «каждые 10 минут проверь тесты», «каждый день в 9:00 собери
// сводку», «через 2 часа напомни», «every 30m …», or a cron line «0 9 * * 1-5».
//
//   /loop <когда> <задача>     repeats while the chat is open (/loop без задачи: список, /loop stop [id]: стоп)
//   /heartbeat [интервал]      every interval the agent checks the standing goal and does the next step
//   schedule tool              the agent sets tasks itself when asked («напоминай каждый час…»)
//   ~/.klinch/schedules.json   tasks that persist: they run in the open chat of their folder, or with
//                              `klinch daemon` (runs due tasks headless, like `klinch -p`, until stopped)
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';

const MIN = 60_000, HOUR = 60 * MIN, DAY = 24 * HOUR;
const UNITS = [
  [/^(с|сек|секунд[уы]?|секунда|s|sec|secs?|seconds?)$/i, 1000],
  [/^(м|мин|минут[уы]?|минута|m|min|mins?|minutes?)$/i, MIN],
  [/^(ч|час|часа|часов|h|hr|hrs?|hours?)$/i, HOUR],
  [/^(д|дн|день|дня|дней|сутки|суток|d|days?)$/i, DAY],
];
const unitMs = (u) => UNITS.find(([re]) => re.test(u))?.[1];

/** Five-field cron: minute hour day-of-month month day-of-week; *, n, a-b, lists, step /n. */
export function parseCron(expr) {
  const f = String(expr).trim().split(/\s+/);
  if (f.length !== 5) return null;
  const lim = [[0, 59], [0, 23], [1, 31], [1, 12], [0, 7]];
  const sets = f.map((field, i) => {
    const s = new Set();
    for (const part of field.split(',')) {
      const m = /^(\*|\d+)(?:-(\d+))?(?:\/(\d+))?$/.exec(part);
      if (!m) return null;
      let [a, b] = m[1] === '*' ? lim[i] : [+m[1], m[2] != null ? +m[2] : m[3] ? lim[i][1] : +m[1]];
      const step = +(m[3] || 1);
      if (a < lim[i][0] || b > lim[i][1] || a > b || !step) return null;
      for (let v = a; v <= b; v += step) s.add(i === 4 && v === 7 ? 0 : v);
    }
    return s;
  });
  return sets.includes(null) ? null : sets;
}

/** The next time after `from` (ms) that a cron expression fires, or null within a year. */
export function nextCron(expr, from = Date.now()) {
  const c = parseCron(expr);
  if (!c) return null;
  const d = new Date(from); d.setSeconds(0, 0); d.setMinutes(d.getMinutes() + 1);
  for (let i = 0; i < 366 * 24 * 60; i++) {
    if (c[3].has(d.getMonth() + 1) && c[2].has(d.getDate()) && c[4].has(d.getDay()) && c[1].has(d.getHours()) && c[0].has(d.getMinutes())) return d.getTime();
    d.setMinutes(d.getMinutes() + 1);
  }
  return null;
}

/**
 * The time phrase at the start of `text` and the task after it:
 * { spec: { every } | { cron } | { at }, prompt } or null. `now` is for tests.
 */
export function parseWhen(text, now = Date.now()) {
  const t = String(text).trim();
  let m;
  const rest = (s) => t.slice(s.length).replace(/^[\s,:;—-]+/, '').trim();
  // 5m, 2h, 30s, 1d
  if ((m = /^(\d+)\s*([smhd])\b/i.exec(t))) return { spec: { every: +m[1] * unitMs(m[2]) }, prompt: rest(m[0]) };
  // каждые 10 минут / every 10 minutes / раз в 2 часа
  if ((m = /^(?:кажд(?:ые|ую|ый|ое)|every|раз\s+в)\s+(\d+)\s*([a-zа-яё]+)/i.exec(t)) && unitMs(m[2])) return { spec: { every: +m[1] * unitMs(m[2]) }, prompt: rest(m[0]) };
  // каждый день в 9:00 / ежедневно в 9 / every day at 09:30 / по будням в 10
  if ((m = /^(?:каждый\s+день|ежедневно|every\s+day|daily|по\s+будням|weekdays)\s+(?:в|at)\s+(\d{1,2})(?::(\d{2}))?/i.exec(t))) {
    const days = /будн|weekday/i.test(m[0]) ? '1-5' : '*';
    return { spec: { cron: `${+(m[2] || 0)} ${+m[1]} * * ${days}` }, prompt: rest(m[0]) };
  }
  // каждую минуту / каждый час / ежечасно / every hour / hourly
  if ((m = /^(?:каждую\s+минуту|every\s+minute)/i.exec(t))) return { spec: { every: MIN }, prompt: rest(m[0]) };
  if ((m = /^(?:каждый\s+час|ежечасно|every\s+hour|hourly)/i.exec(t))) return { spec: { every: HOUR }, prompt: rest(m[0]) };
  if ((m = /^(?:каждый\s+день|ежедневно|every\s+day|daily)/i.exec(t))) return { spec: { every: DAY }, prompt: rest(m[0]) };
  // через 10 минут / in 2 hours
  if ((m = /^(?:через|in)\s+(\d+)\s*([a-zа-яё]+)/i.exec(t)) && unitMs(m[2])) return { spec: { at: now + +m[1] * unitMs(m[2]) }, prompt: rest(m[0]) };
  // в 18:30 / at 18:30 / завтра в 9
  if ((m = /^(завтра\s+)?(?:в|at)\s+(\d{1,2}):?(\d{2})?(?!\d)/i.exec(t)) && +m[2] < 24) {
    const d = new Date(now); d.setHours(+m[2], +(m[3] || 0), 0, 0);
    if (m[1]) d.setDate(d.getDate() + 1); else if (d.getTime() <= now) d.setDate(d.getDate() + 1);
    return { spec: { at: d.getTime() }, prompt: rest(m[0]) };
  }
  // a cron line
  const f = t.split(/\s+/);
  if (f.length >= 5 && parseCron(f.slice(0, 5).join(' '))) return { spec: { cron: f.slice(0, 5).join(' ') }, prompt: f.slice(5).join(' ') };
  return null;
}

/** When a task next runs after `from`. */
export function nextRun(spec, from = Date.now()) {
  if (spec.at) return spec.at > from ? spec.at : null;
  if (spec.every) return from + Math.max(spec.every, 10_000);
  if (spec.cron) return nextCron(spec.cron, from);
  return null;
}

const ru = (n, one, few, many) => { const a = n % 10, b = n % 100; return a === 1 && b !== 11 ? one : a >= 2 && a <= 4 && (b < 10 || b >= 20) ? few : many; };
export function describe(spec) {
  if (spec.at) return `один раз ${new Date(spec.at).toLocaleString('ru-RU', { dateStyle: 'short', timeStyle: 'short' })}`;
  if (spec.cron) return `по расписанию ${spec.cron}`;
  const e = spec.every;
  for (const [ms, one, w] of [[DAY, 'каждый день', ['день', 'дня', 'дней']], [HOUR, 'каждый час', ['час', 'часа', 'часов']], [MIN, 'каждую минуту', ['минуту', 'минуты', 'минут']], [1000, 'каждую секунду', ['секунду', 'секунды', 'секунд']]]) {
    if (e % ms === 0) { const n = e / ms; return n === 1 ? one : `каждые ${n} ${ru(n, ...w)}`; }
  }
  return `каждые ${Math.round(e / 1000)} с`;
}

const file = (env) => join(env.KLINCH_HOME || join(homedir(), '.klinch'), 'schedules.json');
export function loadSchedules(env = process.env) { try { const j = JSON.parse(readFileSync(file(env), 'utf8')); return Array.isArray(j) ? j : []; } catch { return []; } }
export function saveSchedules(list, env = process.env) {
  mkdirSync(join(file(env), '..'), { recursive: true, mode: 0o700 });
  writeFileSync(file(env), JSON.stringify(list, null, 2) + '\n', { mode: 0o600 });
}

/** Adds a task; `persist: false` keeps it only in memory (a /loop of this chat). Returns it. */
export function addSchedule(list, { cwd, spec, prompt, persist = true, kind = 'task' }, env = process.env, now = Date.now()) {
  const next = nextRun(spec, now);
  if (!next) throw new Error('Не понял, когда запускать');
  const job = { id: 'j' + now.toString(36).slice(-5) + Math.random().toString(36).slice(2, 4), cwd, spec, prompt: String(prompt).trim(), next, kind, persist, created: now, runs: 0 };
  list.push(job);
  if (persist) saveSchedules(list.filter((j) => j.persist), env);
  return job;
}

/** Tasks of `cwd` (or all) due at `now`. Each is moved to its next time (a one-off one is removed). */
export function takeDue(list, { cwd = null, now = Date.now() } = {}, env = process.env) {
  const due = list.filter((j) => j.next <= now && (!cwd || j.cwd === cwd));
  for (const j of due) {
    j.runs++; j.last = now;
    j.next = j.spec.at ? null : nextRun(j.spec, now);
  }
  for (let i = list.length - 1; i >= 0; i--) if (list[i].next == null) list.splice(i, 1);
  if (due.some((j) => j.persist)) {
    const disk = loadSchedules(env).filter((d) => !list.some((j) => j.id === d.id) && !due.some((j) => j.id === d.id));
    saveSchedules([...disk, ...list.filter((j) => j.persist)], env);
  }
  return due;
}

export function removeSchedule(list, id, env = process.env) {
  const i = list.findIndex((j) => j.id === id);
  if (i < 0) return false;
  const [j] = list.splice(i, 1);
  if (j.persist) saveSchedules(loadSchedules(env).filter((d) => d.id !== id), env);
  return true;
}

export const HEARTBEAT_PROMPT = 'Пульс: проверь постоянную цель проекта и текущее состояние (файлы, тесты, список задач). Если есть следующий полезный шаг к цели, сделай его и коротко отчитайся. Если делать нечего, ответь одним словом: ПУЛЬС_ОК.';

/** The agent's tool: add / list / remove tasks in plain words. `jobs` is the live list of this chat. */
export function scheduleTool(jobs, getCwd, env = process.env) {
  return {
    name: 'schedule',
    description: 'Повторяющиеся и отложенные задачи для себя. add: when обычными словами («каждые 15 минут», «каждый день в 9:00», «через 2 часа», «по будням в 10») или cron, prompt — что сделать. list, remove (id). Задачи выполняются, пока открыт чат в этой папке, или фоном через klinch daemon.',
    input_schema: { type: 'object', properties: {
      action: { type: 'string', enum: ['add', 'list', 'remove'] }, when: { type: 'string' }, prompt: { type: 'string' }, id: { type: 'string' } }, required: ['action'] },
    preview: ({ action, when, prompt, id }) => `schedule ${action} ${when || id || ''} ${prompt ? '— ' + String(prompt).slice(0, 80) : ''}`.trim(),
    run({ action, when, prompt, id }) {
      if (action === 'list') return jobs.filter((j) => j.cwd === getCwd()).map((j) => `${j.id}  ${describe(j.spec)}  — ${j.prompt}`).join('\n') || 'Задач нет';
      if (action === 'remove') return removeSchedule(jobs, id, env) ? `Удалена ${id}` : `Нет задачи ${id}`;
      const p = parseWhen(`${when || ''} ${prompt || ''}`);
      if (!p) throw new Error(`Не понял время «${when}». Примеры: «каждые 10 минут», «каждый день в 9:00», «через 2 часа», «0 9 * * 1-5»`);
      const job = addSchedule(jobs, { cwd: getCwd(), spec: p.spec, prompt: prompt || p.prompt }, env);
      return `Задача ${job.id}: ${describe(job.spec)}, первый запуск ${new Date(job.next).toLocaleString('ru-RU')}`;
    },
  };
}
