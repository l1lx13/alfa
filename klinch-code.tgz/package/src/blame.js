// AI blame: which lines of a file the agent wrote, in which session and for which request.
//
// Every successful write_file / edit_file / notebook_edit (also from subagents and python scripts) is recorded: the
// lines the agent added get the id of that request; the lines that were there stay as they were. The store keeps a
// short hash per line, not the code, so changes made by a person (or by a shell command) in between are found by
// comparing the hashes with the file as it is now: lines that no longer match become «человек».
//
//   klinch blame <файл> [-L 10,40] [--json]   строки файла: агент (сессия, запрос, модель, время) или человек
//   klinch blame --stats                      доля строк агента по файлам проекта
//   /blame <файл>[#L10-20]                     то же в чате; инструмент ai_blame — агент сам отвечает «кто это написал»
//
// Stored in ~/.klinch/projects/<hash of the git root>/blame/<hash of the path>.json, one file per source file, so a
// chat and an automation run in the same project do not overwrite each other.
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync, statSync, renameSync } from 'node:fs';
import { dirname, join, relative, resolve, sep, isAbsolute } from 'node:path';
import { projectDir } from './memory.js';
import { diffLines } from './tools.js';

const MAX_BYTES = 2_000_000;
const sha = (s, n) => createHash('sha1').update(s).digest('hex').slice(0, n);
const lineHash = (l) => createHash('md5').update(l.replace(/\s+$/, '')).digest('base64').slice(0, 8);
const hashes = (text) => String(text ?? '').split('\n').map(lineHash);

/** The project a file belongs to: the nearest folder with .git above it, else its own folder. */
export function blameRoot(abs) {
  for (let d = dirname(abs); ; d = dirname(d)) {
    if (existsSync(join(d, '.git'))) return d;
    if (dirname(d) === d) return dirname(abs);
  }
}

const storeDir = (root, env) => join(projectDir(root, env), 'blame');
function where(abs, env) {
  const root = blameRoot(abs), rel = relative(root, abs).split(sep).join('/');
  return { root, rel, file: join(storeDir(root, env), sha(rel, 16) + '.json') };
}
function load(file) { try { const j = JSON.parse(readFileSync(file, 'utf8')); return Array.isArray(j.h) && Array.isArray(j.w) ? j : null; } catch { return null; } }
function save(file, data) {
  mkdirSync(dirname(file), { recursive: true, mode: 0o700 });
  const tmp = `${file}.${process.pid}.tmp`;
  writeFileSync(tmp, JSON.stringify(data), { mode: 0o600 });
  renameSync(tmp, file);
}

/**
 * Carries the owners of `h` / `w` (line hashes and their owners) over to the lines `next`: equal lines keep their
 * owner, new ones get `owner` (0 = a person).
 */
export function carry(h, w, next, owner = 0) {
  if (h.length === next.length && h.every((x, i) => x === next[i])) return w.slice();
  const ops = diffLines(h.join('\n'), next.join('\n'));
  const out = [];
  let i = 0;
  for (const [op] of ops) {
    if (op === '=') out.push(w[i++] || 0);
    else if (op === '-') i++;
    else out.push(owner);
  }
  return out;
}

/** The text with its owners, read against what is on disk now. */
function current(abs, env) {
  const { root, rel, file } = where(abs, env);
  const st = load(file);
  let text;
  try { if (statSync(abs).size > MAX_BYTES) return null; text = readFileSync(abs, 'utf8'); } catch { return null; }
  const h = hashes(text);
  const w = st ? carry(st.h, st.w, h) : h.map(() => 0);
  return { root, rel, file, text, h, w, edits: st?.e || {} };
}

/**
 * Records one edit by the agent. `before` / `after` are the file's text (null = no file). `meta`: { session, turn,
 * prompt, model, tool, automation, trigger, sub }.
 */
export function recordEdit({ abs, before, after, meta = {} }, env = process.env) {
  if (after == null || after.length > MAX_BYTES) return null;
  const { rel, file } = where(abs, env);
  const st = load(file);
  const hb = hashes(before ?? ''), ha = hashes(after);
  // Changes nobody recorded since the last time (a person, a shell command) first: they belong to a person.
  const wb = before == null ? hb.map(() => 0) : st ? carry(st.h, st.w, hb) : hb.map(() => 0);
  const key = sha(`${meta.session || 'run'}#${meta.turn ?? 0}#${meta.automation || ''}`, 8);
  const w = carry(hb, wb, ha, key);
  const edits = { ...(st?.e || {}) };
  if (w.includes(key)) {
    const prev = edits[key];
    edits[key] = {
      session: meta.session || null, turn: meta.turn ?? null, prompt: String(meta.prompt || '').split('\n\n# Событие\n')[0].replace(/\s+/g, ' ').trim().slice(0, 300),
      model: meta.model || null, at: Date.now(), first: prev?.first || Date.now(), tools: [...new Set([...(prev?.tools || []), meta.tool].filter(Boolean))],
      ...(meta.automation ? { automation: meta.automation } : {}), ...(meta.trigger ? { trigger: String(meta.trigger).slice(0, 200) } : {}), ...(meta.sub ? { sub: String(meta.sub).slice(0, 80) } : {}),
    };
  }
  const used = new Set(w);
  for (const k of Object.keys(edits)) if (!used.has(k)) delete edits[k];
  save(file, { path: rel, h: ha, w, e: edits });
  return key;
}

/** Each line: { n, text, by: null (a person) | { id, session, prompt, model, at, … } }. */
export function blameFile(abs, env = process.env) {
  const cur = current(abs, env);
  if (!cur) return null;
  const lines = cur.text.split('\n');
  if (lines.length > 1 && lines.at(-1) === '') lines.pop();
  return { path: cur.rel, root: cur.root, lines: lines.map((text, i) => ({ n: i + 1, text, by: cur.w[i] && cur.edits[cur.w[i]] ? { id: cur.w[i], ...cur.edits[cur.w[i]] } : null })) };
}

/** Files of the project with lines by the agent: [{ path, agent, total, sessions }], most agent lines first. */
export function blameStats(root, env = process.env) {
  const dir = storeDir(root, env), out = [];
  let names = [];
  try { names = readdirSync(dir).filter((n) => n.endsWith('.json')); } catch { return out; }
  for (const n of names) {
    const st = load(join(dir, n));
    if (!st?.path) continue;
    const b = blameFile(resolve(root, st.path), env);
    if (!b) continue;
    const agent = b.lines.filter((l) => l.by).length;
    if (agent) out.push({ path: b.path, agent, total: b.lines.length, sessions: new Set(b.lines.filter((l) => l.by).map((l) => l.by.session)).size });
  }
  return out.sort((a, b) => b.agent - a.agent || a.path.localeCompare(b.path));
}

const when = (t) => new Date(t).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
const who = (b) => `${b.automation ? `автоматизация ${b.automation}` : `сессия ${String(b.session || '—').slice(0, 10)}`}${b.model ? ` · ${b.model}` : ''} · ${when(b.at)}`;

/** `path#L10-20` or `-L 10,20` → { path, from, to }. */
export function parseRange(arg, flag) {
  const m = /^(.*?)(?:#L(\d+)(?:-L?(\d+))?)?$/.exec(String(arg || '').trim());
  let from = m[2] ? +m[2] : null, to = m[3] ? +m[3] : from;
  const f = /^(\d+)(?:[,:-](\d+))?$/.exec(String(flag || ''));
  if (f) { from = +f[1]; to = f[2] ? +f[2] : from; }
  return { path: m[1], from, to };
}

/** The blame as text lines: «  1 │ агент[1] │ code» plus the legend of requests. `paint` colours agent lines. */
export function formatBlame(b, { from = null, to = null, paint = (s) => s, dim = (s) => s } = {}) {
  const lines = b.lines.filter((l) => (!from || l.n >= from) && (!to || l.n <= to));
  const ids = [...new Set(lines.filter((l) => l.by).map((l) => l.by.id))];
  const w = String(lines.at(-1)?.n || 1).length;
  const out = lines.map((l) => {
    const tag = l.by ? `агент[${ids.indexOf(l.by.id) + 1}]` : 'человек';
    const row = `${String(l.n).padStart(w)} │ ${tag.padEnd(9)} │ ${l.text}`;
    return l.by ? paint(row) : dim(row);
  });
  const agent = lines.filter((l) => l.by).length;
  out.push('', `${b.path}: строк агента ${agent} из ${lines.length}${lines.length ? ` (${Math.round((100 * agent) / lines.length)}%)` : ''}`);
  ids.forEach((id, i) => {
    const e = lines.find((l) => l.by?.id === id).by;
    out.push(`  [${i + 1}] ${who(e)}${e.sub ? ` · субагент «${e.sub}»` : ''}${e.trigger ? ` · ${e.trigger}` : ''}`, `      «${e.prompt || '—'}»`);
  });
  return out;
}

/** `klinch blame …` and /blame: lines to print. */
export function blameCommand(args, { cwd = process.cwd(), env = process.env, paint, dim } = {}) {
  const json = args.includes('--json');
  const li = args.indexOf('-L');
  const flag = li >= 0 ? args[li + 1] : null;
  const rest = args.filter((a, i) => !a.startsWith('--') && i !== li && (li < 0 || i !== li + 1));
  if (args.includes('--stats') || !rest.length) {
    const s = blameStats(blameRoot(join(cwd, '_')), env);
    if (json) return [JSON.stringify(s)];
    if (!s.length) return ['Строк агента в этом проекте пока нет (или их уже переписали люди). Файл: klinch blame <путь>'];
    return [...s.map((x) => `${String(Math.round((100 * x.agent) / x.total)).padStart(3)}%  ${String(x.agent).padStart(5)} из ${String(x.total).padEnd(5)}  ${x.path}${x.sessions > 1 ? `  (${x.sessions} сессий)` : ''}`), '', 'Подробно по файлу: klinch blame <путь>'];
  }
  const r = parseRange(rest[0], flag);
  const abs = isAbsolute(r.path) ? r.path : resolve(cwd, r.path);
  const b = blameFile(abs, env);
  if (!b) throw new Error(`Не могу прочитать ${r.path}`);
  if (json) return [JSON.stringify({ path: b.path, lines: b.lines.filter((l) => (!r.from || l.n >= r.from) && (!r.to || l.n <= r.to)).map((l) => ({ n: l.n, by: l.by })) })];
  return formatBlame(b, { from: r.from, to: r.to, paint, dim });
}

/** The agent's read-only tool: who wrote these lines (the agent in which request, or a person). */
export function blameTool(env = process.env) {
  return {
    name: 'ai_blame',
    description: 'AI blame: какие строки файла написал агент (в какой сессии, по какому запросу, какой моделью), а какие человек. path, можно с #L10-20. Без path — доля строк агента по файлам проекта.',
    input_schema: { type: 'object', properties: { path: { type: 'string' } } },
    preview: ({ path }) => `ai_blame ${path || '(весь проект)'}`,
    run({ path }, ctx) {
      const lines = blameCommand(path ? [String(path)] : ['--stats'], { cwd: ctx?.cwd || process.cwd(), env });
      const text = lines.join('\n');
      return text.length > 40000 ? text.slice(0, 40000) + '\n… (сократил: укажите #L-диапазон)' : text;
    },
  };
}
