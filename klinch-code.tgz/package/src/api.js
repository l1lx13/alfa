// Minimal client for the Klinch gateway (Anthropic Messages format).

export class ApiError extends Error {
  constructor(status, body) {
    super(describe(status, body));
    this.status = status;
    this.body = body;
    // The conversation no longer fits the model's context window: the agent compacts it and asks again.
    this.tooLong = status === 400 && /prompt is too long|context.{0,20}(length|window)|too many tokens|maximum context/i.test(JSON.stringify(body || ''));
  }
}

function describe(status, body) {
  const e = body?.error;
  if (status === 401) return 'Ключ не принят. Проверьте его: klinch login';
  if (status === 402) return `Баланса не хватает${body?.balance != null ? ` (осталось ${fmt(body.balance)} токенов)` : ''}. Пополнить: https://klinch.cloud/console`;
  if (e === 'model_not_allowed') return `Модель недоступна. Есть: ${(body.allowed || []).join(', ')}`;
  if (typeof e === 'string') return `Ошибка ${status}: ${e}`;
  if (e?.message) return `Ошибка ${status}: ${e.message}`;
  return `Ошибка ${status}`;
}

export const fmt = (n) => Math.round(+n || 0).toLocaleString('ru-RU');

// Busy or briefly failing gateway: the request is sent again after a pause (the answer has not started yet, so
// nothing is lost or charged twice). x-should-retry: false (a usage limit) is final.
const RETRY_STATUS = new Set([408, 409, 429, 500, 502, 503, 504, 529]);
const RETRY_WAIT = [1500, 4000, 10000];
const sleep = (ms, signal) => new Promise((r) => { const t = setTimeout(r, ms); signal?.addEventListener('abort', () => { clearTimeout(t); r(); }, { once: true }); });

export function createClient({ baseUrl, apiKey, fetchImpl = fetch }) {
  const headers = { authorization: 'Bearer ' + apiKey, 'content-type': 'application/json', 'anthropic-version': '2023-06-01', 'x-klinch-client': 'klinch-code' };
  const req = async (path, opts = {}) => {
    const r = await fetchImpl(baseUrl + path, { ...opts, headers: { ...headers, ...opts.headers } });
    if (!r.ok) {
      let body; try { body = await r.json(); } catch { body = undefined; }
      const e = new ApiError(r.status, body);
      e.retry = RETRY_STATUS.has(r.status) && r.headers?.get?.('x-should-retry') !== 'false';
      e.after = Math.min(+r.headers?.get?.('retry-after') * 1000 || 0, 30000);
      throw e;
    }
    return r;
  };
  /** req() with up to three more tries for a busy gateway or a dropped connection. */
  const send = async (path, opts, onRetry, wait = RETRY_WAIT) => {
    for (let i = 0; ; i++) {
      try { return await req(path, opts); } catch (e) {
        const net = !(e instanceof ApiError) && e?.name !== 'AbortError';
        if (opts.signal?.aborted || i >= wait.length || !(net || e.retry)) throw e;
        const ms = Math.max(e.after || 0, wait[i]);
        onRetry?.(i + 1, ms, e);
        await sleep(ms, opts.signal);
        if (opts.signal?.aborted) throw e;
      }
    }
  };
  const json = async (path, opts) => (await req(path, opts)).json();

  return {
    account: () => json('/v1/account'),
    /** POST JSON to another gateway route (pictures, speech, voice): the parsed answer, or the raw Response with raw. */
    postJson: async (path, body, { signal, raw = false } = {}) => { const r = await req(path, { method: 'POST', body: JSON.stringify(body), signal }); return raw ? r : r.json(); },
    models: async () => (await json('/v1/models')).data.filter((m) => m.kind !== 'image'),   // chat models only
    usage: (days = 30) => json('/v1/usage?days=' + days),
    /** Vectors for texts (the semantic code index, src/codeindex.js). */
    async embeddings(input, { model, dimensions, signal } = {}) {
      const d = await (await send('/v1/embeddings', { method: 'POST', body: JSON.stringify({ model, input, ...(dimensions ? { dimensions } : {}) }), signal }, null, [2000])).json();
      const rows = (d?.data || []).slice().sort((a, b) => a.index - b.index).map((x) => x.embedding);
      if (rows.length !== input.length) throw new Error('embeddings: wrong count');
      return rows;
    },

    // Streams one assistant message. Calls onText(delta) as text arrives, onThinking() while the model reasons
    // (the reasoning itself is never shown) and returns the final message ({content, stop_reason, usage}).
    async stream(body, { onText = () => {}, onToolStart = () => {}, onThinking = () => {}, onRetry, retryWait, signal, headers } = {}) {
      const r = await send('/v1/messages', { method: 'POST', body: JSON.stringify({ ...body, stream: true }), signal, ...(headers ? { headers } : {}) }, onRetry, retryWait);
      const msg = { content: [], stop_reason: null, usage: {} };
      const partial = new Map(); // index -> accumulated input JSON of a tool_use block
      const onEvent = (e) => {
        switch (e.type) {
          case 'message_start': Object.assign(msg.usage, e.message?.usage); break;
          case 'content_block_start': {
            const b = { ...e.content_block };
            if (b.type === 'tool_use') { partial.set(e.index, ''); onToolStart(b); }
            if (b.type === 'thinking' || b.type === 'redacted_thinking') onThinking();
            msg.content[e.index] = b;
            break;
          }
          case 'content_block_delta': {
            const b = msg.content[e.index], d = e.delta || {};
            if (!b) break;
            if (d.type === 'text_delta') { b.text = (b.text || '') + d.text; onText(d.text); }
            else if (d.type === 'input_json_delta') partial.set(e.index, partial.get(e.index) + d.partial_json);
            else if (d.type === 'thinking_delta') { b.thinking = (b.thinking || '') + d.thinking; onThinking(); }
            else if (d.type === 'signature_delta') b.signature = (b.signature || '') + d.signature;
            break;
          }
          case 'content_block_stop': {
            const b = msg.content[e.index];
            if (b?.type === 'tool_use') {
              const raw = partial.get(e.index);
              try { b.input = raw ? JSON.parse(raw) : (b.input || {}); } catch { b.input = {}; b.badInput = raw; }
            }
            break;
          }
          case 'message_delta':
            if (e.delta?.stop_reason) msg.stop_reason = e.delta.stop_reason;
            for (const [k, v] of Object.entries(e.usage || {})) if (v != null) msg.usage[k] = v;
            break;
          case 'error': throw new ApiError(500, { error: e.error });
        }
      };
      const dec = new TextDecoder();
      let buf = '';
      for await (const chunk of r.body) {
        buf += dec.decode(chunk, { stream: true });
        let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
          if (!line.startsWith('data:')) continue;
          let e; try { e = JSON.parse(line.slice(5)); } catch { continue; }
          onEvent(e);
        }
      }
      msg.content = msg.content.filter(Boolean);
      if (!msg.stop_reason) msg.stop_reason = 'interrupted';
      return msg;
    },
  };
}
