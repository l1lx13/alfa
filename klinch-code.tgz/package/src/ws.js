// A minimal WebSocket client (text frames only), enough for the DevTools protocol of a browser the user already
// runs. Node 18 has no WebSocket, so this is plain `net` + the HTTP upgrade handshake; no dependencies.
import { connect as tcp } from 'node:net';
import { randomBytes, createHash } from 'node:crypto';

/**
 * Opens ws://host:port/path. Resolves with { send(text), close(), onMessage(fn), onClose(fn) }.
 * Rejects when the server refuses the upgrade or does not answer within `timeout`.
 */
export function openWebSocket(url, { timeout = 15000 } = {}) {
  const u = new URL(url);
  if (u.protocol !== 'ws:') return Promise.reject(new Error(`Только ws:// адреса (${u.protocol})`));
  return new Promise((resolve, reject) => {
    const key = randomBytes(16).toString('base64');
    const sock = tcp({ host: u.hostname.replace(/^\[|\]$/g, ''), port: +u.port || 80 });
    const msgFns = new Set(), closeFns = new Set();
    let buf = Buffer.alloc(0), open = false, closed = false, parts = [];
    const timer = setTimeout(() => { sock.destroy(); reject(new Error('Браузер не ответил (WebSocket)')); }, timeout);
    const finish = (why) => {
      if (closed) return; closed = true; clearTimeout(timer);
      if (!open) reject(new Error(why || 'Соединение закрыто'));
      for (const fn of closeFns) { try { fn(why); } catch { /* ignore */ } }
    };
    const frame = (op, payload) => {
      const len = payload.length, mask = randomBytes(4);
      const head = len < 126 ? Buffer.from([0x80 | op, 0x80 | len])
        : len < 65536 ? Buffer.from([0x80 | op, 0x80 | 126, len >> 8, len & 255])
          : (() => { const h = Buffer.alloc(10); h[0] = 0x80 | op; h[1] = 0x80 | 127; h.writeBigUInt64BE(BigInt(len), 2); return h; })();
      const body = Buffer.allocUnsafe(len);
      for (let i = 0; i < len; i++) body[i] = payload[i] ^ mask[i & 3];
      try { sock.write(Buffer.concat([head, mask, body])); } catch { /* closed */ }
    };
    const api = {
      send(text) { if (!closed) frame(1, Buffer.from(String(text))); },
      close() { if (closed) return; frame(8, Buffer.alloc(0)); setTimeout(() => sock.destroy(), 300).unref?.(); finish('закрыто'); },
      onMessage(fn) { msgFns.add(fn); return () => msgFns.delete(fn); },
      onClose(fn) { closeFns.add(fn); return () => closeFns.delete(fn); },
      get closed() { return closed; },
    };
    const readFrames = () => {
      for (;;) {
        if (buf.length < 2) return;
        const fin = buf[0] & 0x80, op = buf[0] & 0x0f, masked = buf[1] & 0x80;
        let len = buf[1] & 0x7f, off = 2;
        if (len === 126) { if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; }
        else if (len === 127) { if (buf.length < 10) return; len = Number(buf.readBigUInt64BE(2)); off = 10; }
        const maskKey = masked ? buf.subarray(off, off + 4) : null;
        if (masked) off += 4;
        if (buf.length < off + len) return;
        let data = buf.subarray(off, off + len);
        if (maskKey) { data = Buffer.from(data); for (let i = 0; i < data.length; i++) data[i] ^= maskKey[i & 3]; }
        buf = buf.subarray(off + len);
        if (op === 8) { sock.destroy(); finish('браузер закрыл соединение'); return; }
        if (op === 9) { frame(10, data); continue; }
        if (op === 10) continue;
        if (op === 1 || op === 2 || op === 0) {
          parts.push(Buffer.from(data));
          if (fin) { const text = Buffer.concat(parts).toString('utf8'); parts = []; for (const fn of msgFns) { try { fn(text); } catch { /* listener bug */ } } }
        }
      }
    };
    sock.once('connect', () => {
      sock.write(`GET ${u.pathname}${u.search} HTTP/1.1\r\nHost: ${u.host}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n`
        + `Sec-WebSocket-Key: ${key}\r\nSec-WebSocket-Version: 13\r\n\r\n`);
    });
    sock.on('data', (d) => {
      buf = Buffer.concat([buf, d]);
      if (!open) {
        const end = buf.indexOf('\r\n\r\n');
        if (end < 0) return;
        const head = buf.subarray(0, end).toString('latin1');
        buf = buf.subarray(end + 4);
        const want = createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
        if (!/^HTTP\/1\.1 101/.test(head) || !head.toLowerCase().includes(want.toLowerCase())) {
          sock.destroy(); finish(`браузер отказал: ${head.split('\r\n')[0]}`); return;
        }
        open = true; clearTimeout(timer); resolve(api);
      }
      readFrames();
    });
    sock.on('error', (e) => finish(e.code === 'ECONNREFUSED' ? 'порт закрыт' : e.message));
    sock.on('close', () => finish('соединение закрыто'));
  });
}
