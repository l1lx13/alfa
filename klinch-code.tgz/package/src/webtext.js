// Text out of web pages, with no imports: the terminal agent (web.js) and the site's web connector
// (server/extensions.js) both read pages and DuckDuckGo's results with these.
export const decodeEntities = (t) => t.replace(/&(#x?[0-9a-f]+|amp|lt|gt|quot|apos|nbsp|#39);/gi, (m, e) => {
  const k = e.toLowerCase();
  if (k[0] === '#') { const n = k[1] === 'x' ? parseInt(k.slice(2), 16) : parseInt(k.slice(1), 10); return Number.isFinite(n) && n > 0 && n < 0x110000 ? String.fromCodePoint(n) : m; }
  return { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', '#39': "'" }[k] ?? m;
});

/**
 * HTML → readable text: scripts, styles and tags out, block ends become line breaks. With `rich` (the default) links
 * stay as [text](url), headings get their #, and </pre> ends a line; the site's own connector passes rich: false.
 */
export function htmlToText(html, { rich = true } = {}) {
  const title = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1];
  let body = String(html)
    .replace(/<(script|style|noscript|svg|template|head|title)[\s\S]*?<\/\1>/gi, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ');
  if (rich) body = body
    .replace(/<a\s[^>]*href="(https?:[^"]+)"[^>]*>([\s\S]*?)<\/a>/gi, (_, u, t) => { const s = t.replace(/<[^>]+>/g, '').trim(); return s ? `[${s}](${u})` : ' '; })
    .replace(/<(h[1-6])[^>]*>/gi, (_, h) => '\n' + '#'.repeat(+h[1]) + ' ')
    .replace(/<\/pre[^>]*>/gi, '\n');
  body = body
    .replace(/<(br|\/p|\/div|\/li|\/h[1-6]|\/tr|\/section|\/article|\/header|\/footer)[^>]*>/gi, '\n')
    .replace(/<li[^>]*>/gi, '\n- ')
    .replace(/<[^>]+>/g, ' ');
  const text = decodeEntities(body).replace(/[ \t\f\r]+/g, ' ').replace(/ *\n */g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  return (title ? `# ${decodeEntities(title).trim()}\n\n` : '') + text;
}

/** DuckDuckGo's HTML results page → [{ title, url, snippet }]. */
export function parseDuckDuckGo(html, max = 6) {
  const out = [];
  const re = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?(?:class="result__snippet"[^>]*>([\s\S]*?)<\/a>|(?=<a[^>]+class="result__a"))/g;
  let m;
  while ((m = re.exec(html)) && out.length < max) {
    let href = decodeEntities(m[1]);
    const uddg = /[?&]uddg=([^&]+)/.exec(href)?.[1];
    if (uddg) { try { href = decodeURIComponent(uddg); } catch { /* keep */ } }
    if (href.startsWith('//')) href = 'https:' + href;
    if (!/^https?:\/\//.test(href) || /duckduckgo\.com\/y\.js/.test(href)) continue;
    const strip = (t) => decodeEntities(String(t || '').replace(/<[^>]+>/g, '')).replace(/\s+/g, ' ').trim();
    out.push({ title: strip(m[2]), url: href, snippet: strip(m[3]) });
  }
  return out;
}
