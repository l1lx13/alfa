// Voice in the terminal: /voice records one message from the microphone (sox, ffmpeg or arecord), the gateway turns
// it into text (free), and /say reads answers aloud (text to speech on the balance). /talk does both in a loop.
import { spawn, spawnSync } from 'node:child_process';
import { readFileSync, rmSync, writeFileSync, mkdtempSync, existsSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const has = (cmd) => spawnSync(process.platform === 'win32' ? 'where' : 'which', [cmd], { stdio: 'ignore' }).status === 0;

/** The recorder command for a wav file on this computer, or null. */
export function recorder(out, platform = process.platform, exists = has, seconds = 0) {
  const sec = seconds > 0 ? String(seconds) : null;
  if (exists('rec')) return ['rec', ['-q', '-c', '1', '-r', '16000', '-b', '16', out, ...(sec ? ['trim', '0', sec] : [])]];
  if (exists('sox') && platform !== 'win32') return ['sox', ['-q', '-d', '-c', '1', '-r', '16000', '-b', '16', out, ...(sec ? ['trim', '0', sec] : [])]];
  if (exists('ffmpeg')) {
    const input = platform === 'darwin' ? ['-f', 'avfoundation', '-i', ':0'] : platform === 'win32' ? ['-f', 'dshow', '-i', 'audio=default'] : ['-f', 'pulse', '-i', 'default'];
    return ['ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', ...input, ...(sec ? ['-t', sec] : []), '-ac', '1', '-ar', '16000', '-sample_fmt', 's16', out]];
  }
  if (exists('arecord')) return ['arecord', ['-q', '-f', 'S16_LE', '-r', '16000', '-c', '1', ...(sec ? ['-d', sec] : []), out]];
  return null;
}

/** The player command for an mp3 file, or null. */
export function player(file, platform = process.platform, exists = has) {
  if (platform === 'darwin') return ['afplay', [file]];
  if (exists('ffplay')) return ['ffplay', ['-nodisp', '-autoexit', '-loglevel', 'quiet', file]];
  if (exists('mpg123')) return ['mpg123', ['-q', file]];
  if (exists('mpv')) return ['mpv', ['--no-video', '--really-quiet', file]];
  if (platform === 'win32') return ['powershell', ['-NoProfile', '-Command', `Add-Type -AssemblyName presentationCore; $p=New-Object System.Windows.Media.MediaPlayer; $p.Open('${file}'); $p.Play(); Start-Sleep -s 1; while($p.Position -lt $p.NaturalDuration.TimeSpan){Start-Sleep -m 200}`]];
  return null;
}

const NO_MIC = 'Нужна программа для записи с микрофона: sox (brew install sox / apt install sox), ffmpeg или arecord.';

/**
 * Records until `stop` resolves (the user pressed Enter) or `max` ms pass. Returns the wav bytes (or null when
 * nothing was recorded).
 */
export async function record(stop, { max = 120000 } = {}) {
  const dir = mkdtempSync(join(tmpdir(), 'agent-voice-')), out = join(dir, 'in.wav');
  const cmd = recorder(out);
  if (!cmd) throw new Error(NO_MIC);
  const p = spawn(cmd[0], cmd[1], { stdio: ['pipe', 'ignore', 'pipe'] });
  let err = '';
  p.stderr.on('data', (d) => { err = (err + d).slice(-2000); });
  const ended = new Promise((r) => p.on('close', r));
  const t = setTimeout(() => p.kill('SIGINT'), max);
  await Promise.race([stop, ended]);
  clearTimeout(t);
  if (p.exitCode === null) { if (cmd[0] === 'ffmpeg') p.stdin.end('q'); else p.kill('SIGINT'); }
  await Promise.race([ended, new Promise((r) => setTimeout(r, 3000))]);
  try {
    if (!existsSync(out) || statSync(out).size < 2000) { if (err) throw new Error(`Запись не удалась: ${err.trim().split('\n').pop()}`); return null; }
    return readFileSync(out);
  } finally { rmSync(dir, { recursive: true, force: true }); }
}

/** Speech → text through the gateway (POST /v1/transcribe, free). */
export async function transcribe(client, wav, lang) {
  const r = await client.postJson('/v1/transcribe', { audio: wav.toString('base64'), media_type: 'audio/wav', ...(lang ? { lang } : {}) });
  return String(r?.text || '').trim();
}

/** What is worth reading aloud: no code, no Markdown marks, at most ~1500 characters. */
export function speakable(text) {
  return String(text || '')
    .replace(/```[\s\S]*?```/g, ' (код в терминале) ')
    .replace(/`([^`]+)`/g, '$1').replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/^#+\s*/gm, '').replace(/[*_~>|]/g, '').replace(/^\s*[-•]\s+/gm, '')
    .replace(/\s+/g, ' ').trim().slice(0, 1500);
}

/** Reads `text` aloud: speech from the gateway, played on this computer. */
export async function speak(client, text, { voice = 'alloy', signal } = {}) {
  const input = speakable(text);
  if (!input) return false;
  const r = await client.postJson('/v1/audio/speech', { model: 'auto', input, voice, response_format: 'mp3' }, { raw: true, signal });
  const buf = Buffer.from(await r.arrayBuffer());
  // The gateway may answer in another format than asked (wav, ogg): the file is named by what came.
  const type = String(r.headers?.get?.('content-type') || ''), ext = /wav/.test(type) ? 'wav' : /ogg|opus/.test(type) ? 'ogg' : /aac|mp4/.test(type) ? 'm4a' : 'mp3';
  const dir = mkdtempSync(join(tmpdir(), 'agent-say-')), file = join(dir, `out.${ext}`);
  writeFileSync(file, buf);
  const cmd = player(file);
  if (!cmd) { rmSync(dir, { recursive: true, force: true }); throw new Error('Нечем проиграть звук: поставьте ffmpeg (ffplay), mpg123 или mpv.'); }
  await new Promise((resolve) => {
    const p = spawn(cmd[0], cmd[1], { stdio: 'ignore' });
    signal?.addEventListener('abort', () => p.kill(), { once: true });
    p.on('error', resolve); p.on('close', resolve);
  });
  rmSync(dir, { recursive: true, force: true });
  return true;
}

// ---------------------------------------------------------------- listening for a wake word (/listen)
// The microphone is recorded in short pieces; only pieces with a voice in them (by loudness, on this computer) go to
// the gateway for text, so silence costs nothing and does not use up the daily voice limit. When the text has the
// wake word, what follows it is the request; if nothing follows, the next phrase (until a pause) is.

/** The 16-bit PCM samples of a wav file (header skipped). */
export function pcmOf(wav) {
  let p = 12;
  while (p + 8 <= wav.length) {
    const id = wav.toString('ascii', p, p + 4), size = wav.readUInt32LE(p + 4);
    if (id === 'data') return wav.subarray(p + 8, Math.min(wav.length, p + 8 + size));
    p += 8 + size + (size & 1);
  }
  return wav.subarray(44);
}

/** Loudness of a wav piece: root mean square of the samples, 0…32767. */
export function level(wav) {
  const pcm = pcmOf(wav);
  const n = Math.floor(pcm.length / 2);
  if (!n) return 0;
  let sum = 0;
  for (let i = 0; i < n; i++) { const v = pcm.readInt16LE(i * 2); sum += v * v; }
  return Math.sqrt(sum / n);
}

/** One wav from several pieces of the same format. */
export function joinWav(pieces) {
  if (pieces.length === 1) return pieces[0];
  const pcm = Buffer.concat(pieces.map(pcmOf));
  const h = Buffer.alloc(44);
  h.write('RIFF', 0); h.writeUInt32LE(36 + pcm.length, 4); h.write('WAVE', 8); h.write('fmt ', 12); h.writeUInt32LE(16, 16);
  h.writeUInt16LE(1, 20); h.writeUInt16LE(1, 22); h.writeUInt32LE(16000, 24); h.writeUInt32LE(32000, 28); h.writeUInt16LE(2, 32); h.writeUInt16LE(16, 34);
  h.write('data', 36); h.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([h, pcm]);
}

/** Records one piece of `seconds` (wav bytes, or null). */
export async function recordPiece(seconds, { signal } = {}) {
  const dir = mkdtempSync(join(tmpdir(), 'agent-voice-')), out = join(dir, 'p.wav');
  const cmd = recorder(out, process.platform, has, seconds);
  if (!cmd) throw new Error(NO_MIC);
  try {
    await new Promise((resolve, reject) => {
      const p = spawn(cmd[0], cmd[1], { stdio: ['ignore', 'ignore', 'ignore'] });
      const t = setTimeout(() => p.kill('SIGINT'), seconds * 1000 + 3000);
      const stop = () => p.kill('SIGINT');
      signal?.addEventListener('abort', stop, { once: true });
      p.on('error', (e) => { clearTimeout(t); reject(e); });
      p.on('close', () => { clearTimeout(t); signal?.removeEventListener('abort', stop); resolve(); });
    });
    return existsSync(out) && statSync(out).size > 100 ? readFileSync(out) : null;
  } finally { rmSync(dir, { recursive: true, force: true }); }
}

const norm = (s) => String(s || '').toLowerCase().replace(/ё/g, 'е').replace(/[^a-zа-я0-9\s]/gi, ' ').replace(/\s+/g, ' ').trim();

/** The request after the wake word in `text`, '' when only the word was said, null when it was not said. */
export function afterWake(text, word) {
  const t = norm(text), w = norm(word);
  if (!w) return null;
  const i = t.indexOf(w);
  if (i < 0) return null;
  return String(text).trim().split(/\s+/).slice(w.split(' ').length + t.slice(0, i).split(' ').filter(Boolean).length).join(' ').replace(/^[,.!?\s]+/, '').trim();
}

/**
 * Waits for the wake word, then returns the request (text). `hear(wav)` turns speech into text; `onState` reports
 * 'heard' (the word) for the caller to show. Throws when the signal aborts.
 */
export async function waitForWake({ word, hear, signal, piece = 3, threshold = 600, onState = () => {}, rec = recordPiece, max = 60 }) {
  let empty = 0;
  for (;;) {
    if (signal?.aborted) throw Object.assign(new Error('Прервано'), { interrupted: true });
    const wav = await rec(piece, { signal });
    if (signal?.aborted) throw Object.assign(new Error('Прервано'), { interrupted: true });
    // No sound at all (no microphone access, the recorder quit): not a busy loop; give up after a few tries.
    if (!wav) { if (++empty >= 5) throw new Error('Микрофон не отдаёт звук: проверьте доступ к микрофону для терминала'); await new Promise((r) => setTimeout(r, 300)); continue; }
    empty = 0;
    if (level(wav) < threshold) continue;
    const text = await hear(wav).catch(() => '');
    const rest = afterWake(text, word);
    if (rest === null) continue;
    onState('heard');
    if (rest) return rest;
    // The word alone: the next phrase, until a quiet piece (up to `max` seconds).
    const parts = [];
    for (let s = 0; s < max; s += piece) {
      const w = await rec(piece, { signal });
      if (signal?.aborted) throw Object.assign(new Error('Прервано'), { interrupted: true });
      if (!w) break;
      if (level(w) < threshold) { if (parts.length) break; if (s >= piece * 2) break; continue; }
      parts.push(w);
    }
    if (!parts.length) { onState('silence'); continue; }
    const req = (await hear(joinWav(parts)).catch(() => '')).trim();
    if (req) return req;
    onState('silence');
  }
}
