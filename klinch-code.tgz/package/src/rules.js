// Path-scoped rules, like Cursor's .cursor/rules: Markdown files with a front matter that says when they apply.
//
//   ---
//   description: Как писать API-ручки        (when the agent should read the rule itself)
//   globs: server/**/*.js, *.sql             (attached when the agent reads or changes a matching file)
//   alwaysApply: false                       (true: always in the system prompt)
//   ---
//   Текст правила…
//
// Looked up in <project>/.klinch/rules, <project>/.cursor/rules (.md and .mdc, subfolders too) and ~/.klinch/rules.
// A rule with neither globs nor description applies always. A glob without a «/» matches the file name in any
// folder (`*.ts`), one with a «/» the path from the project root (`src/**/*.ts`).
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { homedir } from 'node:os';
import { join, relative, sep, basename } from 'node:path';
import { frontMatter } from './skills.js';

const MAX_RULES = 200, MAX_TEXT = 20000;
const read = (p) => { try { return readFileSync(p, 'utf8'); } catch { return null; } };

/** Rule files under a folder (subfolders too, a few levels), sorted. */
function files(root, depth = 0, out = []) {
  let names; try { names = readdirSync(root).sort(); } catch { return out; }
  for (const n of names) {
    const p = join(root, n);
    let st; try { st = statSync(p); } catch { continue; }
    if (st.isDirectory()) { if (depth < 4 && !n.startsWith('.')) files(p, depth + 1, out); }
    else if (/\.mdc?$/i.test(n)) out.push(p);
    if (out.length >= MAX_RULES) break;
  }
  return out;
}

/** «a, b», «["a", "b"]» or «a b» → ['a', 'b']. */
export const splitGlobs = (v) => String(v || '').replace(/^\[|\]$/g, '').split(/[,\s]+/).map((x) => x.trim().replace(/^['"]|['"]$/g, '')).filter(Boolean);

/** A glob as a RegExp: `**` any folders, `*` and `?` within a name, `{a,b}` alternatives. */
export function globRe(glob) {
  let g = glob.replace(/\\/g, '/').replace(/^\.\//, '');
  if (g.endsWith('/')) g += '**';
  let re = '';
  for (let i = 0; i < g.length; i++) {
    const ch = g[i];
    if (ch === '*' && g[i + 1] === '*') {
      i++;
      if (g[i + 1] === '/') { i++; re += '(?:.*/)?'; } else re += '.*';
    } else if (ch === '*') re += '[^/]*';
    else if (ch === '?') re += '[^/]';
    else if (ch === '{') { const end = g.indexOf('}', i); if (end < 0) { re += '\\{'; continue; } re += '(?:' + g.slice(i + 1, end).split(',').map((x) => x.replace(/[.+^$()|[\]\\]/g, '\\$&').replace(/\*/g, '[^/]*')).join('|') + ')'; i = end; }
    else re += ch.replace(/[.+^$()|[\]\\]/g, '\\$&');
  }
  return new RegExp('^' + re + '$');
}

/** Does the path (relative to the project, with «/») match the glob? */
export function matchGlob(glob, rel) {
  const p = rel.replace(/\\/g, '/');
  const re = globRe(glob);
  return glob.includes('/') ? re.test(p) : re.test(basename(p)) || re.test(p);
}

/**
 * Every rule: [{ name, file, description, globs, always }]. A project rule wins over a personal one of the same name.
 */
export function loadRules(cwd, env = process.env) {
  const home = env.KLINCH_HOME || join(homedir(), '.klinch');
  const out = new Map();
  for (const root of [join(home, 'rules'), join(cwd, '.cursor', 'rules'), join(cwd, '.klinch', 'rules')]) {
    for (const f of files(root)) {
      const { meta, body } = frontMatter(read(f) || '');
      if (!body.trim()) continue;
      const globs = splitGlobs(meta.globs);
      const description = String(meta.description || '').slice(0, 300);
      const always = /^true$/i.test(meta.alwaysApply || '') || (!globs.length && !description);
      const name = relative(root, f).split(sep).join('/').replace(/\.mdc?$/i, '');
      out.set(name, { name, file: f, description, globs, always, body: body.trim().slice(0, MAX_TEXT) });
    }
  }
  return [...out.values()];
}

/** The rules part of the system prompt: the always ones in full, the rest listed. */
export function rulesPrompt(rules, cwd) {
  if (!rules.length) return '';
  const parts = [];
  const always = rules.filter((r) => r.always);
  if (always.length) parts.push(`# Правила проекта\n${always.map((r) => `## ${r.name}\n${r.body}`).join('\n\n')}`);
  const asked = rules.filter((r) => !r.always && !r.globs.length);
  const scoped = rules.filter((r) => !r.always && r.globs.length);
  if (asked.length || scoped.length) {
    parts.push('# Правила по темам и путям'
      + (scoped.length ? `\nПравило для файлов придёт само, когда ты откроешь или изменишь подходящий файл:\n${scoped.map((r) => `- ${r.name}: ${r.globs.join(', ')}${r.description ? ` (${r.description})` : ''}`).join('\n')}` : '')
      + (asked.length ? `\nЕсли задача подходит под тему, прочитай правило через read_file:\n${asked.map((r) => `- ${relOrAbs(cwd, r.file)}: ${r.description}`).join('\n')}` : ''));
  }
  return parts.join('\n\n');
}
const relOrAbs = (cwd, f) => { const r = relative(cwd, f); return r.startsWith('..') ? f : r.split(sep).join('/'); };

/**
 * Tracks which glob rules this conversation has already seen. `attach(rel)` returns the text of the rules for that
 * path that were not shown yet (empty string when none), so each rule comes once per conversation.
 */
export function ruleTracker(rules) {
  const scoped = rules.filter((r) => !r.always && r.globs.length);
  const shown = new Set();
  return {
    count: scoped.length,
    attach(rel) {
      if (!rel || rel.startsWith('..')) return '';
      const hit = scoped.filter((r) => !shown.has(r.name) && r.globs.some((g) => matchGlob(g, rel)));
      for (const r of hit) shown.add(r.name);
      return hit.map((r) => `# Правило проекта «${r.name}» (для ${r.globs.join(', ')})\n${r.body}`).join('\n\n');
    },
    reset() { shown.clear(); },
  };
}
