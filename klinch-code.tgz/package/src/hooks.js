// Hooks: your own commands that run at agent events, in the Claude Code format, so existing hook scripts work.
//
// Settings: ~/.klinch/settings.json, <project>/.klinch/settings.json, <project>/.claude/settings.json:
//   { "hooks": { "PreToolUse": [ { "matcher": "shell|edit_file", "hooks": [ { "type": "command", "command": "…" } ] } ] } }
// Events: SessionStart, UserPromptSubmit, PreToolUse, PostToolUse, Stop. `matcher` (a regex over tool names) only
// matters for the tool events; empty or "*" matches all. The command gets the event as JSON on stdin and runs in
// the project folder with KLINCH_PROJECT_DIR / CLAUDE_PROJECT_DIR set.
//   exit 0  → fine; for SessionStart and UserPromptSubmit, stdout is added to what the agent sees
//   exit 2  → block: PreToolUse refuses the call, UserPromptSubmit drops the prompt, PostToolUse and Stop send stderr
//             back to the agent (Stop makes it keep working)
//   other   → a warning is printed, nothing is blocked
// JSON on stdout also works: {"decision":"block","reason":"…"}, or for PreToolUse
// {"hookSpecificOutput":{"permissionDecision":"allow"|"deny"|"ask","permissionDecisionReason":"…"}}.
// Project hooks run commands from the repository, so they run only after the user allowed them once.
import { spawn } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync, chmodSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { pluginHooks } from './plugins.js';

export const EVENTS = ['SessionStart', 'UserPromptSubmit', 'PreToolUse', 'PostToolUse', 'Stop'];
const dir = (env) => env.KLINCH_HOME || join(homedir(), '.klinch');
const readJson = (p) => { try { return JSON.parse(readFileSync(p, 'utf8')); } catch { return null; } };

/** [{ file, source, hooks: { Event: [{ matcher, hooks: [{ command, timeout }] }] } }] */
export function loadHookConfigs(cwd, env = process.env) {
  const out = [];
  for (const [file, source] of [[join(dir(env), 'settings.json'), 'user'], [join(cwd, '.claude', 'settings.json'), 'project'], [join(cwd, '.klinch', 'settings.json'), 'project']]) {
    const h = readJson(file)?.hooks;
    if (h && typeof h === 'object' && EVENTS.some((e) => Array.isArray(h[e]) && h[e].length)) out.push({ file, source, hooks: h });
  }
  // Installed plugins' hooks (src/plugins.js): installing one was the consent.
  for (const p of pluginHooks(env)) if (EVENTS.some((e) => Array.isArray(p.hooks[e]) && p.hooks[e].length)) out.push(p);
  return out;
}

const trustFile = (env) => join(dir(env), 'hooks-trust.json');
const key = (cwd, c) => cwd + '\0' + c.file + '\0' + createHash('sha256').update(JSON.stringify(c.hooks)).digest('hex');
export const isTrusted = (cwd, c, env = process.env) => c.source === 'user' || !!readJson(trustFile(env))?.[key(cwd, c)];
export function trust(cwd, c, env = process.env) {
  const t = readJson(trustFile(env)) || {};
  t[key(cwd, c)] = Date.now();
  mkdirSync(dir(env), { recursive: true, mode: 0o700 });
  writeFileSync(trustFile(env), JSON.stringify(t, null, 2) + '\n', { mode: 0o600 });
  try { chmodSync(trustFile(env), 0o600); } catch { /* Windows */ }
}

/** Every command of every config as a flat list of commands of one event. */
export const commandsOf = (configs, event) => configs.flatMap((c) => (c.hooks[event] || []).flatMap((m) =>
  (m?.hooks || []).filter((h) => h?.type === 'command' && h.command).map((h) => ({ matcher: m.matcher || '', command: h.command, timeout: h.timeout }))));

const matches = (matcher, tool) => {
  if (!matcher || matcher === '*' || tool == null) return true;
  try { return new RegExp(`^(?:${matcher})$`).test(tool); } catch { return matcher === tool; }
};

function runCommand(command, input, { cwd, env, timeoutSec = 60 }) {
  return new Promise((done) => {
    const sh = process.platform === 'win32' ? ['cmd.exe', ['/d', '/s', '/c', command]] : ['/bin/sh', ['-c', command]];
    const child = spawn(sh[0], sh[1], { cwd, env: { ...env, KLINCH_PROJECT_DIR: cwd, CLAUDE_PROJECT_DIR: cwd }, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
    let stdout = '', stderr = '';
    child.stdout.on('data', (d) => { if (stdout.length < 100_000) stdout += d; });
    child.stderr.on('data', (d) => { if (stderr.length < 100_000) stderr += d; });
    const t = setTimeout(() => { child.kill('SIGKILL'); stderr += `\n(хук прерван по таймауту ${timeoutSec} с)`; }, timeoutSec * 1000);
    child.on('error', (e) => { clearTimeout(t); done({ code: 1, stdout, stderr: e.message }); });
    child.on('close', (code) => { clearTimeout(t); done({ code: code ?? 1, stdout: stdout.trim(), stderr: stderr.trim() }); });
    child.stdin.on('error', () => {});
    child.stdin.end(JSON.stringify(input));
  });
}

/**
 * Creates the runner. `run(event, payload)` → { block, reason, context, decision }:
 *   block    true when a hook refused (exit 2 or "decision":"block" / permissionDecision "deny")
 *   decision "allow" | "ask" from PreToolUse JSON (skip or force the confirmation)
 *   context  text from stdout to add for the agent (SessionStart, UserPromptSubmit, PostToolUse)
 */
export function createHooks(configs, { cwd, env = process.env, sessionId = '', warn = () => {} } = {}) {
  return {
    configs,
    count: configs.reduce((n, c) => n + EVENTS.reduce((k, e) => k + commandsOf([c], e).length, 0), 0),
    async run(event, payload = {}) {
      const list = commandsOf(configs, event).filter((h) => matches(h.matcher, payload.tool_name));
      const res = { block: false, reason: '', context: '', decision: null };
      for (const h of list) {
        const r = await runCommand(h.command, { hook_event_name: event, session_id: sessionId, cwd, ...payload }, { cwd, env, timeoutSec: Math.min(+h.timeout || 60, 600) });
        let json = null;
        if (r.stdout.startsWith('{')) { try { json = JSON.parse(r.stdout); } catch { /* plain text */ } }
        const hso = json?.hookSpecificOutput || {};
        if (r.code === 2 || json?.decision === 'block' || hso.permissionDecision === 'deny') {
          res.block = true;
          res.reason = [res.reason, json?.reason || hso.permissionDecisionReason || r.stderr || `хук ${h.command} запретил`].filter(Boolean).join('\n');
          break;
        }
        if (hso.permissionDecision === 'allow' || hso.permissionDecision === 'ask') res.decision = hso.permissionDecision;
        if (r.code !== 0) { warn(`хук ${event} (${h.command}): код ${r.code}${r.stderr ? ', ' + r.stderr.split('\n')[0] : ''}`); continue; }
        const add = hso.additionalContext || (json ? '' : r.stdout);
        if (add) res.context += (res.context ? '\n' : '') + add;
      }
      return res;
    },
  };
}

export const noHooks = { configs: [], count: 0, run: async () => ({ block: false, reason: '', context: '', decision: null }) };
