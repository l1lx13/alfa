// Skills, custom slash commands and project instructions.
//
// Skill: a folder with SKILL.md (front matter `name`, `description`, then instructions). The agent sees the list
//   of names and descriptions and loads the full text with the `skill` tool when a task fits; the user can also
//   run one as /name. Looked up in <project>/.klinch/skills, <project>/.claude/skills, ~/.klinch/skills.
// Command: a Markdown file whose text becomes the prompt of /name; `$ARGUMENTS` is replaced by what follows.
//   <project>/.klinch/commands, <project>/.claude/commands, ~/.klinch/commands.
// Subagent: a Markdown file (front matter `name`, `description`, `tools`) whose text is the subagent's instructions;
//   the agent starts it with task type "<name>". <project>/.klinch/agents, <project>/.claude/agents, ~/.klinch/agents,
//   ~/.claude/agents.
// Output style: a Markdown file (front matter `name`, `description`) added to the system prompt (/style).
//   <project>/.klinch/output-styles, <project>/.claude/output-styles, ~/.klinch/output-styles, ~/.claude/output-styles.
// Instructions: KLINCH.md, AGENTS.md and CLAUDE.md in the project and ~/.klinch/KLINCH.md go into the system prompt.
// Installed plugins (src/plugins.js) add their commands, skills, agents and styles before the user's own.
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { homedir } from 'node:os';
import { join, basename, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadPlugins } from './plugins.js';

// Skills that ship with the CLI (its skills/ folder): recipes for whole kinds of tasks (a Remotion video,
// a white-label copy of a site…). Lowest priority, so a plugin's or the user's skill of the same name wins.
const BUILTIN_SKILLS = join(dirname(fileURLToPath(import.meta.url)), '..', 'skills');
const home = (env) => env.KLINCH_HOME || join(homedir(), '.klinch');
const read = (p) => { try { return readFileSync(p, 'utf8'); } catch { return null; } };
const isDir = (p) => { try { return statSync(p).isDirectory(); } catch { return false; } };

/** `---\nkey: value\n---\nbody` → { meta, body }. Values are plain strings (quotes stripped). */
export function frontMatter(text) {
  const m = /^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/.exec(text || '');
  if (!m) return { meta: {}, body: text || '' };
  const meta = {};
  for (const line of m[1].split(/\r?\n/)) {
    const kv = /^([A-Za-z0-9_-]+)\s*:\s*(.*)$/.exec(line);
    if (kv) meta[kv[1]] = kv[2].trim().replace(/^(['"])(.*)\1$/, '$2');
  }
  return { meta, body: m[2] };
}

/** Folders of one kind (skills, commands…), lowest priority first: plugins, yours, the project's. */
const roots = (cwd, env, kind, claudeHome = false) => [
  ...(kind === 'skills' && env.KLINCH_BUILTIN_SKILLS !== '0' ? [BUILTIN_SKILLS] : []),
  ...loadPlugins(env).map((p) => join(p.dir, kind)),
  ...(claudeHome ? [join(env.HOME || homedir(), '.claude', kind)] : []),
  join(home(env), kind), join(cwd, '.claude', kind), join(cwd, '.klinch', kind),
];

const slug = (s) => String(s || '').trim().toLowerCase().replace(/[^a-z0-9а-яё_-]+/gi, '-').replace(/^-+|-+$/g, '').slice(0, 64);

export function loadSkills(cwd, env = process.env) {
  const out = new Map();
  for (const root of roots(cwd, env, 'skills')) {
    if (!isDir(root)) continue;
    for (const d of readdirSync(root).sort()) {
      const dir = join(root, d), text = read(join(dir, 'SKILL.md'));
      if (!text) continue;
      const { meta, body } = frontMatter(text);
      const name = slug(meta.name || d);
      if (name) out.set(name, { name, description: (meta.description || body.split('\n').find((l) => l.trim()) || '').slice(0, 300), body, dir });
    }
  }
  return [...out.values()];
}

export function loadCommands(cwd, env = process.env) {
  const out = new Map();
  for (const root of roots(cwd, env, 'commands')) {
    if (!isDir(root)) continue;
    for (const f of readdirSync(root).sort()) {
      if (!f.endsWith('.md')) continue;
      const { meta, body } = frontMatter(read(join(root, f)) || '');
      const name = slug(basename(f, '.md'));
      if (name && body.trim()) out.set(name, { name, description: meta.description || body.trim().split('\n')[0].slice(0, 120), body });
    }
  }
  return [...out.values()];
}

/** Markdown files of a kind as { name, meta, body }, later folders winning on a name clash. */
function mdFiles(dirs) {
  const out = new Map();
  for (const root of dirs) {
    if (!isDir(root)) continue;
    for (const f of readdirSync(root).sort()) {
      if (!f.endsWith('.md')) continue;
      const { meta, body } = frontMatter(read(join(root, f)) || '');
      const name = slug(meta.name || basename(f, '.md'));
      if (name && body.trim()) out.set(name, { name, meta, body: body.trim() });
    }
  }
  return [...out.values()];
}

// Claude Code tool names in an agent's `tools:` line; any tool that changes things makes the subagent a «general» one.
const READ_ONLY = /^(read|grep|glob|ls|webfetch|websearch|read_file|search|list_files|web_fetch|web_search|repo_map|notebookread|todowrite|todo_write)$/i;
const RESERVED = new Set(['explore', 'general']);

/** Subagents: [{ name, description, prompt, readOnly }]. */
export function loadAgents(cwd, env = process.env) {
  return mdFiles(roots(cwd, env, 'agents', true)).filter((a) => !RESERVED.has(a.name)).map((a) => {
    const tools = String(a.meta.tools || '').split(/[,\s]+/).filter(Boolean);
    return { name: a.name, description: String(a.meta.description || a.body.split('\n')[0]).slice(0, 300), prompt: a.body.slice(0, 20000), readOnly: tools.length > 0 && tools.every((t) => READ_ONLY.test(t)) };
  });
}

// Built-in output styles (/style). `default` adds nothing.
export const BUILTIN_STYLES = [
  { name: 'default', description: 'обычные короткие ответы', prompt: null },
  { name: 'explanatory', description: 'объясняет решения и устройство кода по ходу работы', prompt: 'Работая над задачей, коротко объясняй пользователю, почему ты выбираешь такое решение и как устроен код, который ты читаешь и меняешь: 1-3 предложения «Почему так» после важных шагов. Не жертвуй качеством и скоростью работы ради объяснений.' },
  { name: 'learning', description: 'учит: оставляет пользователю небольшие куски кода написать самому', prompt: 'Пользователь хочет научиться. Объясняй ход мысли, а в подходящих местах (небольшая функция, условие, тест на 5-10 строк) не пиши код сам: оставь в файле пометку TODO(вы) с точной постановкой и попроси пользователя дописать, затем проверь его вариант. Остальную работу делай сам как обычно.' },
];

/** Output styles: built-in ones, then files (plugins, ~/.claude, yours, the project's). */
export function loadOutputStyles(cwd, env = process.env) {
  const out = new Map(BUILTIN_STYLES.map((s) => [s.name, s]));
  for (const s of mdFiles(roots(cwd, env, 'output-styles', true))) out.set(s.name, { name: s.name, description: String(s.meta.description || '').slice(0, 200), prompt: s.body.slice(0, 20000) });
  return [...out.values()];
}

/** The prompt a custom command sends: `$ARGUMENTS` replaced, or the arguments appended when the file has no placeholder. */
export function expandCommand(cmd, args = '') {
  return cmd.body.includes('$ARGUMENTS') ? cmd.body.split('$ARGUMENTS').join(args) : cmd.body.trim() + (args ? `\n\n${args}` : '');
}

export const INSTRUCTION_FILES = ['KLINCH.md', 'AGENTS.md', 'CLAUDE.md'];

/** Project and personal instructions for the system prompt (each file up to 20 KB). */
export function loadInstructions(cwd, env = process.env) {
  const parts = [];
  const add = (p, label) => { const t = read(p); if (t?.trim()) parts.push(`# ${label}\n${t.trim().slice(0, 20000)}`); };
  add(join(home(env), 'KLINCH.md'), 'Личные инструкции пользователя (~/.klinch/KLINCH.md)');
  for (const f of INSTRUCTION_FILES) if (existsSync(join(cwd, f))) add(join(cwd, f), `Инструкции проекта (${f})`);
  return parts.join('\n\n');
}
