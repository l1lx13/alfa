// Agent Review outside the chat: `klinch review [--staged] [--strict]` checks the changes with a read-only reviewer,
// and `klinch hook install [--strict]` runs it before every `git commit` (pre-commit hook). By default the hook only
// shows the findings; with --strict a commit whose review ends «нужно исправить» is stopped. Skip once:
// KLINCH_SKIP_REVIEW=1 git commit …, or git commit --no-verify.
import { execFileSync } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync, unlinkSync, chmodSync, mkdirSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { createAgent } from './agent.js';
import { REVIEWER, reviewPrompt, currentDiff, textOf } from './multi.js';

const MARK = '# agent-review-hook';
const git = (cwd, args) => execFileSync('git', args, { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], maxBuffer: 64 << 20 });

/** The changes to review: staged ones (what the commit will hold) or everything not committed yet. */
export function changesFor(cwd, { staged = false } = {}) {
  if (staged) return git(cwd, ['diff', '--cached']);
  return currentDiff(cwd).diff;
}

export const verdict = (t) => (/ИТОГ:\s*нужно исправить/i.test(t) ? 'fix' : /ИТОГ:\s*можно принимать/i.test(t) ? 'ok' : null);

/** Runs the reviewer on `diff`; streams its answer to `out`. Returns { text, verdict }. */
export async function reviewChanges({ client, model, cwd, diff, out, task = '' }) {
  const agent = createAgent({ client, model, cwd, out, confirm: async () => false, subagent: 'explore', role: REVIEWER, maxSteps: 40 });
  const text = textOf(await agent.ask(reviewPrompt(diff, task)));
  return { text, verdict: verdict(text) };
}

/** The pre-commit hook file of the repository (core.hooksPath respected). */
export function hookPath(cwd) {
  const p = git(cwd, ['rev-parse', '--git-path', 'hooks/pre-commit']).trim();
  return resolve(cwd, p);
}

export const hookScript = (cmd, strict) => `#!/bin/sh
${MARK}
# Agent Review of the staged changes before each commit. Skip once: KLINCH_SKIP_REVIEW=1 git commit (or --no-verify).
[ -n "$KLINCH_SKIP_REVIEW" ] && exit 0
command -v ${cmd} >/dev/null 2>&1 || exit 0
exec ${cmd} review --staged --hook${strict ? ' --strict' : ''} < /dev/null
`;

/** `hook install [--strict] [--force]` / `hook remove` / `hook` (status). Returns lines to print. */
export function hookCommand(args, cwd, cmd = 'klinch') {
  const [sub = ''] = args.filter((a) => !a.startsWith('-'));
  const file = hookPath(cwd);
  const ours = existsSync(file) && readFileSync(file, 'utf8').includes(MARK);
  if (sub === 'install') {
    if (existsSync(file) && !ours && !args.includes('--force')) throw new Error(`Уже есть свой pre-commit: ${file}. Заменить: hook install --force`);
    mkdirSync(dirname(file), { recursive: true });
    writeFileSync(file, hookScript(cmd, args.includes('--strict')));
    try { chmodSync(file, 0o755); } catch { /* Windows */ }
    return [`Ревью перед коммитом включено (${file}).`, args.includes('--strict') ? 'Коммит остановится, если ревью скажет «нужно исправить».' : 'Замечания показываются, коммит не блокируется (строго: hook install --strict).', 'Пропустить один раз: git commit --no-verify'];
  }
  if (sub === 'remove' || sub === 'uninstall') {
    if (!ours) return ['Хука ревью нет.'];
    unlinkSync(file); return ['Ревью перед коммитом выключено.'];
  }
  return [ours ? `Ревью перед коммитом включено: ${file}${readFileSync(file, 'utf8').includes('--strict') ? ' (строго)' : ''}` : 'Ревью перед коммитом выключено. Включить: hook install [--strict]'];
}
