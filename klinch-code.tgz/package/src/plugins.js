// Plugins: a folder that brings commands, skills, subagents, hooks, MCP servers and output styles at once, in the
// Claude Code plugin layout, so an existing plugin works as is:
//
//   <plugin>/.claude-plugin/plugin.json   { "name": "…", "description": "…", "version": "…" }
//   <plugin>/commands/*.md                 slash commands
//   <plugin>/skills/<name>/SKILL.md        skills
//   <plugin>/agents/*.md                   subagents for the task tool
//   <plugin>/hooks/hooks.json              { "hooks": { "PreToolUse": [...] } }
//   <plugin>/.mcp.json                     { "mcpServers": { … } }
//   <plugin>/output-styles/*.md            output styles
//
// ${CLAUDE_PLUGIN_ROOT} / ${KLINCH_PLUGIN_ROOT} in hooks and MCP configs is the plugin's folder.
// Installed with `klinch plugin add <git-url | folder>` into ~/.klinch/plugins/<name>; installing is the user's
// consent, so a plugin's hooks and servers run like the user's own.
import { readFileSync, readdirSync, statSync, existsSync, cpSync, rmSync, mkdirSync, renameSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { homedir } from 'node:os';
import { join, resolve, basename } from 'node:path';

const home = (env) => env.KLINCH_HOME || join(homedir(), '.klinch');
export const pluginsDir = (env = process.env) => join(home(env), 'plugins');
const readJson = (p) => { try { return JSON.parse(readFileSync(p, 'utf8')); } catch { return null; } };
const isDir = (p) => { try { return statSync(p).isDirectory(); } catch { return false; } };
const PARTS = ['commands', 'skills', 'agents', 'hooks', 'output-styles', '.mcp.json'];

function manifestOf(dir) {
  return readJson(join(dir, '.claude-plugin', 'plugin.json'));
}
const looksLikePlugin = (dir) => !!manifestOf(dir) || PARTS.some((p) => existsSync(join(dir, p)));

/** Installed plugins: [{ name, dir, description, version }]. */
export function loadPlugins(env = process.env) {
  const root = pluginsDir(env);
  if (!isDir(root)) return [];
  return readdirSync(root).sort().map((d) => join(root, d)).filter((dir) => isDir(dir) && looksLikePlugin(dir)).map((dir) => {
    const m = manifestOf(dir) || {};
    return { name: String(m.name || basename(dir)), dir, description: String(m.description || ''), version: m.version ? String(m.version) : '' };
  });
}

/** Every string in a JSON value with the plugin root put in. */
export function withRoot(v, dir) {
  if (typeof v === 'string') return v.split('${CLAUDE_PLUGIN_ROOT}').join(dir).split('${KLINCH_PLUGIN_ROOT}').join(dir);
  if (Array.isArray(v)) return v.map((x) => withRoot(x, dir));
  if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, withRoot(x, dir)]));
  return v;
}

/** Hook configs of the plugins, as hooks.js reads them. */
export const pluginHooks = (env = process.env) => loadPlugins(env).map((p) => {
  const file = join(p.dir, 'hooks', 'hooks.json'), h = readJson(file)?.hooks;
  return h && typeof h === 'object' ? { file, source: 'user', hooks: withRoot(h, p.dir) } : null;
}).filter(Boolean);

/** MCP servers of the plugins: { name: config }. */
export const pluginServers = (env = process.env) => loadPlugins(env).flatMap((p) => {
  const file = join(p.dir, '.mcp.json');
  return Object.entries(readJson(file)?.mcpServers || {}).map(([name, config]) => ({ name, config: withRoot(config, p.dir), source: 'user', file }));
});

/** `klinch plugin add <git-url | folder> | list | remove <name>`. Returns lines to print. */
export function pluginCommand(argv, env = process.env, run = execFileSync) {
  const [sub, arg] = argv;
  const root = pluginsDir(env);
  if (!sub || sub === 'list' || sub === 'ls') {
    const list = loadPlugins(env);
    if (!list.length) return ['Плагинов нет. Поставить: klinch plugin add <ссылка на git или папка> (формат плагинов Claude Code)'];
    return list.map((p) => `${p.name}${p.version ? ' ' + p.version : ''}  ${p.description}  ${PARTS.filter((x) => existsSync(join(p.dir, x))).join(', ')}`);
  }
  if (sub === 'remove' || sub === 'rm') {
    const p = loadPlugins(env).find((x) => x.name === arg || basename(x.dir) === arg);
    if (!p) throw new Error(`Плагина ${arg || ''} нет. Список: klinch plugin list`);
    rmSync(p.dir, { recursive: true, force: true });
    return [`Удалён плагин ${p.name}.`];
  }
  if (sub === 'add' || sub === 'install') {
    if (!arg) throw new Error('klinch plugin add <ссылка на git-репозиторий или путь к папке>');
    mkdirSync(root, { recursive: true });
    const tmp = join(root, `.new-${Date.now()}`);
    const local = isDir(resolve(arg));
    try {
      if (local) cpSync(resolve(arg), tmp, { recursive: true, filter: (s) => !/[\\/](\.git|node_modules)$/.test(s) });
      else if (/^(https?:\/\/|git@|ssh:\/\/)/.test(arg) || /^[\w.-]+\/[\w.-]+$/.test(arg)) {
        const url = /^[\w.-]+\/[\w.-]+$/.test(arg) ? `https://github.com/${arg}.git` : arg;
        run('git', ['clone', '--depth', '1', '--', url, tmp], { stdio: ['ignore', 'ignore', 'pipe'], timeout: 120000 });
        rmSync(join(tmp, '.git'), { recursive: true, force: true });
      } else throw new Error(`Не нашёл папку и не похоже на ссылку: ${arg}`);
      if (!looksLikePlugin(tmp)) throw new Error('Это не плагин: нет .claude-plugin/plugin.json и папок commands, skills, agents, hooks');
      const name = String(manifestOf(tmp)?.name || basename(arg).replace(/\.git$/, '')).replace(/[^\w.-]+/g, '-').slice(0, 60);
      const dest = join(root, name);
      rmSync(dest, { recursive: true, force: true });
      renameSync(tmp, dest);
      const what = PARTS.filter((x) => existsSync(join(dest, x)));
      return [`Плагин ${name} установлен (${what.join(', ') || 'пустой'}). Подключится при следующем запуске klinch.`,
        ...(what.includes('hooks') || what.includes('.mcp.json') ? ['Он запускает свои команды (хуки или MCP-серверы): ставьте плагины только из источников, которым доверяете.'] : [])];
    } finally { rmSync(tmp, { recursive: true, force: true }); }
  }
  throw new Error('Команды: klinch plugin list | add <git или папка> | remove <имя>');
}
