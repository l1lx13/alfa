---
name: remotion-video
description: Видео кодом на Remotion (React): анимация логотипа, заставка, ролик с текстом и сценами, рендер в MP4/GIF/WebM. Загружай, когда просят сделать видео, анимацию или моушн и отрендерить файл.
---
# Видео на Remotion

Remotion рисует каждый кадр как React-компонент. Время = номер кадра (`useCurrentFrame()`), а не CSS-анимации.

## 1. Проект (без интерактивных вопросов)
Не запускай `npx create-video` (он спрашивает в терминале). Собери проект руками:
```
mkdir -p <папка>/src <папка>/public && cd <папка>
npm init -y >/dev/null
npm i remotion@4 @remotion/cli@4 react@18 react-dom@18 @fontsource/inter
npm i -D typescript @types/react@18
```
Все пакеты `remotion` и `@remotion/*` одной и той же версии, иначе рендер падает.

Файлы:
- `src/index.ts`: `import { registerRoot } from 'remotion'; import { Root } from './Root'; registerRoot(Root);`
- `src/Root.tsx`: `<Composition id="Main" component={Main} durationInFrames={180} fps={30} width={1920} height={1080} />`
- `src/Main.tsx`: сама анимация.
- `tsconfig.json`: `{"compilerOptions":{"jsx":"react-jsx","module":"esnext","moduleResolution":"bundler","target":"es2020","strict":true,"skipLibCheck":true,"esModuleInterop":true}}`

## 2. Анимация
- `const frame = useCurrentFrame(); const { fps } = useVideoConfig();`
- Плавно: `interpolate(frame, [0, 20], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.bezier(0.16, 1, 0.3, 1) })`. Без `clamp` значения уходят за пределы.
- Упруго: `spring({ frame: frame - delay, fps, config: { damping: 12, stiffness: 120 } })` (от 0 к 1, можно чуть за 1).
- Сцены по времени: `<Sequence from={60} durationInFrames={90}>`; внутри Sequence кадр снова считается с 0.
- Мигание: `Math.floor(frame / 15) % 2` или `interpolate(frame % 30, [0, 15, 30], [1, 0.2, 1])`.
- Нельзя: CSS `transition`/`@keyframes`, `setTimeout`, `Math.random()` (кадры рендерятся параллельно и не по порядку). Случайность только `random('seed')` из remotion.
- Логотип/SVG: перерисуй его в JSX (`<svg>` с теми же `rect`/`circle`), чтобы анимировать части по отдельности; картинку из public подключай через `staticFile('logo.svg')` и `<Img>`.

## Компоновка
- Логотип и текст рядом: ставь их в один flex-ряд (`display: 'flex', alignItems: 'center', gap: 48`) и двигай весь ряд, а не считай абсолютные координаты на глаз. Иначе текст наезжает на логотип.
- Нужна ширина текста заранее: `measureText` из `@remotion/layout-utils` (с тем же fontFamily, fontSize, fontWeight).
- Элемент, который сначала один на экране (логотип до появления текста), стоит ровно по центру кадра. Невидимый текст (opacity 0) всё равно занимает место во flex-ряду и сдвигает логотип из центра: пока текста нет, не держи его в потоке, или считай позиции явно.
- «Логотип уезжает влево, справа появляется текст» = переход от одного элемента по центру к группе «логотип + текст» по центру. Посчитай ширину группы (`measureText` для текста + размер логотипа + gap), конечная позиция логотипа `x = (1920 - ширинаГруппы) / 2`, и анимируй translateX от центра к ней. Текст держи на фиксированном gap от логотипа.
- Проверка по числам: на первом и последнем кадре середина видимых элементов должна быть около 960 по X (±20 px). Цвет логотипа ищи по пикселям (например, Python + Pillow) и сравни.
- Финальный кадр: всё по центру и в «безопасной зоне» (отступ от краёв не меньше 5% кадра), ничего не пересекается.

## 3. Шрифты без сети
Рендер не должен ходить в Google Fonts. Ставь шрифт пакетом `@fontsource/<имя>` и импортируй нужные начертания в `Main.tsx`: `import '@fontsource/inter/700.css';`, затем `fontFamily: 'Inter'`. Такой CSS сразу подключает и латиницу, и кириллицу.
- Если текст по-русски, шрифт должен иметь кириллицу. Один файл `latin-*.woff2` её не содержит: русские буквы уйдут в запасной шрифт с засечками.
- Свой файл в `public/` подключай через `loadFont` из `@remotion/fonts` и дождись загрузки (`delayRender`/`continueRender`), иначе первые кадры и still рендерятся запасным шрифтом.
- Проверь на кадре, что шрифт действительно тот: гротеск без засечек, а не Times.

## 4. Рендер и проверка (обязательно)
```
npx remotion compositions src/index.ts                     # композиция видна, ошибок сборки нет
npx remotion still src/index.ts Main out/check.png --frame=150   # кадр до полного рендера
npx remotion render src/index.ts Main out/video.mp4 --codec=h264
ffprobe -v error -show_entries format=duration:stream=width,height,r_frame_rate -of default=nw=1 out/video.mp4
```
- Первый запуск скачивает Chrome Headless Shell (около 100 МБ): ставь `timeout_sec` 600, а долгий рендер запускай в фоне и смотри вывод.
- На Linux без библиотек Chrome (ошибка про libnss3/libgbm и т. п.): `sudo apt-get install -y libnss3 libatk-bridge2.0-0 libgbm1 libxkbcommon0 libasound2t64 || sudo apt-get install -y libasound2`.
- После рендера ОБЯЗАТЕЛЬНО посмотри результат глазами: вытащи 2–3 кадра (`npx remotion still … --frame=N` или `ffmpeg -ss 5 -i out/video.mp4 -frames:v 1 out/frame.png`) и открой их через read_file. Проверь: всё в кадре, ничего не обрезано, текст читается, цвета как просили. Если не так, поправь и отрендери снова.
- GIF: `--codec=gif --every-nth-frame=2`; прозрачный фон: `--codec=prores --prores-profile=4444` или `--codec=vp8 --pixel-format=yuva420p`.

## 5. Отчёт
Напиши путь к MP4, длительность и размер по ffprobe, что происходит в ролике по секундам, и как перерендерить.
